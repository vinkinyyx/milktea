function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return r; }; var t, r = {}, e = Object.prototype, n = e.hasOwnProperty, o = "function" == typeof Symbol ? Symbol : {}, i = o.iterator || "@@iterator", a = o.asyncIterator || "@@asyncIterator", u = o.toStringTag || "@@toStringTag"; function c(t, r, e, n) { return Object.defineProperty(t, r, { value: e, enumerable: !n, configurable: !n, writable: !n }); } try { c({}, ""); } catch (t) { c = function c(t, r, e) { return t[r] = e; }; } function h(r, e, n, o) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype); return c(a, "_invoke", function (r, e, n) { var o = 1; return function (i, a) { if (3 === o) throw Error("Generator is already running"); if (4 === o) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var u = n.delegate; if (u) { var c = d(u, n); if (c) { if (c === f) continue; return c; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (1 === o) throw o = 4, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = 3; var h = s(r, e, n); if ("normal" === h.type) { if (o = n.done ? 4 : 2, h.arg === f) continue; return { value: h.arg, done: n.done }; } "throw" === h.type && (o = 4, n.method = "throw", n.arg = h.arg); } }; }(r, n, new Context(o || [])), !0), a; } function s(t, r, e) { try { return { type: "normal", arg: t.call(r, e) }; } catch (t) { return { type: "throw", arg: t }; } } r.wrap = h; var f = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var l = {}; c(l, i, function () { return this; }); var p = Object.getPrototypeOf, y = p && p(p(x([]))); y && y !== e && n.call(y, i) && (l = y); var v = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(l); function g(t) { ["next", "throw", "return"].forEach(function (r) { c(t, r, function (t) { return this._invoke(r, t); }); }); } function AsyncIterator(t, r) { function e(o, i, a, u) { var c = s(t[o], t, i); if ("throw" !== c.type) { var h = c.arg, f = h.value; return f && "object" == _typeof(f) && n.call(f, "__await") ? r.resolve(f.__await).then(function (t) { e("next", t, a, u); }, function (t) { e("throw", t, a, u); }) : r.resolve(f).then(function (t) { h.value = t, a(h); }, function (t) { return e("throw", t, a, u); }); } u(c.arg); } var o; c(this, "_invoke", function (t, n) { function i() { return new r(function (r, o) { e(t, n, r, o); }); } return o = o ? o.then(i, i) : i(); }, !0); } function d(r, e) { var n = e.method, o = r.i[n]; if (o === t) return e.delegate = null, "throw" === n && r.i["return"] && (e.method = "return", e.arg = t, d(r, e), "throw" === e.method) || "return" !== n && (e.method = "throw", e.arg = new TypeError("The iterator does not provide a '" + n + "' method")), f; var i = s(o, r.i, e.arg); if ("throw" === i.type) return e.method = "throw", e.arg = i.arg, e.delegate = null, f; var a = i.arg; return a ? a.done ? (e[r.r] = a.value, e.next = r.n, "return" !== e.method && (e.method = "next", e.arg = t), e.delegate = null, f) : a : (e.method = "throw", e.arg = new TypeError("iterator result is not an object"), e.delegate = null, f); } function w(t) { this.tryEntries.push(t); } function m(r) { var e = r[4] || {}; e.type = "normal", e.arg = t, r[4] = e; } function Context(t) { this.tryEntries = [[-1]], t.forEach(w, this), this.reset(!0); } function x(r) { if (null != r) { var e = r[i]; if (e) return e.call(r); if ("function" == typeof r.next) return r; if (!isNaN(r.length)) { var o = -1, a = function e() { for (; ++o < r.length;) if (n.call(r, o)) return e.value = r[o], e.done = !1, e; return e.value = t, e.done = !0, e; }; return a.next = a; } } throw new TypeError(_typeof(r) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, c(v, "constructor", GeneratorFunctionPrototype), c(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = c(GeneratorFunctionPrototype, u, "GeneratorFunction"), r.isGeneratorFunction = function (t) { var r = "function" == typeof t && t.constructor; return !!r && (r === GeneratorFunction || "GeneratorFunction" === (r.displayName || r.name)); }, r.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, c(t, u, "GeneratorFunction")), t.prototype = Object.create(v), t; }, r.awrap = function (t) { return { __await: t }; }, g(AsyncIterator.prototype), c(AsyncIterator.prototype, a, function () { return this; }), r.AsyncIterator = AsyncIterator, r.async = function (t, e, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(h(t, e, n, o), i); return r.isGeneratorFunction(e) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, g(v), c(v, u, "Generator"), c(v, i, function () { return this; }), c(v, "toString", function () { return "[object Generator]"; }), r.keys = function (t) { var r = Object(t), e = []; for (var n in r) e.unshift(n); return function t() { for (; e.length;) if ((n = e.pop()) in r) return t.value = n, t.done = !1, t; return t.done = !0, t; }; }, r.values = x, Context.prototype = { constructor: Context, reset: function reset(r) { if (this.prev = this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(m), !r) for (var e in this) "t" === e.charAt(0) && n.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0][4]; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(r) { if (this.done) throw r; var e = this; function n(t) { a.type = "throw", a.arg = r, e.next = t; } for (var o = e.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i[4], u = this.prev, c = i[1], h = i[2]; if (-1 === i[0]) return n("end"), !1; if (!c && !h) throw Error("try statement without catch or finally"); if (null != i[0] && i[0] <= u) { if (u < c) return this.method = "next", this.arg = t, n(c), !0; if (u < h) return n(h), !1; } } }, abrupt: function abrupt(t, r) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var n = this.tryEntries[e]; if (n[0] > -1 && n[0] <= this.prev && this.prev < n[2]) { var o = n; break; } } o && ("break" === t || "continue" === t) && o[0] <= r && r <= o[2] && (o = null); var i = o ? o[4] : {}; return i.type = t, i.arg = r, o ? (this.method = "next", this.next = o[2], f) : this.complete(i); }, complete: function complete(t, r) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && r && (this.next = r), f; }, finish: function finish(t) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var e = this.tryEntries[r]; if (e[2] === t) return this.complete(e[4], e[3]), m(e), f; } }, "catch": function _catch(t) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var e = this.tryEntries[r]; if (e[0] === t) { var n = e[4]; if ("throw" === n.type) { var o = n.arg; m(e); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(r, e, n) { return this.delegate = { i: x(r), r: e, n: n }, "next" === this.method && (this.arg = t), f; } }, r; }
System.register("chunks:///_virtual/AppRoot.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./ConfigLoader.ts", "./HostLifecycleCoordinator.ts", "./CoordinateMapper.ts", "./Viewport.ts", "./GameRoot.ts", "./AppRuntime.ts"], function (t) {
  var e, o, n, i, r, a, s, d, l, p, u, c, h, f, g, v, C, T, y, m, S, _, w, O, k, I, A, E;
  return {
    setters: [function (t) {
      e = t.inheritsLoose;
    }, function (t) {
      o = t.cclegacy, n = t._decorator, i = t.Canvas, r = t.UITransform, a = t.input, s = t.Input, d = t.resources, l = t.JsonAsset, p = t.Node, u = t.Graphics, c = t.Color, h = t.Label, f = t.Texture2D, g = t.SpriteFrame, v = t.Sprite, C = t.PHYSICS_2D_PTM_RATIO, T = t.PhysicsSystem2D, y = t.Vec2, m = t.Vec3, S = t.Component;
    }, function (t) {
      _ = t.ConfigLoader;
    }, function (t) {
      w = t.HostLifecycleCoordinator;
    }, function (t) {
      O = t.CoordinateMapper;
    }, function (t) {
      k = t.configureViewport, I = t.presentationSize;
    }, function (t) {
      A = t.GameRoot;
    }, function (e) {
      E = e.AppRuntime, t("AppRuntime", e.AppRuntime);
    }],
    execute: function execute() {
      var R;
      o._RF.push({}, "23a90TkkpxQSKONswVIHcNR", "AppRoot", void 0);
      var b = n.ccclass;
      t("AppRoot", b("AppRoot")(R = function (t) {
        function o() {
          for (var e, o = arguments.length, n = new Array(o), i = 0; i < o; i++) n[i] = arguments[i];
          return (e = t.call.apply(t, [this].concat(n)) || this).retryNode = null, e.loadGeneration = 0, e.loading = !1, e.startupToken = 0, e.startupFrame = null, e.sceneTransition = !1, e.bootTrace = 0, e;
        }
        e(o, t);
        var n = o.prototype;
        return n.onLoad = function () {
          var t;
          this.node.getComponent(i) || this.node.addComponent(i), (null != (t = this.node.getComponent(r)) ? t : this.node.addComponent(r)).setContentSize(750, 1334), k(this.node, {
            width_du: 750,
            height_du: 1334
          }), w.install(), this.showBrandFrame(), a.on(s.EventType.TOUCH_END, this.onRetryTouch, this), this.loadConfiguration();
        }, n.onDestroy = function () {
          this.loadGeneration++, a.off(s.EventType.TOUCH_END, this.onRetryTouch, this), this.loading && !this.sceneTransition && d.release("config/design-baseline", l), this.sceneTransition || 0 === this.startupToken || E.startupToken !== this.startupToken || (E.startupInProgress = !1, E.startupToken = 0);
        }, n.retry = function () {
          this.loadConfiguration();
        }, n.showBrandFrame = function () {
          var t = this,
            e = this.startupFrame = new p("MilkTeaStartupFrame");
          this.node.addChild(e), e.setSiblingIndex(0), e.addComponent(r).setContentSize(750, 1334);
          var o = I(),
            n = e.addComponent(u);
          n.fillColor = new c(255, 244, 225), n.rect(-o.width / 2, -o.height / 2, o.width, o.height), n.fill();
          var i = new p("BrandFallback");
          e.addChild(i), i.addComponent(r).setContentSize(650, 150), i.setPosition(0, 190, 0);
          var a = i.addComponent(h);
          a.string = "奶茶挤挤", a.fontSize = 82, a.lineHeight = 94, a.isBold = !0, a.color = new c(103, 58, 32), d.load("startup/brand-logo/texture", f, function (o, n) {
            if (t.isValid && t.startupFrame === e && e.isValid && e.activeInHierarchy) if (!o && n) {
              var a = new g();
              a.texture = n, a.packable = !1, e.once(p.EventType.NODE_DESTROYED, function () {
                a.isValid && a.destroy();
              });
              var s = new p("BrandLogo");
              e.addChild(s), s.addComponent(r).setContentSize(620, 218), s.setPosition(0, 190, 0), s.addComponent(v).spriteFrame = a, i.active = !1;
            } else {
              var d;
              console.warn("Startup logo unavailable; using text fallback: " + (null != (d = null == o ? void 0 : o.message) ? d : "missing asset"));
            }
          });
          var s = new p("BrandTagline");
          e.addChild(s), s.addComponent(r).setContentSize(690, 80), s.setPosition(0, 20, 0);
          var l = s.addComponent(h);
          l.string = "接住小料，挤出好心情", l.fontSize = 30, l.lineHeight = 40, l.color = new c(103, 58, 32);
          var C = new p("BrandPhase");
          e.addChild(C), C.addComponent(r).setContentSize(690, 70), C.setPosition(0, -360, 0);
          var T = C.addComponent(h);
          T.string = "准备杯子", T.fontSize = 24, T.lineHeight = 32, T.color = new c(145, 92, 57);
        }, n.onRetryTouch = function () {
          var t;
          null != (t = this.retryNode) && t.isValid && this.retry();
        }, n.loadConfiguration = function () {
          var t = this;
          if (!this.loading && !E.startupInProgress) {
            this.loading = !0, E.startupInProgress = !0, this.startupToken = ++E.startupSequence, E.startupToken = this.startupToken, E.rules = null, E.mapper = null, E.loadError = null;
            var e = ++this.loadGeneration,
              o = this.bootTrace = E.startup.beginTrace(0);
            E.startup.stage("BOOT_CONFIG", "start", {
              code: "config/design-baseline"
            }, 0, o), d.load("config/design-baseline", l, function (n, i) {
              var r;
              if (e === t.loadGeneration && t.isValid && E.startupToken === t.startupToken) {
                var a;
                if (n || !i) return d.release("config/design-baseline", l), t.finishStartup(t.startupToken), void t.showError("配置读取失败：" + (null != (a = null == n ? void 0 : n.message) ? a : "资源缺失"), "BOOT_CONFIG_READ", n);
                var s = _.validate(i.json);
                if (!s.ok) return d.release("config/design-baseline", l), t.finishStartup(t.startupToken), void t.showError("配置校验失败：" + s.error.message, "BOOT_CONFIG_VALIDATE", s.error);
                k(t.node, s.data.viewport), E.rules = s.data, null == (r = t.retryNode) || r.destroy(), t.retryNode = null, E.startup.stage("BOOT_CONFIG", "ok", {
                  code: "rules:" + s.data.design_rules_version,
                  bundleName: "viewport:" + s.data.viewport.width_du + "x" + s.data.viewport.height_du
                }, 0, o);
                var p = E.mapper = new O(s.data.viewport.width_du, s.data.viewport.height_du, s.data.viewport.du_per_spec_physics_unit, C),
                  u = T.instance;
                if (u.autoSimulation = !1, u.fixedTimeStep = 1 / s.data.physics.fixed_hz, u.resetAccumulator(0), u.allowSleep = s.data.physics.sleep, u.velocityIterations = s.data.physics.velocity_iterations, u.positionIterations = s.data.physics.position_iterations, !T.PHYSICS_BOX2D && !T.PHYSICS_BOX2D_WASM) return t.finishStartup(t.startupToken), void t.showError("未启用2D Box2D：请在项目设置→功能裁剪中启用后重试", "BOOT_PHYSICS_UNSUPPORTED");
                u.gravity = new y(p.specAccelerationToCocosGravityApi(s.data.physics.gravity.x), p.specAccelerationToCocosGravityApi(s.data.physics.gravity.y));
                var c = t.startupToken;
                try {
                  t.node.addComponent(A), t.finishStartup(c);
                } catch (n) {
                  t.finishStartup(c), t.showError("玩家界面初始化失败：" + String(n), "BOOT_GAMEROOT_FAILED", n);
                }
              }
            });
          }
        }, n.showError = function (t, e, o) {
          var n;
          void 0 === e && (e = "BOOT_CONFIG_FAILED"), E.loadError = t;
          try {
            E.startup.stage("BOOT_CONFIG", "error", {
              code: e,
              error: null != o ? o : t,
              stack: this.stackSummary(o)
            }, 0, this.bootTrace);
          } catch (t) {}
          null != (n = this.retryNode) && n.isValid && this.retryNode.destroy();
          var i = this.retryNode = new p("ConfigErrorRetry");
          this.node.addChild(i), i.addComponent(r).setContentSize(700, 220);
          var a = i.addComponent(h);
          a.string = e + "\n" + t.slice(0, 80) + "\n点击画面重试", a.fontSize = 28, a.lineHeight = 40, a.overflow = h.Overflow.CLAMP, a.enableWrapText = !0, console.error("[boot] " + e + " " + t, null != o ? o : ""), i.setPosition(new m(0, 0, 0));
        }, n.stackSummary = function (t) {
          var e = t instanceof Error ? t.stack : void 0;
          if (e) return e.split("\n").slice(0, 6).join(" | ");
        }, n.finishStartup = function (t) {
          if (E.startupToken === t) {
            this.loading = !1, E.startupInProgress = !1, E.startupToken = 0, this.startupToken = 0;
            var e = globalThis.__milkteaBootReady;
            "function" == typeof e && e();
          }
        }, o;
      }(S)) || R);
      o._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/AppRuntime.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./HostLifecycleCoordinator.ts", "./StartupTrace.ts"], function (e) {
  var t, n, u, r;
  return {
    setters: [function (e) {
      t = e.createClass;
    }, function (e) {
      n = e.cclegacy;
    }, function (e) {
      u = e.HostLifecycleCoordinator;
    }, function (e) {
      r = e.StartupTrace;
    }],
    execute: function execute() {
      var c;
      n._RF.push({}, "5a531a36ApMboinRwonp+lu", "AppRuntime", void 0);
      var a = e("AppRuntime", function () {
        function e() {}
        return t(e, null, [{
          key: "backgrounded",
          get: function get() {
            return u.backgrounded;
          }
        }]), e;
      }());
      c = a, a.buildId = "20261106-adfix-tap-candidate-01", a.startup = new r(function () {
        return c.buildId;
      }), a.configRulesHash = "c4c93c79d0b1d1bfd0eb65ade281e3f7ef29ea95124c54a60bdcafde5d716d02", a.rules = null, a.mapper = null, a.loadError = null, a.startupInProgress = !1, a.startupToken = 0, a.startupSequence = 0, n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ArtAssets.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./ArtCatalog.ts", "./ArtLoadBudget.ts", "./HostLifecycleCoordinator.ts"], function (e) {
  var t, n, i, r, s, o, a, u, c, d, l, h, g, f, p, v, b;
  return {
    setters: [function (e) {
      t = e.createForOfIteratorHelperLoose, n = e.createClass, i = e.asyncToGenerator;
    }, function (e) {
      r = e.cclegacy, s = e.Sprite, o = e.Node, a = e.UITransform, u = e.Texture2D, c = e.SpriteFrame, d = e.resources, l = e.ImageAsset, h = e.assetManager, g = e.JsonAsset;
    }, function (e) {
      f = e.ArtCatalog;
    }, function (e) {
      p = e.makeBudgetError, v = e.ArtLoadBudget;
    }, function (e) {
      b = e.HostLifecycleCoordinator;
    }],
    execute: function execute() {
      function m() {
        try {
          return "undefined" != typeof performance && "function" == typeof performance.now ? performance.now() : Date.now();
        } catch (e) {
          return 0;
        }
      }
      r._RF.push({}, "e3337X3fNpIAZzZa9J6ifeh", "ArtAssets", void 0);
      e("ArtAssets", function () {
        function e() {
          this.catalog = void 0, this.disposed = !1, this.generation = 1, this.registry = null, this.loaded = new Map(), this.pending = new Map(), this.bundles = new Map(), this.bundleLoads = new Map(), this.scope = null, this.budgetTimer = null;
        }
        var r = e.prototype;
        return r.beginLoadScope = function (e, t, n, i) {
          var r = this;
          void 0 === n && (n = 15e3), void 0 === i && (i = "GAME_ART"), this.cancelScope("START_ART_CANCELLED"), this.generation++;
          var s = new v(e, t, n),
            o = {
              budget: s,
              generation: this.generation,
              kind: i,
              lastAccountedAtMs: m(),
              previousForeground: !b.backgrounded,
              unsubscribeVisibility: null,
              closed: !1
            };
          return this.scope = o, this.pending.clear(), this.bundleLoads.clear(), o.unsubscribeVisibility = b.subscribe(function () {
            r.scope !== o || o.closed || (r.accountUntil(o, m()), o.previousForeground = !b.backgrounded, o.budget.expired && r.failScope(o));
          }), this.budgetTimer = setInterval(function () {
            return r.tickBudget(o);
          }, 150), s;
        }, r.settleLoadScope = function (e) {
          var t = this.scope;
          t && (e && t.budget !== e || (this.accountUntil(t, m()), t.budget.active ? (t.budget.settle(), this.closeScope(t)) : this.failScope(t)));
        }, r.cancelScope = function (e, t) {
          void 0 === e && (e = "START_ART_CANCELLED");
          var n = this.scope;
          n && (t && n.budget !== t || (n.budget.cancel(e), this.closeScope(n), this.generation++, this.pending.clear(), this.bundleLoads.clear()));
        }, r.initialize = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
            var e, t;
            return _regeneratorRuntime().wrap(function _callee$(_context2) {
              while (1) switch (_context2.prev = _context2.next) {
                case 0:
                  e = this.requireActiveScope();
                  _context2.next = 3;
                  return this.raceBudget(e, new Promise(function (e, t) {
                    return d.load("art/p1/catalog", g, function (n, i) {
                      return n || !i ? t(null != n ? n : new Error("美术索引缺失")) : e(i);
                    });
                  }));
                case 3:
                  t = _context2.sent;
                  this.assertScope(e), t.addRef(), this.registry = t, this.catalog = new f(t.json);
                case 5:
                case "end":
                  return _context2.stop();
              }
            }, _callee, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), r.getLoadedVariant = function (e) {
          var t;
          return null == (t = this.loaded.get(e)) ? void 0 : t.variant;
        }, r.loadedVariantSnapshot = function () {
          return Array.from(this.loaded.entries(), function (e) {
            var t = e[0],
              n = e[1];
            return {
              assetId: t,
              variantId: n.variant.resource_key,
              path: n.variant.png,
              size: n.variant.size,
              alphaInsets: f.insets(n.variant),
              pivot: f.pivot(n.variant)
            };
          });
        }, r.load = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(e, t) {
            return _regeneratorRuntime().wrap(function _callee2$(_context3) {
              while (1) switch (_context3.prev = _context3.next) {
                case 0:
                  void 0 === t && (t = 128);
                  _context3.next = 3;
                  return this.acquire(e, t);
                case 3:
                case "end":
                  return _context3.stop();
              }
            }, _callee2, this);
          }));
          return function (t, n) {
            return e.apply(this, arguments);
          };
        }(), r.setSpriteAsset = function (e, t) {
          var n = this.loaded.get(t),
            i = e.getComponent(s);
          n && i && (i.spriteFrame = n.frame);
        }, r.createSprite = function (e, t, n, i, r) {
          void 0 === r && (r = !1), this.assertAlive();
          var u = this.loaded.get(t);
          if (!u) throw new Error("图片尚未加载: " + t);
          var c = new o(t);
          e.addChild(c);
          var d = c.addComponent(a),
            l = r ? [.5, .5] : f.pivot(u.variant);
          d.setAnchorPoint(l[0], l[1]);
          var h = c.addComponent(s);
          return h.sizeMode = s.SizeMode.CUSTOM, h.trim = !1, h.spriteFrame = u.frame, h.type = f.insets(u.variant) ? s.Type.SLICED : s.Type.SIMPLE, d.setContentSize(n, i), c;
        }, r.dispose = function () {
          var e;
          if (!this.disposed) {
            this.disposed = !0, this.cancelScope("START_ART_CANCELLED");
            for (var n, i = t(this.loaded.values()); !(n = i()).done;) {
              var r = n.value;
              r.frame.destroy(), r.texture.destroy(), r.image.decRef(), this.releaseImage(r.variant);
            }
            this.loaded.clear(), this.pending.clear(), this.bundleLoads.clear(), null == (e = this.registry) || e.decRef(), this.registry = null, this.stopBudgetTimer();
          }
        }, r.requireActiveScope = function () {
          var e = this.scope;
          if (!e) throw p("START_ART_CANCELLED");
          return this.accountUntil(e, m()), e.budget.assertActive(), e;
        }, r.assertScope = function (e) {
          if (this.disposed || this.scope !== e || e.generation !== this.generation || e.closed) throw p("START_ART_CANCELLED");
          this.accountUntil(e, m()), e.budget.assertActive();
        }, r.accountUntil = function (e, t) {
          if (!e.closed) {
            var n = t - e.lastAccountedAtMs;
            e.lastAccountedAtMs = t, !Number.isFinite(n) || n <= 0 || e.previousForeground && e.budget.advance(n, !0);
          }
        }, r.closeScope = function (e) {
          e.closed || (e.closed = !0, e.unsubscribeVisibility && (e.unsubscribeVisibility(), e.unsubscribeVisibility = null), this.scope === e && (this.scope = null, this.stopBudgetTimer()));
        }, r.failScope = function (e) {
          e.closed || (this.closeScope(e), this.generation++, this.pending.clear(), this.bundleLoads.clear());
        }, r.raceBudget = function (e, t) {
          return Promise.race([t, e.budget.cancelled()]);
        }, r.tickBudget = function (e) {
          e.closed || this.scope !== e || (this.accountUntil(e, m()), e.budget.active || this.failScope(e));
        }, r.stopBudgetTimer = function () {
          null !== this.budgetTimer && (clearInterval(this.budgetTimer), this.budgetTimer = null);
        }, r.acquire = function (e, t) {
          var n = this;
          this.assertAlive();
          var i = this.loaded.get(e);
          if (i) return Promise.resolve(i);
          var r = this.requireActiveScope(),
            s = this.pending.get(e);
          if (s) return this.raceBudget(r, s);
          var o = this.catalog.select(e, t),
            a = this.loadImage(o, r).then(function (t) {
              if (n.assertScope(r), !t) throw new Error("图片加载失败 " + e + ": 资源缺失");
              if (t.width !== o.size[0] || t.height !== o.size[1]) throw n.releaseImage(o), new Error("图片尺寸不符: " + e);
              n.assertScope(r), t.addRef();
              try {
                var i = new u();
                i.image = t;
                var s = new c();
                s.texture = i, s.packable = !1;
                var a = f.insets(o);
                a && (s.insetLeft = a[0], s.insetTop = a[1], s.insetRight = a[2], s.insetBottom = a[3]);
                var d = {
                  variant: o,
                  image: t,
                  texture: i,
                  frame: s
                };
                return n.loaded.set(e, d), d;
              } catch (e) {
                throw t.decRef(), n.releaseImage(o), e;
              }
            })["catch"](function (t) {
              if (t instanceof Error && "ArtLoadBudgetError" === t.name) throw t;
              throw new Error("图片加载失败 " + e + ": " + (t instanceof Error ? t.message : String(t)));
            });
          return this.pending.set(e, a), a.then(function () {
            n.pending.get(e) === a && n.pending["delete"](e);
          }, function () {
            n.pending.get(e) === a && n.pending["delete"](e);
          }), a;
        }, r.loadImage = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3(e, t) {
            var n, i;
            return _regeneratorRuntime().wrap(function _callee3$(_context4) {
              while (1) switch (_context4.prev = _context4.next) {
                case 0:
                  if (e.bundle) {
                    _context4.next = 2;
                    break;
                  }
                  return _context4.abrupt("return", this.raceBudget(t, this.loadResourceImage(e)));
                case 2:
                  i = null != (n = this.bundles.get(e.bundle)) ? n : null;
                  if (i) {
                    _context4.next = 15;
                    break;
                  }
                  _context4.prev = 4;
                  _context4.next = 7;
                  return this.loadBundle(e.bundle, t);
                case 7:
                  i = _context4.sent;
                  _context4.next = 15;
                  break;
                case 10:
                  _context4.prev = 10;
                  _context4.t0 = _context4["catch"](4);
                  if (!(_context4.t0 instanceof Error && "ArtLoadBudgetError" === _context4.t0.name)) {
                    _context4.next = 14;
                    break;
                  }
                  throw _context4.t0;
                case 14:
                  i = null;
                case 15:
                  return _context4.abrupt("return", (this.assertScope(t), i ? this.raceBudget(t, new Promise(function (t, n) {
                    return i.load(f.imageKey(e), l, null, function (e, i) {
                      return e || !i ? n(null != e ? e : new Error("资源缺失")) : t(i);
                    });
                  })) : this.raceBudget(t, this.loadResourceImage(e))));
                case 16:
                case "end":
                  return _context4.stop();
              }
            }, _callee3, this, [[4, 10]]);
          }));
          return function (t, n) {
            return e.apply(this, arguments);
          };
        }(), r.loadResourceImage = function (e) {
          return new Promise(function (t, n) {
            return d.load(f.imageKey(e), l, function (e, i) {
              return e || !i ? n(null != e ? e : new Error("资源缺失")) : t(i);
            });
          });
        }, r.loadBundle = function (e, t) {
          var n = this,
            i = this.bundles.get(e);
          if (i) return Promise.resolve(i);
          var r = this.bundleLoads.get(e);
          if (r) return this.raceBudget(t, r);
          var s = this.raceBudget(t, new Promise(function (t, n) {
            return h.loadBundle(e, function (i, r) {
              return i || !r ? n(null != i ? i : new Error("Bundle 缺失: " + e)) : t(r);
            });
          })).then(function (i) {
            return n.scope === t && t.generation === n.generation && t.budget.active && n.bundles.set(e, i), i;
          });
          this.bundleLoads.set(e, s);
          var o = function o() {
            n.bundleLoads.get(e) === s && n.bundleLoads["delete"](e);
          };
          return s.then(o, o), s;
        }, r.releaseImage = function (e) {
          var t;
          e.bundle ? null == (t = this.bundles.get(e.bundle)) || t.release(f.imageKey(e), l) : d.release(f.imageKey(e), l);
        }, r.assertAlive = function () {
          if (this.disposed) throw new Error("美术资源持有者已销毁");
        }, n(e, [{
          key: "activeBudget",
          get: function get() {
            var e, t;
            return null != (e = null == (t = this.scope) ? void 0 : t.budget) ? e : null;
          }
        }, {
          key: "loadedCount",
          get: function get() {
            return this.loaded.size;
          }
        }]), e;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ArtCatalog.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (e) {
  var r, t, n;
  return {
    setters: [function (e) {
      r = e.createClass, t = e.createForOfIteratorHelperLoose;
    }, function (e) {
      n = e.cclegacy;
    }],
    execute: function execute() {
      n._RF.push({}, "7d986YUuW5FyZ5BfH9AfovI", "ArtCatalog", void 0);
      e("ArtCatalog", function () {
        function e(r) {
          var n = this;
          this.byId = new Map();
          var i = r;
          if (!i || !Array.isArray(i.variants) || 0 === i.variants.length) throw new Error("美术索引 variants 缺失");
          for (var s, o = function o() {
              var r,
                t,
                i,
                o = s.value;
              if (!o.asset_id || null == (r = o.resource_key) || !r.startsWith("art/p1/") || !o.resource_key.endsWith("/spriteFrame") || void 0 !== o.bundle && "common" !== o.bundle && "classic" !== o.bundle || !Array.isArray(o.size) || 2 !== o.size.length || !o.size.every(function (e) {
                return Number.isInteger(e) && e > 0;
              })) throw new Error("无效美术索引: " + (null != (i = o.asset_id) ? i : "unknown"));
              e.pivot(o), e.insets(o);
              var u = null != (t = n.byId.get(o.asset_id)) ? t : [];
              if (u.some(function (e) {
                return e.resource_key === o.resource_key;
              })) throw new Error("重复美术路径: " + o.resource_key);
              u.push(o), n.byId.set(o.asset_id, u);
            }, u = t(i.variants); !(s = u()).done;) o();
          for (var a, l = t(this.byId.values()); !(a = l()).done;) {
            a.value.sort(function (e, r) {
              return Math.max.apply(Math, e.size) - Math.max.apply(Math, r.size);
            });
          }
        }
        return e.prototype.select = function (e, r) {
          var t;
          if (!Number.isFinite(r) || r <= 0) throw new Error("目标贴图尺寸必须为正有限数");
          var n = this.byId.get(e);
          if (!n) throw new Error("缺少美术资源: " + e);
          return null != (t = n.find(function (e) {
            return Math.max.apply(Math, e.size) >= r;
          })) ? t : n[n.length - 1];
        }, e.imageKey = function (e) {
          return e.resource_key.replace(/\/spriteFrame$/, "");
        }, e.pivot = function (e) {
          var r = e.pivot.split(",").map(Number);
          if (2 !== r.length || r.some(function (e) {
            return !Number.isFinite(e) || e < 0 || e > 1;
          })) throw new Error("无效锚点: " + e.asset_id);
          return r;
        }, e.insets = function (e) {
          if ("none" === e.nine_slice) return null;
          var r = e.nine_slice.split(",").map(Number);
          if (4 !== r.length || r.some(function (e) {
            return !Number.isFinite(e) || e < 0;
          }) || r[0] + r[2] > e.size[0] || r[1] + r[3] > e.size[1]) throw new Error("无效九切: " + e.asset_id);
          return r;
        }, e.ingredientId = function (e) {
          return "spr_ing_" + e + "_base";
        }, e.ingredientEdgeDu = function (e) {
          if (!Number.isFinite(e) || e <= 0) throw new Error("小料半径必须为正有限数");
          return 2 * e / .9;
        }, r(e, [{
          key: "ids",
          get: function get() {
            return Array.from(this.byId.keys());
          }
        }, {
          key: "variantCount",
          get: function get() {
            for (var e, r = 0, n = t(this.byId.values()); !(e = n()).done;) {
              r += e.value.length;
            }
            return r;
          }
        }]), e;
      }());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ArtLoadBudget.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, s, n;
  return {
    setters: [function (t) {
      e = t.createForOfIteratorHelperLoose, s = t.createClass;
    }, function (t) {
      n = t.cclegacy;
    }],
    execute: function execute() {
      t("makeBudgetError", i), n._RF.push({}, "2cebdFKaTNA2oCGU5SDYle7", "ArtLoadBudget", void 0);
      t("ArtLoadBudget", function () {
        function t(t, e, s, n) {
          void 0 === s && (s = 15e3), void 0 === n && (n = 0), this.usedMs = 0, this.state = "ACTIVE", this.cancelHandles = [], this.ownerEpoch = t, this.traceId = e, this.budgetMs = s, this.usedMs = Math.max(0, n), this.usedMs >= this.budgetMs && (this.state = "EXPIRED");
        }
        var n = t.prototype;
        return n.advance = function (t, e) {
          return !("ACTIVE" !== this.state || !e || !Number.isFinite(t) || t <= 0) && (this.usedMs += t, !(this.usedMs < this.budgetMs) && (this.state = "EXPIRED", this.rejectAll("START_ART_TIMEOUT"), !0));
        }, n.cancel = function (t) {
          void 0 === t && (t = "START_ART_CANCELLED"), "ACTIVE" === this.state && (this.state = "CANCELLED", this.rejectAll(t));
        }, n.settle = function () {
          "ACTIVE" === this.state && (this.state = "SETTLED", this.resolvePending());
        }, n.assertActive = function () {
          if ("EXPIRED" === this.state) throw i("START_ART_TIMEOUT");
          if ("CANCELLED" === this.state) throw i("START_ART_CANCELLED");
        }, n.cancelled = function () {
          var t = this;
          return "EXPIRED" === this.state ? Promise.reject(i("START_ART_TIMEOUT")) : "CANCELLED" === this.state ? Promise.reject(i("START_ART_CANCELLED")) : "SETTLED" === this.state ? new Promise(function () {}) : new Promise(function (e, s) {
            t.cancelHandles.push(s);
          });
        }, n.rejectAll = function (t) {
          var s = this.cancelHandles;
          this.cancelHandles = [];
          for (var n, r = e(s); !(n = r()).done;) {
            var a = n.value;
            try {
              a(i(t));
            } catch (t) {}
          }
        }, n.resolvePending = function () {
          this.cancelHandles = [];
        }, s(t, [{
          key: "foregroundMs",
          get: function get() {
            return Math.round(this.usedMs);
          }
        }, {
          key: "remainingMs",
          get: function get() {
            return Math.max(0, this.budgetMs - this.usedMs);
          }
        }, {
          key: "expired",
          get: function get() {
            return "EXPIRED" === this.state;
          }
        }, {
          key: "active",
          get: function get() {
            return "ACTIVE" === this.state;
          }
        }, {
          key: "status",
          get: function get() {
            return this.state;
          }
        }]), t;
      }());
      function i(t) {
        var e = new Error(t);
        return e.name = "ArtLoadBudgetError", e;
      }
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/Clock.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, s;
  return {
    setters: [function (t) {
      e = t.createClass;
    }, function (t) {
      s = t.cclegacy;
    }],
    execute: function execute() {
      s._RF.push({}, "d80dc7Yj0RfwLoU3xH6mbQ+", "Clock", void 0);
      t("FixedClock", function () {
        function t(t, e, s) {
          if (this.stepSeconds = void 0, this.accumulator = 0, this._tick = 0, this._paused = !1, this.hz = t, this.maxCatchupSteps = e, this.onStep = s, !Number.isFinite(t) || t <= 0 || !Number.isInteger(e) || e < 1) throw new Error("Clock configuration invalid");
          this.stepSeconds = 1 / t;
        }
        var s = t.prototype;
        return s.pause = function () {
          this._paused = !0, this.accumulator = 0;
        }, s.resume = function () {
          this._paused = !1, this.accumulator = 0;
        }, s.reset = function () {
          this.accumulator = 0, this._tick = 0;
        }, s.update = function (t) {
          if (this._paused) return {
            steps: 0,
            pausedForBacklog: !1,
            tick: this._tick,
            droppedSeconds: 0,
            overloaded: !1
          };
          if (!Number.isFinite(t) || t < 0) throw new Error("render delta must be finite and non-negative");
          this.accumulator += t;
          for (var e = 0, s = !1; this.accumulator + 1e-12 >= this.stepSeconds && e < this.maxCatchupSteps;) {
            var i = this.onStep();
            if (this.accumulator -= this.stepSeconds, !1 === i) {
              this.pause(), s = !0;
              break;
            }
            if (this._tick++, e++, this._paused) break;
          }
          if (s || this._paused) return {
            steps: e,
            pausedForBacklog: !1,
            tick: this._tick,
            droppedSeconds: 0,
            overloaded: !1
          };
          var c = this.accumulator + 1e-12 >= this.stepSeconds,
            o = 0;
          c && (o = Math.floor((this.accumulator + 1e-12) / this.stepSeconds) * this.stepSeconds, this.accumulator -= o, this.accumulator < 0 && this.accumulator > -1e-10 && (this.accumulator = 0));
          return {
            steps: e,
            pausedForBacklog: !1,
            tick: this._tick,
            droppedSeconds: o,
            overloaded: c
          };
        }, e(t, [{
          key: "tick",
          get: function get() {
            return this._tick;
          }
        }, {
          key: "paused",
          get: function get() {
            return this._paused;
          }
        }]), t;
      }());
      s._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CloneState.ts", ["cc"], function (e) {
  var t;
  return {
    setters: [function (e) {
      t = e.cclegacy;
    }],
    execute: function execute() {
      e("cloneState", function (e) {
        if ("function" == typeof structuredClone) return structuredClone(e);
        var t = new Map();
        return function e(r) {
          if (null === r || "object" != _typeof(r)) return r;
          if (t.has(r)) return t.get(r);
          var n = Array.isArray(r) ? [] : {};
          t.set(r, n);
          for (var u = 0, c = Object.keys(r); u < c.length; u++) {
            var o = c[u];
            n[o] = e(r[o]);
          }
          return n;
        }(e);
      }), t._RF.push({}, "e404dVHROBHz6IygLWyefNM", "CloneState", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CocosPhysicsAdapter.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./CupGeometry.ts"], function (e) {
  var t, i, s, o, n, r, l, a, d, c, u, h, p, y, v;
  return {
    setters: [function (e) {
      t = e.createForOfIteratorHelperLoose, i = e["extends"], s = e.createClass;
    }, function (e) {
      o = e.cclegacy, n = e.Node, r = e.RigidBody2D, l = e.ERigidBody2DType, a = e.BoxCollider2D, d = e.Size, c = e.Vec2, u = e.CircleCollider2D, h = e.PhysicsSystem2D, p = e.Contact2DType, y = e.Vec3;
    }, function (e) {
      v = e.CupGeometry;
    }],
    execute: function execute() {
      o._RF.push({}, "f5fceJcnHJbl6TyEY6S1/1V", "CocosPhysicsAdapter", void 0);
      var f = Object.freeze([]);
      e("CocosPhysicsAdapter", function () {
        function e(t, i, s) {
          this.bodies = new Map(), this.colliderOwners = new Map(), this.activeContacts = new Map(), this.staticNodes = [], this.listenerDisposers = [], this.samplePosition = new y(), this.stepTimings = {
            syncToPhysics: 0,
            physicsStep: 0,
            syncFromPhysics: 0,
            velocityClamp: 0
          }, this.timingDiagnostics = !1, this.contactBeginCount = 0, this.contactEndCount = 0, this.disposed = !1, this.generation = e.nextGeneration++, this._stepCount = 0, this.cupShape = null, this.cupOffsetXDu = 0, this.cupBodies = [], this.root = t, this.rules = i, this.mapper = s;
        }
        var o = e.prototype;
        return o.setTimingDiagnostics = function (e) {
          this.timingDiagnostics = e;
        }, o.createCup = function (e, t) {
          var i;
          void 0 === t && (t = 0), this.assertAlive(), this.destroyCup();
          var s = null == (i = this.rules.stages.find(function (t) {
            return t.id === e;
          })) ? void 0 : i.cup_width_scale;
          if (void 0 === s) throw new Error("Unknown stage: " + e);
          var o = this.rules.cup;
          this.cupOffsetXDu = t, this.cupShape = v.build({
            centerXDu: o.center_x_du + t,
            bottomYDu: o.inner_bottom_y_du,
            topYDu: o.inner_top_y_du,
            bottomWidthDu: o.bottom_width_du,
            topWidthDu: o.top_width_du,
            widthScale: s
          });
          for (var c = 0; c < this.cupShape.segments.length; c++) {
            var u = this.cupShape.segments[c],
              h = new n("CupBoundary-" + u.kind);
            this.root.addChild(h), h.setPosition(this.mapper.duToCocosWorld(u.center.x - this.rules.viewport.width_du / 2), this.mapper.duToCocosWorld(u.center.y - this.rules.viewport.height_du / 2), 0), h.angle = u.angleDeg;
            var p = h.addComponent(r);
            p.type = l.Kinematic, p.enabledContactListener = !0, p.gravityScale = 0;
            var y = h.addComponent(a);
            y.size = new d(this.mapper.duToCocosWorld(u.lengthDu), this.mapper.duToCocosWorld(u.thicknessDu)), y.friction = this.rules.physics.friction, y.restitution = this.rules.physics.restitution, y.apply(), this.staticNodes.push(h), this.cupBodies.push(p), this.installContacts(y, null, "listener:cup:" + c);
          }
        }, o.setCupVelocityX = function (e) {
          if (this.assertAlive(), !Number.isFinite(e)) throw new Error("Cup velocity must be finite");
          for (var i, s = this.mapper.duVelocityToBox2D(e), o = t(this.cupBodies); !(i = o()).done;) {
            i.value.linearVelocity = new c(s, 0);
          }
        }, o.getCupOffsetX = function () {
          var e = this.staticNodes[0];
          return e ? this.mapper.cocosWorldToDu(e.position.x) + this.rules.viewport.width_du / 2 - this.rules.cup.center_x_du : this.cupOffsetXDu;
        }, o.createBody = function (e) {
          var t, i, s;
          if (this.assertAlive(), this.bodies.has(e.entityId)) throw new Error("Entity " + e.entityId + " already exists");
          var o = this.rules.ingredients.find(function (t) {
            return t.level === e.level;
          });
          if (!o || Math.abs(o.radius_du - e.radiusDu) > 1e-8) throw new Error("Level/radius mismatch for entity " + e.entityId);
          if (![e.positionDu.x, e.positionDu.y, e.velocityDuPerSecond.x, e.velocityDuPerSecond.y].every(Number.isFinite)) throw new Error("Body state must be finite");
          var a = new n("Ingredient-" + e.entityId);
          this.root.addChild(a), a.setPosition(this.mapper.duToCocosWorld(e.positionDu.x - this.rules.viewport.width_du / 2), this.mapper.duToCocosWorld(e.positionDu.y - this.rules.viewport.height_du / 2), 0);
          var d = null != (t = e.angleRadians) ? t : 0;
          if (!Number.isFinite(d) || !Number.isFinite(null != (i = e.angularVelocity) ? i : 0)) throw new Error("Body rotation state must be finite");
          a.angle = 180 * d / Math.PI;
          var h = a.addComponent(r);
          h.type = l.Dynamic, h.enabledContactListener = !0, !1 === e.enabledInitially && (h.enabled = !1), h.linearDamping = this.rules.physics.linear_damping, h.angularDamping = this.rules.physics.angular_damping, h.allowSleep = this.rules.physics.sleep, h.awakeOnLoad = !0;
          var p = a.addComponent(u);
          p.radius = this.mapper.duToCocosWorld(e.radiusDu), p.density = this.rules.physics.density_relative, p.friction = this.rules.physics.friction, p.restitution = this.rules.physics.restitution, p.apply(), h.linearVelocity = new c(this.mapper.duVelocityToBox2D(e.velocityDuPerSecond.x), this.mapper.duVelocityToBox2D(e.velocityDuPerSecond.y)), h.angularVelocity = null != (s = e.angularVelocity) ? s : 0, this.bodies.set(e.entityId, {
            node: a,
            body: h,
            collider: p,
            radiusDu: e.radiusDu
          }), this.colliderOwners.set(p, {
            entityId: e.entityId,
            boundaryIndex: null
          }), this.installContacts(p, e.entityId);
        }, o.destroyBody = function (e) {
          var t = this.bodies.get(e);
          t && (t.body.enabled = !1, this.colliderOwners["delete"](t.collider), this.removeListener("listener:" + e), this.removeContactsFor(e), this.bodies["delete"](e), t.node.destroy());
        }, o.replaceParentsWithChild = function (e, t) {
          if (this.assertAlive(), e[0] === e[1] || !this.bodies.has(e[0]) || !this.bodies.has(e[1]) || this.bodies.has(t.entityId)) return {
            ok: !1,
            error: {
              code: "MERGE_OWNER_INVALID",
              message: "合成父对象或子ID无效",
              retryable: !1
            }
          };
          var s,
            o = this.bodies.get(e[0]),
            n = this.bodies.get(e[1]);
          try {
            return this.createBody(i({}, t, {
              enabledInitially: !1
            })), s = this.bodies.get(t.entityId), o.body.enabled = !1, n.body.enabled = !1, s.body.enabled = !0, this.removeBodyRecord(e[0], o), this.removeBodyRecord(e[1], n), o.node.destroy(), n.node.destroy(), {
              ok: !0,
              data: void 0
            };
          } catch (i) {
            return s && (s.body.enabled = !1, this.removeBodyRecord(t.entityId, s), s.node.destroy()), o.node.isValid && (o.body.enabled = !0, this.restoreBodyRecord(e[0], o)), n.node.isValid && (n.body.enabled = !0, this.restoreBodyRecord(e[1], n)), {
              ok: !1,
              error: {
                code: "MERGE_REPLACE_ROLLED_BACK",
                message: String(i),
                retryable: !0
              }
            };
          }
        }, o.stepFixed = function () {
          this.assertAlive();
          var e = h.instance,
            i = this.timingDiagnostics ? performance.now() : 0;
          e.physicsWorld.syncSceneToPhysics(), this.timingDiagnostics && (this.stepTimings.syncToPhysics = performance.now() - i, i = performance.now()), e.step(1 / this.rules.physics.fixed_hz), this.timingDiagnostics && (this.stepTimings.physicsStep = performance.now() - i, i = performance.now()), this._stepCount++, e.physicsWorld.syncPhysicsToScene(), this.timingDiagnostics && (this.stepTimings.syncFromPhysics = performance.now() - i, i = performance.now());
          for (var s, o = t(this.bodies.values()); !(s = o()).done;) {
            var n = s.value,
              r = n.body.linearVelocity,
              l = Math.hypot(r.x, r.y),
              a = this.mapper.box2DVelocityToDu(l),
              d = this.rules.physics.max_linear_speed * this.rules.viewport.du_per_spec_physics_unit;
            if (a > d) {
              var u = d / a;
              n.body.linearVelocity = new c(r.x * u, r.y * u);
            }
            var p = this.rules.physics.max_angular_speed;
            Math.abs(n.body.angularVelocity) > p && (n.body.angularVelocity = Math.sign(n.body.angularVelocity) * p);
          }
          this.timingDiagnostics && (this.stepTimings.velocityClamp = performance.now() - i);
        }, o.visitBodySamples = function (e) {
          this.assertAlive();
          for (var i, s = t(this.bodies); !(i = s()).done;) {
            var o = i.value,
              n = o[0],
              r = o[1];
            r.node.getPosition(this.samplePosition);
            var l = r.body.linearVelocity;
            e(n, r.radiusDu, this.mapper.cocosWorldToDu(this.samplePosition.x) + this.rules.viewport.width_du / 2, this.mapper.cocosWorldToDu(this.samplePosition.y) + this.rules.viewport.height_du / 2, this.mapper.box2DVelocityToDu(l.x), this.mapper.box2DVelocityToDu(l.y), r.body.isAwake());
          }
        }, o.applyHorizontalAcceleration = function (e, t) {
          var i = this.bodies.get(e);
          if (i) {
            var s = t * this.rules.viewport.du_per_spec_physics_unit,
              o = this.mapper.duAccelerationToBox2D(s) * i.body.getMass();
            i.body.applyForceToCenter(new c(o, 0), !0);
          }
        }, o.getContacts = function () {
          return Array.from(this.activeContacts.values(), function (e) {
            return i({}, e);
          });
        }, o.getBody = function (e) {
          var t = this.bodies.get(e);
          if (t) {
            var i = t.node.position,
              s = t.body.linearVelocity;
            return {
              entityId: e,
              positionDu: {
                x: this.mapper.cocosWorldToDu(i.x) + this.rules.viewport.width_du / 2,
                y: this.mapper.cocosWorldToDu(i.y) + this.rules.viewport.height_du / 2
              },
              velocityDuPerSecond: {
                x: this.mapper.box2DVelocityToDu(s.x),
                y: this.mapper.box2DVelocityToDu(s.y)
              },
              angleRadians: t.node.angle * Math.PI / 180,
              angularVelocity: t.body.angularVelocity,
              sleeping: !t.body.isAwake()
            };
          }
        }, o.restoreBodies = function (e) {
          for (var i = this, s = 0, o = Array.from(this.bodies.keys()); s < o.length; s++) {
            var n = o[s];
            this.destroyBody(n);
          }
          for (var r, l = function l() {
              var e = r.value,
                t = i.rules.ingredients.find(function (t) {
                  return t.level === e.level;
                });
              if (!t) throw new Error("Unknown level " + e.level);
              i.createBody({
                entityId: e.entityId,
                level: e.level,
                radiusDu: t.radius_du,
                positionDu: e.positionDu,
                velocityDuPerSecond: e.velocityDuPerSecond
              });
              var s = i.bodies.get(e.entityId);
              s.node.angle = 180 * e.angleRadians / Math.PI, s.body.angularVelocity = e.angularVelocity, e.sleeping && s.body.sleep();
            }, a = t(e); !(r = a()).done;) l();
        }, o.canSpawn = function (e, t) {
          return null === this.spawnRejectionReason(e, t);
        }, o.spawnRejectionReason = function (e, i) {
          var s,
            o = null == (s = this.rules.ingredients.find(function (t) {
              return t.level === e;
            })) ? void 0 : s.radius_du;
          if (!o || !this.cupShape) return "invalid_level_or_cup";
          if (i - o < this.cupShape.spawnRange.minX || i + o > this.cupShape.spawnRange.maxX) return "outside_legal_interval";
          for (var n, r = this.rules.cup.spawn_y_du, l = t(this.bodies); !(n = l()).done;) {
            var a = n.value,
              d = a[0],
              c = a[1],
              u = this.getBody(d);
            if (Math.hypot(u.positionDu.x - i, u.positionDu.y - r) < c.radiusDu + o) return "blocked_by_entity:" + d;
          }
          return null;
        }, o.dispose = function () {
          if (!this.disposed) {
            for (var e = 0, i = Array.from(this.bodies.keys()); e < i.length; e++) {
              var s = i[e];
              this.destroyBody(s);
            }
            this.destroyCup(), this.activeContacts.clear(), this.colliderOwners.clear();
            for (var o, n = t(this.listenerDisposers.slice()); !(o = n()).done;) {
              var r = o.value;
              r();
            }
            this.listenerDisposers.length = 0, this.disposed = !0;
          }
        }, o.installContacts = function (e, t, i) {
          var s = this;
          void 0 === i && (i = "listener:" + t);
          var o = null === t ? this.staticNodes.findIndex(function (t) {
              return t === e.node;
            }) : null,
            n = {
              entityId: t,
              boundaryIndex: null !== o && o >= 0 ? o : null
            };
          this.colliderOwners.set(e, n);
          var r = this.generation,
            l = function l(i, o, _l) {
              s.disposed || r !== s.generation || s.colliderOwners.get(e) !== n || s.onContact(!0, t, i, o, _l);
            },
            a = function a(i, o, l) {
              s.disposed || r !== s.generation || s.colliderOwners.get(e) !== n || s.onContact(!1, t, i, o, l);
            };
          e.on(p.BEGIN_CONTACT, l), e.on(p.END_CONTACT, a);
          var d = function d() {
            e.off(p.BEGIN_CONTACT, l), e.off(p.END_CONTACT, a), s.colliderOwners["delete"](e);
          };
          Object.defineProperty(d, "name", {
            value: i
          }), this.listenerDisposers.push(d);
        }, o.onContact = function (e, t, i, s, o) {
          var n,
            r = this.colliderOwners.get(i),
            l = this.colliderOwners.get(s);
          if (r && l) {
            var a = this.idFromCollider(s);
            if (null !== t || null !== a) {
              var d = null === t ? a : null === a ? t : Math.min(t, a),
                u = null === t || null === a ? null : Math.max(t, a),
                h = null === u && null != (n = (null === t ? r : l).boundaryIndex) ? n : -1;
              if (!(null === u && h < 0)) {
                var p = null === u ? d + "|cup:" + h : Math.min(d, u) + "|" + Math.max(d, u);
                if (e) {
                  var y = 0;
                  if (null != o && o.colliderA && o.colliderB) {
                    var v,
                      f,
                      g,
                      m,
                      b = o.getWorldManifold().normal,
                      D = this.idFromCollider(o.colliderA),
                      C = this.idFromCollider(o.colliderB),
                      w = null === D ? new c(0, 0) : null != (v = null == (f = this.bodies.get(D)) ? void 0 : f.body.linearVelocity) ? v : new c(0, 0),
                      _ = null === C ? new c(0, 0) : null != (g = null == (m = this.bodies.get(C)) ? void 0 : m.body.linearVelocity) ? g : new c(0, 0),
                      x = (_.x - w.x) * b.x + (_.y - w.y) * b.y;
                    y = this.mapper.box2DVelocityToDu(Math.abs(x));
                  }
                  this.activeContacts.has(p) || this.contactBeginCount++, this.activeContacts.set(p, {
                    contactId: p,
                    firstId: d,
                    secondId: u,
                    normalSpeed: y
                  });
                } else this.activeContacts["delete"](p) && this.contactEndCount++;
              }
            }
          }
        }, o.idFromCollider = function (e) {
          var t, i;
          return null != (t = null == (i = this.colliderOwners.get(e)) ? void 0 : i.entityId) ? t : null;
        }, o.removeContactsFor = function (e) {
          for (var i, s = t(this.activeContacts); !(i = s()).done;) {
            var o = i.value,
              n = o[0],
              r = o[1];
            r.firstId !== e && r.secondId !== e || this.activeContacts["delete"](n) && this.contactEndCount++;
          }
        }, o.removeBodyRecord = function (e, t) {
          this.colliderOwners["delete"](t.collider), this.removeListener("listener:" + e), this.removeContactsFor(e), this.bodies.get(e) === t && this.bodies["delete"](e);
        }, o.restoreBodyRecord = function (e, t) {
          this.bodies.set(e, t), this.colliderOwners.set(t.collider, {
            entityId: e,
            boundaryIndex: null
          }), this.listenerDisposers.some(function (t) {
            return t.name === "listener:" + e;
          }) || this.installContacts(t.collider, e);
        }, o.destroyCup = function () {
          for (var e = 0; e < this.staticNodes.length; e++) this.removeListener("listener:cup:" + e), this.staticNodes[e].destroy();
          for (var i, s = t(this.activeContacts); !(i = s()).done;) {
            var o = i.value,
              n = o[0];
            null === o[1].secondId && this.activeContacts["delete"](n);
          }
          this.staticNodes.length = 0, this.cupBodies.length = 0, this.cupShape = null, this.cupOffsetXDu = 0;
        }, o.assertAlive = function () {
          if (this.disposed) throw new Error("Physics adapter has been disposed");
        }, o.removeListener = function (e) {
          var t = this.listenerDisposers.findIndex(function (t) {
            return t.name === e;
          });
          t >= 0 && (this.listenerDisposers[t](), this.listenerDisposers.splice(t, 1));
        }, s(e, [{
          key: "entityCount",
          get: function get() {
            return this.bodies.size;
          }
        }, {
          key: "contactCount",
          get: function get() {
            return this.activeContacts.size;
          }
        }, {
          key: "listenerCount",
          get: function get() {
            return this.listenerDisposers.length;
          }
        }, {
          key: "stepCount",
          get: function get() {
            return this._stepCount;
          }
        }, {
          key: "cupSegments",
          get: function get() {
            var e, t;
            return null != (e = null == (t = this.cupShape) ? void 0 : t.segments) ? e : f;
          }
        }, {
          key: "contactBeginEvents",
          get: function get() {
            return this.contactBeginCount;
          }
        }, {
          key: "contactEndEvents",
          get: function get() {
            return this.contactEndCount;
          }
        }, {
          key: "wallContactProjectionMarginDu",
          get: function get() {
            return this.mapper.box2DMetersToDu(.024);
          }
        }, {
          key: "lastStepTimings",
          get: function get() {
            return this.stepTimings;
          }
        }]), e;
      }()).nextGeneration = 1, o._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ConfigLoader.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (e) {
  var r, i;
  return {
    setters: [function (e) {
      r = e.createForOfIteratorHelperLoose;
    }, function (e) {
      i = e.cclegacy;
    }],
    execute: function execute() {
      i._RF.push({}, "847e3iYk5hRnp2VlGoeK4jd", "ConfigLoader", void 0);
      e("ConfigLoader", function () {
        function e() {}
        return e.validate = function (e) {
          try {
            var i;
            if (!e || "object" != _typeof(e)) throw new Error("根配置必须是对象");
            var t = e,
              s = function s(e, r, i, t) {
                if (void 0 === i && (i = -1 / 0), void 0 === t && (t = 1 / 0), "number" != typeof e || !Number.isFinite(e) || e < i || e > t) throw new Error(r + " 必须是 " + i + ".." + t + " 范围内的有限数值");
              },
              o = function o(e, r) {
                if (null == e) throw new Error("缺少配置项 " + r);
              };
            o(t.design_rules_version, "design_rules_version");
            for (var n, a = r(["viewport", "physics", "cup", "cup_motion", "shake", "auto_drop", "spawn_jitter", "drop", "ingredients", "stages"]); !(n = a()).done;) {
              var _ = n.value;
              o(t[_], _);
            }
            if (!t.physics.gravity || !t.drop || !Array.isArray(t.stages)) throw new Error("physics.gravity、drop、stages结构无效");
            if ("bottom_left" !== (null == (i = t.viewport) ? void 0 : i.world_origin)) throw new Error("viewport.world_origin 必须为 bottom_left");
            s(t.viewport.width_du, "viewport.width_du", 1), s(t.viewport.height_du, "viewport.height_du", 1), s(t.viewport.du_per_spec_physics_unit, "viewport.du_per_spec_physics_unit", 1e-4), s(t.physics.fixed_hz, "physics.fixed_hz", 60, 60);
            for (var d = 0, p = Object.entries({
                "physics.gravity.x": t.physics.gravity.x,
                "physics.gravity.y": t.physics.gravity.y,
                "physics.density_relative": t.physics.density_relative,
                "physics.friction": t.physics.friction,
                "physics.restitution": t.physics.restitution,
                "physics.linear_damping": t.physics.linear_damping,
                "physics.angular_damping": t.physics.angular_damping,
                "physics.max_linear_speed": t.physics.max_linear_speed,
                "physics.max_angular_speed": t.physics.max_angular_speed,
                "physics.velocity_iterations": t.physics.velocity_iterations,
                "physics.position_iterations": t.physics.position_iterations,
                "physics.max_catchup_steps": t.physics.max_catchup_steps
              }); d < p.length; d++) {
              var u = p[d],
                c = u[0];
              s(u[1], c, c.endsWith("gravity.x") || c.endsWith("gravity.y") ? -1 / 0 : 0);
            }
            if (t.physics.density_relative <= 0) throw new Error("physics.density_relative 必须大于0");
            if (t.physics.max_linear_speed <= 0 || t.physics.max_angular_speed <= 0) throw new Error("physics速度上限必须大于0");
            if (t.physics.restitution > 1) throw new Error("physics.restitution 必须在0..1之间");
            for (var h, l = r(["velocity_iterations", "position_iterations", "max_catchup_steps"]); !(h = l()).done;) {
              var w = h.value;
              if (!Number.isInteger(t.physics[w]) || t.physics[w] < 1) throw new Error("physics." + w + " 必须是正整数");
            }
            if ("circle" !== t.physics.shape) throw new Error("physics.shape 当前阶段必须为 circle");
            if (!Array.isArray(t.ingredients) || 9 !== t.ingredients.length) throw new Error("ingredients 必须正好包含九级");
            for (var y, v = new Set(), g = new Set(), f = r(t.ingredients); !(y = f()).done;) {
              var m = y.value;
              if (!m || "string" != typeof m.id || !m.id.trim() || v.has(m.id)) throw new Error("小料 ID 缺失或重复: " + (null == m ? void 0 : m.id));
              if (!Number.isInteger(m.level) || m.level < 1 || m.level > 9 || g.has(m.level)) throw new Error("小料等级缺失或重复: " + m.level);
              v.add(m.id), g.add(m.level), s(m.radius_du, "ingredients." + m.id + ".radius_du", .01), s(m.merge_score, "ingredients." + m.id + ".merge_score", 0), s(m.units, "ingredients." + m.id + ".units", 1);
            }
            if (!Array.isArray(t.drop.spawn_levels) || 0 === t.drop.spawn_levels.length) throw new Error("drop.spawn_levels 不能为空");
            for (var E, b = 0, x = new Set(), k = r(t.drop.spawn_levels); !(E = k()).done;) {
              var j = E.value;
              if (!g.has(j.level)) throw new Error("出料等级 " + j.level + " 不存在");
              if (x.has(j.level)) throw new Error("出料等级重复: " + j.level);
              x.add(j.level), s(j.weight, "drop.spawn_levels." + j.level + ".weight", 0), b += j.weight;
            }
            if (Math.abs(b - 100) > 1e-9) throw new Error("出料权重合计必须为100，当前为 " + b);
            for (var A = 0, I = Object.entries({
                "cup.center_x_du": t.cup.center_x_du,
                "cup.inner_bottom_y_du": t.cup.inner_bottom_y_du,
                "cup.inner_top_y_du": t.cup.inner_top_y_du,
                "cup.bottom_width_du": t.cup.bottom_width_du,
                "cup.top_width_du": t.cup.top_width_du,
                "cup.spawn_y_du": t.cup.spawn_y_du,
                "cup.danger_line_y_du": t.cup.danger_line_y_du
              }); A < I.length; A++) {
              var N = I[A],
                O = N[0];
              s(N[1], O, 0);
            }
            if (t.cup.inner_top_y_du <= t.cup.inner_bottom_y_du || t.cup.bottom_width_du <= 0 || t.cup.top_width_du <= 0) throw new Error("杯体高度和宽度必须为正且高度递增");
            if (t.cup.spawn_y_du > t.viewport.height_du || t.cup.danger_line_y_du > t.viewport.height_du) throw new Error("投放高度和危险线必须位于设计视口内");
            for (var S = 0, F = Object.entries(t.cup_motion); S < F.length; S++) {
              var L = F[S],
                z = L[0];
              s(L[1], "cup_motion." + z, 0);
            }
            if (t.cup_motion.max_offset_du <= 0 || t.cup_motion.max_speed_du_per_second <= 0 || t.cup_motion.acceleration_du_per_second2 <= 0) throw new Error("cup_motion参数必须大于0");
            for (var C, M = r(["duration_seconds", "cooldown_seconds", "acceleration_amplitude", "frequency_hz", "visual_offset_max_du"]); !(C = M()).done;) {
              var D = C.value;
              s(t.shake[D], "shake." + D, 0);
            }
            if ("boolean" != typeof t.shake.guaranteed_merge) throw new Error("shake.guaranteed_merge必须是boolean");
            if (t.shake.duration_seconds <= 0 || t.shake.frequency_hz <= 0 || t.shake.visual_offset_max_du > 6) throw new Error("shake参数超出已验证边界");
            for (var R = 0, q = Object.entries(t.auto_drop); R < q.length; R++) {
              var G = q[R],
                H = G[0],
                V = G[1];
              if (s(V, "auto_drop." + H, 1), !Number.isSafeInteger(V)) throw new Error("auto_drop." + H + "必须是安全整数");
            }
            for (var W, B = r(["x_offsets_du", "vx_du_per_second"]); !(W = B()).done;) {
              var K = W.value,
                P = t.spawn_jitter[K];
              if (!Array.isArray(P) || P.length < 2 || P.some(function (e) {
                return !Number.isFinite(e);
              })) throw new Error("spawn_jitter." + K + "无效");
            }
            if (!Array.isArray(t.stages) || t.stages.length < 1) throw new Error("stages 不能为空");
            for (var Y, J = new Set(), Q = Math.max.apply(Math, t.ingredients.map(function (e) {
                return e.radius_du;
              })), T = r(t.stages); !(Y = T()).done;) {
              var U = Y.value;
              if (!U.id || J.has(U.id)) throw new Error("stage ID缺失或重复: " + U.id);
              if (J.add(U.id), s(U.cup_width_scale, "stages." + U.id + ".cup_width_scale", .01, 4), "classic" === U.id && t.cup.bottom_width_du * U.cup_width_scale < 2 * Q) throw new Error("stages." + U.id + " 杯底放不下最高级小料");
              for (var X = 0, Z = [t.cup.bottom_width_du, t.cup.top_width_du]; X < Z.length; X++) {
                var $ = Z[X];
                if (t.cup.center_x_du - $ * U.cup_width_scale / 2 < 0 || t.cup.center_x_du + $ * U.cup_width_scale / 2 > t.viewport.width_du) throw new Error("stages." + U.id + " 杯体宽度超出设计视口");
              }
            }
            return {
              ok: !0,
              data: Object.freeze(t)
            };
          } catch (e) {
            return {
              ok: !1,
              error: {
                code: "CONFIG_INVALID",
                message: e instanceof Error ? e.message : String(e),
                retryable: !0
              }
            };
          }
        }, e;
      }());
      i._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CoordinateMapper.ts", ["cc"], function (t) {
  var i;
  return {
    setters: [function (t) {
      i = t.cclegacy;
    }],
    execute: function execute() {
      i._RF.push({}, "bfbe01LQ45Vto48dFD9VaYM", "CoordinateMapper", void 0);
      t("CoordinateMapper", function () {
        function t(t, i, e, o) {
          if (this.widthDu = t, this.heightDu = i, this.duPerSpecPhysicsUnit = e, this.cocosPtmRatio = o, ![t, i, e, o].every(Number.isFinite) || t <= 0 || i <= 0 || e <= 0 || o <= 0) throw new Error("Invalid coordinate scale");
        }
        var i = t.prototype;
        return i.screenToDu = function (t, i, e) {
          var o = Math.min(i / this.widthDu, e / this.heightDu),
            n = (i - this.widthDu * o) / 2,
            c = (e - this.heightDu * o) / 2;
          return {
            x: (t.x - n) / o,
            y: (t.y - c) / o
          };
        }, i.uiTopLeftToDu = function (t, i, e) {
          return this.screenToDu({
            x: t.x,
            y: e - t.y
          }, i, e);
        }, i.duToScreen = function (t, i, e) {
          var o = Math.min(i / this.widthDu, e / this.heightDu),
            n = (i - this.widthDu * o) / 2,
            c = (e - this.heightDu * o) / 2;
          return {
            x: n + t.x * o,
            y: c + (this.heightDu - t.y) * o
          };
        }, i.specAccelerationToDu = function (t) {
          return t * this.duPerSpecPhysicsUnit;
        }, i.duVelocityToSpec = function (t) {
          return t / this.duPerSpecPhysicsUnit;
        }, i.duVelocityToBox2D = function (t) {
          return t / this.duPerSpecPhysicsUnit;
        }, i.box2DVelocityToDu = function (t) {
          return t * this.duPerSpecPhysicsUnit;
        }, i.duAccelerationToBox2D = function (t) {
          return t / this.duPerSpecPhysicsUnit;
        }, i.duToCocosWorld = function (t) {
          return t / this.duPerSpecPhysicsUnit * this.cocosPtmRatio;
        }, i.cocosWorldToDu = function (t) {
          return t / this.cocosPtmRatio * this.duPerSpecPhysicsUnit;
        }, i.duToBox2DMeters = function (t) {
          return t / this.duPerSpecPhysicsUnit;
        }, i.box2DMetersToDu = function (t) {
          return t * this.duPerSpecPhysicsUnit;
        }, i.specAccelerationToCocosGravityApi = function (t) {
          return t * this.cocosPtmRatio;
        }, t;
      }());
      i._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CupGeometry.ts", ["cc"], function (t) {
  var e;
  return {
    setters: [function (t) {
      e = t.cclegacy;
    }],
    execute: function execute() {
      e._RF.push({}, "61700B9mI5btpo7zK6vVL6v", "CupGeometry", void 0);
      t("CupGeometry", function () {
        function t() {}
        return t.build = function (t) {
          var e,
            n = t.centerXDu,
            o = t.bottomYDu,
            r = t.topYDu,
            i = t.widthScale,
            u = null != (e = t.wallThicknessDu) ? e : 16;
          if (![n, o, r, t.bottomWidthDu, t.topWidthDu, i, u].every(Number.isFinite) || r <= o || i <= 0 || u <= 0) throw new Error("Invalid cup geometry");
          var y = t.bottomWidthDu * i,
            h = t.topWidthDu * i,
            a = {
              x: n - y / 2,
              y: o
            },
            c = {
              x: n + y / 2,
              y: o
            },
            x = {
              x: n - h / 2,
              y: r
            },
            p = {
              x: n + h / 2,
              y: r
            },
            m = function m(t, e, n, o) {
              var r = n.x - e.x,
                i = n.y - e.y,
                y = Math.hypot(r, i);
              return {
                kind: t,
                innerStart: e,
                innerEnd: n,
                center: {
                  x: (e.x + n.x) / 2 + o.x * u / 2,
                  y: (e.y + n.y) / 2 + o.y * u / 2
                },
                lengthDu: y + u,
                angleDeg: 180 * Math.atan2(i, r) / Math.PI,
                thicknessDu: u,
                outward: o
              };
            },
            s = x.x - a.x,
            l = r - o,
            d = Math.hypot(s, l),
            f = {
              x: -l / d,
              y: s / d
            },
            g = p.x - c.x,
            D = p.y - c.y,
            v = Math.hypot(g, D),
            b = {
              x: D / v,
              y: -g / v
            };
          return {
            leftBottom: a,
            rightBottom: c,
            leftTop: x,
            rightTop: p,
            innerWidthAtBottom: y,
            innerWidthAtTop: h,
            segments: [m("bottom", a, c, {
              x: 0,
              y: -1
            }), m("left", a, x, f), m("right", c, p, b)],
            spawnRange: {
              minX: n - h / 2,
              maxX: n + h / 2
            }
          };
        }, t;
      }());
      e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/CupSweepProbe.ts", ["cc"], function (t) {
  var r;
  return {
    setters: [function (t) {
      r = t.cclegacy;
    }],
    execute: function execute() {
      t({
        cupWallHandCheck: function cupWallHandCheck(t, r, n) {
          var a = t.innerEnd.x - t.innerStart.x,
            e = t.innerEnd.y - t.innerStart.y,
            i = Math.hypot(a, e),
            u = -t.outward.x,
            h = -t.outward.y,
            o = (r.x - t.innerStart.x) * a / i + (r.y - t.innerStart.y) * e / i,
            y = (r.x - t.innerStart.x) * u + (r.y - t.innerStart.y) * h;
          return o >= 0 && o <= i ? y - n : Number.POSITIVE_INFINITY;
        },
        sampleCupSegmentSweep: function sampleCupSegmentSweep(t, r, y, M, c, s, x, S) {
          var E = t.innerStart.x,
            f = t.innerStart.y,
            p = t.innerEnd.x - E,
            v = t.innerEnd.y - f,
            P = Math.hypot(p, v),
            m = p / P,
            d = v / P,
            _ = -t.outward.x,
            C = -t.outward.y,
            I = r - E,
            b = y - f,
            w = I * m + b * d,
            N = I * _ + b * C,
            O = t.thicknessDu,
            l = (P + O) / 2,
            R = w - P / 2,
            B = N + O / 2,
            T = Math.abs(R) - l,
            k = Math.abs(B) - O / 2,
            F = Math.max(T, 0),
            U = Math.max(k, 0),
            g = Math.hypot(F, U) + Math.min(Math.max(T, k), 0),
            D = w,
            A = N,
            H = w - P,
            V = N;
          S[n] = w >= 0 && w <= P ? N - s : Number.POSITIVE_INFINITY, S[a] = g - s, S[e] = Math.min(Math.hypot(D, A), Math.hypot(H, V)) - s, S[i] = x && function (t, r, n, a, e, i) {
            var u = t.innerStart.x,
              y = t.innerStart.y,
              M = t.innerEnd.x - u,
              c = t.innerEnd.y - y,
              s = Math.hypot(M, c),
              x = M / s,
              S = c / s,
              E = -t.outward.x,
              f = -t.outward.y,
              p = t.thicknessDu,
              v = (r - u) * x + (n - y) * S,
              P = (r - u) * E + (n - y) * f,
              m = (a - u) * x + (e - y) * S,
              d = (a - u) * E + (e - y) * f,
              _ = -p / 2,
              C = s + p / 2,
              I = -p,
              b = 0;
            return !(!h(v, P, m, d, _ - i, C + i, I, b) && !h(v, P, m, d, _, C, I - i, b + i)) || o(v, P, m, d, _, I, i) || o(v, P, m, d, _, b, i) || o(v, P, m, d, C, I, i) || o(v, P, m, d, C, b, i);
          }(t, M, c, r, y, s) ? 1 : 0;
          var W = !1;
          if (x && 1 === S[i]) {
            var Y = (M - E) * m + (c - f) * d,
              q = (M - E) * _ + (c - f) * C;
            W = "bottom" === t.kind ? c >= f && y < f - s : q >= 0 && N < -s, (Y < -O / 2 - s || Y > P + O / 2 + s) && (W = !1);
          }
          S[u] = W ? 1 : 0;
        }
      }), r._RF.push({}, "19ae1Nc2m1H+6bMlwR331CG", "CupSweepProbe", void 0);
      var n = t("CUP_PROBE_FACE", 0),
        a = t("CUP_PROBE_BOX", 1),
        e = t("CUP_PROBE_ENDPOINT", 2),
        i = t("CUP_PROBE_SWEPT", 3),
        u = t("CUP_PROBE_ESCAPE", 4);
      function h(t, r, n, a, e, i, u, h) {
        var o = 0,
          y = 1,
          M = n - t,
          c = a - r;
        if (Math.abs(M) < 1e-12) {
          if (t < e || t > i) return !1;
        } else {
          var s = (e - t) / M,
            x = (i - t) / M;
          if (s > x) {
            var S = s;
            s = x, x = S;
          }
          o = Math.max(o, s), y = Math.min(y, x);
        }
        if (Math.abs(c) < 1e-12) {
          if (r < u || r > h) return !1;
        } else {
          var E = (u - r) / c,
            f = (h - r) / c;
          if (E > f) {
            var p = E;
            E = f, f = p;
          }
          o = Math.max(o, E), y = Math.min(y, f);
        }
        return o <= y && y >= 0 && o <= 1;
      }
      function o(t, r, n, a, e, i, u) {
        var h = n - t,
          o = a - r,
          y = t - e,
          M = r - i,
          c = h * h + o * o,
          s = y * y + M * M - u * u;
        if (c < 1e-18) return s <= 0;
        var x = 2 * (y * h + M * o),
          S = x * x - 4 * c * s;
        if (S < 0) return !1;
        var E = Math.sqrt(S),
          f = (-x - E) / (2 * c),
          p = (-x + E) / (2 * c);
        return f >= 0 && f <= 1 || p >= 0 && p <= 1;
      }
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/DiagnosticRing.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, s;
  return {
    setters: [function (t) {
      e = t.createClass;
    }, function (t) {
      s = t.cclegacy;
    }],
    execute: function execute() {
      s._RF.push({}, "3544bKWpH9PoKRbT3LH0PsK", "DiagnosticRing", void 0);
      t("DiagnosticRing", function () {
        function t(t) {
          if (this.slots = void 0, this._latestSeq = 0, this._count = 0, this._overflowCount = 0, this.capacity = t, !Number.isSafeInteger(t) || t < 1) throw new Error("DIAGNOSTIC_RING_CAPACITY_INVALID");
          this.slots = new Array(t);
        }
        var s = t.prototype;
        return s.append = function (t) {
          if (this._latestSeq >= Number.MAX_SAFE_INTEGER) throw new Error("DIAGNOSTIC_SEQUENCE_OVERFLOW");
          var e = ++this._latestSeq;
          return this.slots[(e - 1) % this.capacity] = {
            seq: e,
            value: t
          }, this._count < this.capacity ? this._count++ : this._overflowCount++, this.slots[(e - 1) % this.capacity];
        }, s.page = function (t, e) {
          void 0 === t && (t = 0), void 0 === e && (e = 256);
          for (var s = Number.isSafeInteger(t) && t >= 0 ? t : 0, i = Number.isSafeInteger(e) ? Math.max(1, Math.min(this.capacity, e)) : 256, o = this.oldestSeq, n = s < o - 1 ? {
              from: s + 1,
              to: o - 1
            } : null, r = Math.max(s + 1, o), a = Math.min(this._latestSeq, r + i - 1), u = [], c = r; c <= a; c++) {
            var h = this.slots[(c - 1) % this.capacity];
            if (!h || h.seq !== c) throw new Error("DIAGNOSTIC_RING_SEQUENCE_GAP:" + c);
            u.push(h);
          }
          return {
            records: u,
            oldestSeq: o,
            latestSeq: this._latestSeq,
            nextCursor: u.length ? u[u.length - 1].seq : s,
            overflowCount: this._overflowCount,
            droppedRange: n
          };
        }, s.clear = function () {
          this.slots.fill(void 0), this._latestSeq = 0, this._count = 0, this._overflowCount = 0;
        }, e(t, [{
          key: "latestSeq",
          get: function get() {
            return this._latestSeq;
          }
        }, {
          key: "count",
          get: function get() {
            return this._count;
          }
        }, {
          key: "overflowCount",
          get: function get() {
            return this._overflowCount;
          }
        }, {
          key: "oldestSeq",
          get: function get() {
            return this._count ? this._latestSeq - this._count + 1 : this._latestSeq + 1;
          }
        }]), t;
      }());
      s._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/EffectsController.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, a, i, s, n, o, r, c, d, h, l, u, f;
  return {
    setters: [function (t) {
      e = t.createForOfIteratorHelperLoose, a = t.asyncToGenerator;
    }, function (t) {
      i = t.cclegacy, s = t.Sprite, n = t.UIOpacity, o = t.resources, r = t.ImageAsset, c = t.Texture2D, d = t.Node, h = t.UITransform, l = t.SpriteFrame, u = t.Rect, f = t.Size;
    }],
    execute: function execute() {
      i._RF.push({}, "7e6c0q2N9ZO6KQXUaG1YQOg", "EffectsController", void 0);
      var p = {
          drop: "contact_spark",
          collision: "contact_spark",
          merge: "merge_burst",
          combo: "combo_star",
          danger: "danger_glow",
          result: "settle_stars",
          tap: "tap_ring"
        },
        g = {
          contact_spark: 12,
          merge_burst: 16,
          combo_star: 12,
          danger_glow: 12,
          settle_stars: 16,
          tap_ring: 12
        },
        v = {
          drop: 8,
          collision: 8,
          merge: 5,
          combo: 2,
          danger: 1,
          result: 1,
          tap: 8
        };
      t("EffectsController", function () {
        function t(t) {
          this.atlases = new Map(), this.active = [], this.generation = 1, this.paused = !1, this.disposed = !1, this.reducedMotion = !1, this.loading = new Map(), this.catImage = null, this.catTexture = null, this.catTime = 0, this.catNode = null, this.catX = 0, this.catY = 0, this.catRequested = !1, this.root = t;
        }
        var i = t.prototype;
        return i.setReducedMotion = function (t) {
          this.reducedMotion = t;
        }, i.setPaused = function (t) {
          this.paused = t;
        }, i.prepare = function () {
          var t = a( /*#__PURE__*/_regeneratorRuntime().mark(function _callee4() {
            var t, e, a;
            return _regeneratorRuntime().wrap(function _callee4$(_context5) {
              while (1) switch (_context5.prev = _context5.next) {
                case 0:
                  t = 0, e = ["contact_spark", "merge_burst", "combo_star", "danger_glow", "settle_stars", "tap_ring"];
                case 1:
                  if (!(t < e.length)) {
                    _context5.next = 8;
                    break;
                  }
                  a = e[t];
                  _context5.next = 5;
                  return this.load(a);
                case 5:
                  t++;
                  _context5.next = 1;
                  break;
                case 8:
                case "end":
                  return _context5.stop();
              }
            }, _callee4, this);
          }));
          return function () {
            return t.apply(this, arguments);
          };
        }(), i.update = function (t) {
          var e;
          if (!(this.disposed || this.paused || !Number.isFinite(t) || t <= 0)) {
            this.catTime += t, null != (e = this.catNode) && e.isValid && this.catNode.setPosition(this.catX, this.catY + 3 * Math.sin(2.4 * this.catTime), 0);
            for (var a = this.active.length - 1; a >= 0; a--) {
              var i = this.active[a];
              if (i.node.isValid) {
                i.age += t;
                var o = Math.min(i.atlas.frames.length - 1, Math.floor(i.age * i.atlas.fps)),
                  r = i.node.getComponent(s);
                r && (r.spriteFrame = i.atlas.frames[o]);
                var c = i.node.getComponent(n);
                c && i.age > i.atlas.frames.length / i.atlas.fps * .72 && (c.opacity = Math.max(0, Math.round(255 * (1 - (i.age - i.atlas.frames.length / i.atlas.fps * .72) / (i.atlas.frames.length / i.atlas.fps * .28))))), o >= i.atlas.frames.length - 1 && (i.node.destroy(), this.active.splice(a, 1));
              } else this.active.splice(a, 1);
            }
          }
        }, i.play = function () {
          var t = a( /*#__PURE__*/_regeneratorRuntime().mark(function _callee5(t, e, a, i, o) {
            var r, c, l, u, f, g;
            return _regeneratorRuntime().wrap(function _callee5$(_context6) {
              while (1) switch (_context6.prev = _context6.next) {
                case 0:
                  if (!(void 0 === o && (o = this.reducedMotion), !(this.disposed || this.paused || o && "danger" !== t))) {
                    _context6.next = 7;
                    break;
                  }
                  r = this.generation;
                  c = p[t];
                  _context6.next = 5;
                  return this.load(c);
                case 5:
                  l = _context6.sent;
                  if (l && !this.disposed && !this.paused && r === this.generation && this.root.isValid) {
                    u = this.active.filter(function (e) {
                      return e.kind === t;
                    });
                    if (u.length >= v[t]) {
                      f = u[0];
                      f.node.destroy(), this.active = this.active.filter(function (t) {
                        return t !== f;
                      });
                    }
                    g = new d("V2FX-" + t);
                    this.root.addChild(g), g.setPosition(e - 375, a - 667, 0), g.addComponent(h).setContentSize("danger" === t ? 92 : "result" === t ? 220 : "tap" === t ? 68 : 112, "danger" === t ? 92 : "result" === t ? 220 : "tap" === t ? 68 : 112), g.addComponent(s).spriteFrame = l.frames[0], g.addComponent(n).opacity = 255, this.active.push({
                      node: g,
                      kind: t,
                      age: 0,
                      atlas: l,
                      owner: i
                    });
                  }
                case 7:
                case "end":
                  return _context6.stop();
              }
            }, _callee5, this);
          }));
          return function (e, a, i, s, n) {
            return t.apply(this, arguments);
          };
        }(), i.ensureCat = function (t, e) {
          var a,
            i = this;
          this.disposed || (this.catRequested = !0, this.catX = t - 375, this.catY = e - 667, null != (a = this.catNode) && a.isValid ? this.catNode.setPosition(this.catX, this.catY, 0) : this.catImage ? this.makeCat() : o.load("effects/v2/cat_barista", r, function (t, e) {
            !t && e && !i.disposed && i.catRequested && (i.catImage = e, i.catTexture = new c(), i.catTexture.image = e, i.makeCat());
          }));
        }, i.hideCat = function () {
          var t;
          this.catRequested = !1, null != (t = this.catNode) && t.isValid && this.catNode.destroy(), this.catNode = null;
        }, i.makeCat = function () {
          if (this.catImage && this.catTexture && this.root.isValid) {
            this.catNode = new d("V2CatBarista"), this.root.addChild(this.catNode), this.catNode.setPosition(this.catX, this.catY, 0), this.catNode.addComponent(h).setContentSize(92, 110);
            var t = new l();
            t.reset({
              texture: this.catTexture,
              rect: new u(0, 0, this.catImage.width, this.catImage.height),
              originalSize: new f(this.catImage.width, this.catImage.height)
            });
            var e = this.catNode.addComponent(s);
            e.sizeMode = s.SizeMode.CUSTOM, e.trim = !1, e.spriteFrame = t, this.catNode.getComponent(h).setContentSize(92, 110);
          }
        }, i.cancelOwner = function (t) {
          for (var a, i = e(this.active.filter(function (e) {
              return e.owner === t;
            })); !(a = i()).done;) {
            var s = a.value;
            s.node.destroy(), this.active.splice(this.active.indexOf(s), 1);
          }
        }, i.dispose = function () {
          var t, a;
          this.disposed = !0, this.generation++;
          for (var i, s = e(this.active); !(i = s()).done;) {
            i.value.node.destroy();
          }
          this.active = [];
          for (var n, o = e(this.atlases.values()); !(n = o()).done;) {
            for (var r, c = n.value, d = e(c.frames); !(r = d()).done;) {
              r.value.destroy();
            }
            c.texture.destroy();
          }
          this.atlases.clear(), null != (t = this.catNode) && t.isValid && this.catNode.destroy(), this.catNode = null, null == (a = this.catTexture) || a.destroy(), this.catTexture = null, this.catImage = null;
        }, i.load = function () {
          var t = a( /*#__PURE__*/_regeneratorRuntime().mark(function _callee6(t) {
            var e, a, i, s, n;
            return _regeneratorRuntime().wrap(function _callee6$(_context7) {
              while (1) switch (_context7.prev = _context7.next) {
                case 0:
                  e = this, a = this.atlases.get(t);
                  if (!a) {
                    _context7.next = 3;
                    break;
                  }
                  return _context7.abrupt("return", a);
                case 3:
                  i = this.loading.get(t);
                  if (!i) {
                    _context7.next = 6;
                    break;
                  }
                  return _context7.abrupt("return", i);
                case 6:
                  s = this.generation, n = new Promise(function (a) {
                    o.load("effects/v2/" + t + "_sheet_4col", r, function (i, n) {
                      if (i || !n || e.disposed || s !== e.generation) a(null);else {
                        var o = new c();
                        o.image = n;
                        for (var r = [], d = 0; d < g[t]; d++) {
                          var h = new l();
                          h.reset({
                            texture: o,
                            rect: new u(d % 4 * (n.width / 4), Math.floor(d / 4) * (n.width / 4), n.width / 4, n.width / 4),
                            originalSize: new f(n.width / 4, n.width / 4)
                          }), r.push(h);
                        }
                        var p = {
                          texture: o,
                          frames: r,
                          fps: 24
                        };
                        e.atlases.set(t, p), a(p);
                      }
                    });
                  });
                  return _context7.abrupt("return", (this.loading.set(t, n), n.then(function () {
                    e.loading.get(t) === n && e.loading["delete"](t);
                  }, function () {
                    e.loading.get(t) === n && e.loading["delete"](t);
                  }), n));
                case 8:
                case "end":
                  return _context7.stop();
              }
            }, _callee6, this);
          }));
          return function (e) {
            return t.apply(this, arguments);
          };
        }(), t;
      }());
      i._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/EventIdentity.ts", ["cc", "./Sha256.ts"], function (t) {
  var e, n;
  return {
    setters: [function (t) {
      e = t.cclegacy;
    }, function (t) {
      n = t.sha256Utf8;
    }],
    execute: function execute() {
      t({
        deterministicEventId: function deterministicEventId(t, e, i, c) {
          var s = n(JSON.stringify([t, e, i].concat(c))).slice(0, 32).split("");
          s[12] = "8", s[16] = (3 & parseInt(s[16], 16) | 8).toString(16);
          var r = s.join("");
          return r.slice(0, 8) + "-" + r.slice(8, 12) + "-" + r.slice(12, 16) + "-" + r.slice(16, 20) + "-" + r.slice(20);
        },
        makeEvent: function makeEvent(t) {
          return t;
        }
      }), e._RF.push({}, "7a97cDTBFJEcqWwvJDLoVrR", "EventIdentity", void 0), e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/GameAudio.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (i) {
  var s, e, t, u, o;
  return {
    setters: [function (i) {
      s = i.createForOfIteratorHelperLoose, e = i["extends"];
    }, function (i) {
      t = i.cclegacy, u = i.Node, o = i.AudioSource;
    }],
    execute: function execute() {
      t._RF.push({}, "0b8e1nA1M5LAJ5qT40VnAd3", "GameAudio", void 0);
      var n = {
        collision_soft: 1,
        ui_tap: 2,
        drop: 2,
        shake_start: 2,
        merge_small: 3,
        merge_large: 3,
        danger_tick: 4,
        result: 5
      };
      i("GameAudio", function () {
        function i(i, s, t, n) {
          var l;
          this.music = void 0, this.voices = void 0, this.voiceCues = [null, null, null], this.unlocked = !1, this.disposed = !1, this.clips = void 0, this.clips = e({}, s);
          var c = new u("P1CAudioBGM");
          i.addChild(c), this.music = c.addComponent(o), this.music.clip = null != (l = s.bgm_classic) ? l : null, this.music.loop = !0, this.music.playOnAwake = !1;
          for (var r = 0, a = Object.values(s); r < a.length; r++) {
            var d = a[r];
            null == d || d.addRef();
          }
          this.voices = [0, 1, 2].map(function (s) {
            var e = new u("P1CAudioSFX-" + (s + 1));
            i.addChild(e);
            var t = e.addComponent(o);
            return t.playOnAwake = !1, t;
          }), this.setVolumes(t, n);
        }
        var t = i.prototype;
        return t.addClip = function (i, s) {
          this.disposed || this.clips[i] || (s.addRef(), this.clips[i] = s, "bgm_classic" === i && (this.music.clip = s));
        }, t.setVolumes = function (i, e) {
          this.music.volume = Math.max(0, Math.min(1, i));
          for (var t, u = s(this.voices); !(t = u()).done;) {
            t.value.volume = Math.max(0, Math.min(1, e));
          }
        }, t.requestMusicFromGesture = function () {
          return !(this.disposed || !this.clips.bgm_classic) && (this.unlocked = !0, this.music.playing || this.music.play(), !0);
        }, t.play = function (i) {
          var s = this;
          if (this.disposed || !this.unlocked || !this.clips[i]) return !1;
          var e = this.voices.findIndex(function (i) {
            return !i.playing;
          });
          if (e < 0) {
            e = this.voiceCues.reduce(function (i, e, t) {
              return null !== e && (null === s.voiceCues[i] || n[e] < n[s.voiceCues[i]]) ? t : i;
            }, 0);
            var t = this.voiceCues[e];
            if (null !== t && n[t] >= n[i]) return !1;
          }
          var u = this.voices[e];
          return u.stop(), u.clip = this.clips[i], u.play(), this.voiceCues[e] = i, !0;
        }, t.pauseForHidden = function () {
          this.music.pause();
          for (var i, e = s(this.voices); !(i = e()).done;) {
            i.value.stop();
          }
          this.voiceCues.fill(null);
        }, t.resumeAfterUserGesture = function () {
          return this.requestMusicFromGesture();
        }, t.dispose = function () {
          if (!this.disposed) {
            this.disposed = !0, this.music.stop();
            for (var i, e = s(this.voices); !(i = e()).done;) {
              i.value.stop();
            }
            for (var t = 0, u = Object.values(this.clips); t < u.length; t++) {
              var o = u[t];
              null == o || o.decRef();
            }
            this.voiceCues.fill(null);
          }
        }, i;
      }());
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/GameRoot.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./Clock.ts", "./RunEngine.ts", "./HostLifecycleCoordinator.ts", "./AppRuntime.ts", "./CocosPhysicsAdapter.ts", "./ArtAssets.ts", "./ArtCatalog.ts", "./GameAudio.ts", "./LocalSaveRepository.ts", "./RewardLedger.ts", "./SaveCodec.ts", "./SaveValidator.ts", "./RewardedShakeService.ts", "./SpillReviveService.ts", "./RewardedAdCoordinator.ts", "./ReviveLedger.ts", "./RewardedAdPolicyLoader.ts", "./SpillRevivePolicyLoader.ts", "./RewardedAdProviderFactory.ts", "./Viewport.ts", "./EffectsController.ts"], function (e) {
  var t, i, n, s, r, o, a, l, u, d, h, c, v, p, f, g, w, S, R, m, y, E, b, _, k, I, T, C, A, O, D, M, P, x, L, N, B, U, F, G, V, H, z, W, q, K, Y;
  return {
    setters: [function (e) {
      t = e.inheritsLoose, i = e.createForOfIteratorHelperLoose, n = e["extends"], s = e.asyncToGenerator;
    }, function (e) {
      r = e.cclegacy, o = e._decorator, a = e.input, l = e.Input, u = e.Node, d = e.Color, h = e.UITransform, c = e.UIOpacity, v = e.Graphics, p = e.Label, f = e.Sprite, g = e.assetManager, w = e.AudioClip, S = e.resources, R = e.tween, m = e.Vec3, y = e.Vec2, E = e.Component, b = e.Tween, _ = e.JsonAsset;
    }, function (e) {
      k = e.FixedClock;
    }, function (e) {
      I = e.RunEngine;
    }, function (e) {
      T = e.HostLifecycleCoordinator;
    }, function (e) {
      C = e.AppRuntime;
    }, function (e) {
      A = e.CocosPhysicsAdapter;
    }, function (e) {
      O = e.ArtAssets;
    }, function (e) {
      D = e.ArtCatalog;
    }, function (e) {
      M = e.GameAudio;
    }, function (e) {
      P = e.LocalSaveRepository;
    }, function (e) {
      x = e.RewardLedger;
    }, function (e) {
      L = e.SaveCodec;
    }, function (e) {
      N = e.SaveValidator;
    }, function (e) {
      B = e.RewardedShakeService;
    }, function (e) {
      U = e.SpillReviveService;
    }, function (e) {
      F = e.RewardedAdCoordinator;
    }, function (e) {
      G = e.ReviveLedger;
    }, function (e) {
      V = e.RewardedAdPolicyLoader;
    }, function (e) {
      H = e.SpillRevivePolicyLoader;
    }, function (e) {
      z = e.createRewardedAdEnvironment, W = e.createReviveAdEnvironment;
    }, function (e) {
      q = e.presentationSize, K = e.gameUiPoint;
    }, function (e) {
      Y = e.EffectsController;
    }],
    execute: function execute() {
      var X, j;
      r._RF.push({}, "1a480dQ6u5CEo2++TQ15XVx", "GameRoot", void 0);
      var Q = o.ccclass,
        J = Object.freeze({
          enabled: !1,
          policyVersion: "policy-unavailable",
          adUnitId: null,
          placement: "extra-shake",
          maxExtraShakesPerRun: 5,
          maxDailyRewardedShakes: 5,
          minForegroundSecondsFirstSession: 60,
          requireTutorialComplete: !0,
          requireFirstNaturalRunCompleted: !0
        }),
        Z = Object.freeze({
          enabled: !1,
          policyVersion: "policy-unavailable",
          adUnitId: null,
          placement: "spill-revive",
          maxRevivesPerRun: 1,
          clearanceDu: 40,
          autoDropDelayTicks: 120,
          minForegroundSecondsFirstSession: 60,
          requireTutorialComplete: !0,
          requireFirstNaturalRunCompleted: !0
        });
      e("GameRoot", Q("P1BGameRoot")(((j = function (e) {
        function r() {
          for (var t, i = arguments.length, n = new Array(i), s = 0; s < i; s++) n[s] = arguments[s];
          return (t = e.call.apply(e, [this].concat(n)) || this).screen = "MENU", t.sceneId = 0, t.worldId = 0, t.world = null, t.rear = null, t.front = null, t.fixedBackground = null, t.art = new O(), t.effects = null, t.artReady = !1, t.adapter = null, t.engine = null, t.clock = null, t.audio = null, t.audioLoading = !1, t.audioUnlockRequested = !1, t.audioFailure = "", t.ingredientViews = new Map(), t.shakeArcNodes = [], t.classicBundle = null, t.classicBundleLoad = null, t.audioClips = {}, t.audioFailures = new Set(), t.repo = new P(), t.bundle = P.emptyBundle(), t.bundleRevision = 0, t.rewarded = null, t.rewardedHost = null, t.rewardedPolicyError = "", t.foregroundSeconds = 0, t.spillRevive = null, t.spillReviveHost = null, t.spillRevivePolicyError = "", t.adOverlayKind = "extra-shake", t.debugRepo = null, t.debugLease = null, t.debugNamespace = null, t.debugMode = !1, t.lease = null, t.persistent = !1, t.loading = !1, t.saveInFlight = !1, t.activeSaveTaskId = 0, t.saveTaskSequence = 0, t.saveIdleWaiters = [], t.saveDirty = !1, t.settingsDirty = !1, t.saveAge = 0, t.baseTick = 0, t.leaseInitialized = !1, t.bundleInitialized = !1, t.artRetryTask = null, t.artLoadGeneration = 0, t.pendingStartRequested = !1, t.buttons = [], t.labels = new Map(), t.previewX = 375, t.primaryPointer = null, t.dropStartX = 0, t.dropStartPreviewX = 375, t.pointerKind = null, t.startedInButton = null, t.startedInOverlay = null, t.ignoreMouseUntil = 0, t.ownerEpoch = 0, t.lastCommand = null, t.cupPointerStartX = 0, t.cupPointerStartOffset = 0, t.lastEvents = [], t.pauseOwners = new Set(), t.lifecycleOff = null, t.notice = "", t.mode = "drag_release", t.reducedMotion = !1, t.settingsReturnScreen = "MENU", t.tutorialStep = 0, t.tutorialReturnScreen = "PLAYING", t.resultSaved = !1, t.resultFinalized = !1, t.resultError = "", t.runBestScoreAtStart = 0, t.uiRoot = null, t.overlayRoot = null, t.overlayButtons = [], t.overlayVisible = !1, t.startupTraceId = 0, t.firstTickTraceId = -1, t.recoveryUsedRunId = null, t.showPhysicsDiagnostics = !1, t.previewGraphic = null, t.contactPairs = new Set(), t.contactObjectTicks = new Map(), t.lastContactFeedbackTick = -60, t.feedbackSequence = 0, t.keydown = function (e) {
            "p" === e.key.toLowerCase() ? t.togglePause() : "r" === e.key.toLowerCase() && t.resumeByUser();
          }, t.onWindowBlur = function () {
            return t.cancelPointer();
          }, t.artLoading = !1, t.buttonSkins = new Map(), t.settingsArtBudget = null, t.renderFailureShown = !1, t.uiRefreshElapsed = 0, t.lastSaveTick = 0, t.lastDangerCueTick = -60, t.consumedDomainEventIds = new Set(), t;
        }
        t(r, e);
        var o = r.prototype;
        return o.onLoad = function () {
          var e = this;
          this.sceneId = r.nextSceneId++, this.lifecycleOff = T.subscribe(function (t) {
            return e.onLifecycle(t);
          }), a.on(l.EventType.TOUCH_START, this.onTouchStart, this), a.on(l.EventType.TOUCH_MOVE, this.onTouchMove, this), a.on(l.EventType.TOUCH_END, this.onTouchEnd, this), a.on(l.EventType.TOUCH_CANCEL, this.onTouchCancel, this), a.on(l.EventType.MOUSE_DOWN, this.onMouseDown, this), a.on(l.EventType.MOUSE_MOVE, this.onMouseMove, this), a.on(l.EventType.MOUSE_UP, this.onMouseUp, this), window.addEventListener("keydown", this.keydown), window.addEventListener("blur", this.onWindowBlur), this.uiRoot = new u("P1BPlayerUI"), this.node.addChild(this.uiRoot), this.uiRoot.setSiblingIndex(this.node.children.length - 1), this.effects = new Y(this.uiRoot), this.overlayRoot = new u("P1BStartupOverlay"), this.node.addChild(this.overlayRoot), this.overlayRoot.setSiblingIndex(this.node.children.length - 1), this.initialize();
          var t = this.node.getChildByName("MilkTeaStartupFrame");
          null != t && t.isValid && (t.active = !1, t.destroy());
        }, o.initialize = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee7() {
            var e, t, i, n, s, r, o, a, l;
            return _regeneratorRuntime().wrap(function _callee7$(_context8) {
              while (1) switch (_context8.prev = _context8.next) {
                case 0:
                  if (this.loading) {
                    _context8.next = 60;
                    break;
                  }
                  this.loading = !0, this.artLoading = !0, this.render();
                  e = this.ownerEpoch, t = this.startupTraceId = C.startup.beginTrace(e), i = this.art.beginLoadScope(e, t, 15e3, "GAME_ART");
                  _context8.prev = 3;
                  if (this.leaseInitialized) {
                    _context8.next = 15;
                    break;
                  }
                  _context8.next = 7;
                  return this.repo.acquireWriteLease();
                case 7:
                  n = _context8.sent;
                  if (!(this.leaseInitialized = !0, n.ok)) {
                    _context8.next = 14;
                    break;
                  }
                  if (this.isOwner()) {
                    _context8.next = 11;
                    break;
                  }
                  return _context8.abrupt("return", void n.data.release());
                case 11:
                  this.lease = n.data.release, this.persistent = "persistent" === n.data.mode;
                  _context8.next = 15;
                  break;
                case 14:
                  C.startup.stage("SAVE_READ", "error", {
                    code: n.error.code
                  }, e, t);
                case 15:
                  if (this.isOwner()) {
                    _context8.next = 17;
                    break;
                  }
                  return _context8.abrupt("return");
                case 17:
                  if (this.bundleInitialized) {
                    _context8.next = 24;
                    break;
                  }
                  _context8.next = 20;
                  return this.repo.readBundle();
                case 20:
                  s = _context8.sent;
                  if (this.isOwner()) {
                    _context8.next = 23;
                    break;
                  }
                  return _context8.abrupt("return");
                case 23:
                  s.ok ? (s.data.envelope && (this.bundle = s.data.envelope.payload, this.bundleRevision = s.data.envelope.revision), s.data.warning && (this.notice = s.data.warning), C.startup.stage("SAVE_READ", "ok", {
                    code: s.data.envelope ? "" : "EMPTY_SAVE",
                    assetId: "revision:" + this.bundleRevision,
                    bundleName: "hasRun:" + !!this.bundle.run
                  }, e, t)) : (this.persistent = !1, this.notice = "存档不可续用：" + s.error.message + "。原始槽保留；为保护存档，当前禁止持久化覆盖。", C.startup.stage("SAVE_READ", "error", {
                    code: s.error.code,
                    bundleName: "memory-only"
                  }, e, t)), this.bundleInitialized = !0;
                case 24:
                  this.mode = this.bundle.profile.settings.dropMode;
                  this.reducedMotion = this.bundle.profile.settings.reducedMotion;
                  _context8.t0 = this.rewarded;
                  if (_context8.t0) {
                    _context8.next = 30;
                    break;
                  }
                  _context8.next = 30;
                  return this.initializeRewardedShake();
                case 30:
                  if (this.isOwner()) {
                    _context8.next = 32;
                    break;
                  }
                  return _context8.abrupt("return");
                case 32:
                  _context8.t1 = this.spillRevive;
                  if (_context8.t1) {
                    _context8.next = 36;
                    break;
                  }
                  _context8.next = 36;
                  return this.initializeSpillRevive();
                case 36:
                  if (this.isOwner()) {
                    _context8.next = 38;
                    break;
                  }
                  return _context8.abrupt("return");
                case 38:
                  _context8.next = 40;
                  return this.art.initialize();
                case 40:
                  if (this.isOwner()) {
                    _context8.next = 42;
                    break;
                  }
                  return _context8.abrupt("return", void this.art.dispose());
                case 42:
                  this.artReady = !0;
                  o = this.art.catalog.ids.length, a = this.art.catalog.variantCount;
                  C.startup.stage("ART_CATALOG", "ok", {
                    assetId: "ids:" + o,
                    bundleName: "variants:" + a
                  }, e, t);
                  _context8.next = 47;
                  return this.loadRequiredArt();
                case 47:
                  if (this.isOwner()) {
                    _context8.next = 49;
                    break;
                  }
                  return _context8.abrupt("return", void this.art.dispose());
                case 49:
                  if (!(this.art.settleLoadScope(i), this.artLoading = !1, this.hideOverlay(), this.render(), this.bindRewardedShake(), this.bindSpillRevive(), this.loadAudioClips(), !this.isOwner())) {
                    _context8.next = 51;
                    break;
                  }
                  return _context8.abrupt("return");
                case 51:
                  if (this.notice = "", C.startup.stage("MENU_READY", "ok", {
                    assetId: "loaded:" + this.art.loadedCount,
                    bundleName: "screen:" + this.screen
                  }, e, t), this.bundle.run) this.notice = this.bundle.run.rulesVersion === (null == (r = C.rules) ? void 0 : r.design_rules_version) ? "发现可续局存档。选择“继续上局”后仍需明确点击继续。" : "发现旧版玩法未完成局；原存档已保留，可取消确认或明确开始新局。", this.render();
                  _context8.next = 57;
                  break;
                case 54:
                  _context8.prev = 54;
                  _context8.t2 = _context8["catch"](3);
                  if (this.art.cancelScope(this.startupErrorCode(_context8.t2), i), this.artLoading = !1, this.isOwner()) {
                    l = this.startupErrorCode(_context8.t2);
                    C.startup.stage("GAME_ART", "error", {
                      code: l,
                      error: _context8.t2
                    }, e, t), this.showStartupFailure(l, String(_context8.t2), t);
                  }
                case 57:
                  _context8.prev = 57;
                  this.isOwner() && (this.loading = !1, this.pendingStartRequested && this.artReady && "MENU" === this.screen && (this.pendingStartRequested = !1, this.startNew()));
                  return _context8.finish(57);
                case 60:
                case "end":
                  return _context8.stop();
              }
            }, _callee7, this, [[3, 54, 57, 60]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.onDestroy = function () {
          var e, t, i, n, s, r, o;
          this.ownerEpoch++, this.settingsArtBudget = null, this.art.cancelScope("START_ART_CANCELLED"), this.clearOverlay(), null == (e = this.lifecycleOff) || e.call(this), this.lifecycleOff = null, this.rewarded && this.rewardedHost && this.rewarded.unbind(this.rewardedHost), this.rewardedHost = null, this.spillRevive && this.spillReviveHost && this.spillRevive.unbind(this.spillReviveHost), this.spillReviveHost = null, a.off(l.EventType.TOUCH_START, this.onTouchStart, this), a.off(l.EventType.TOUCH_MOVE, this.onTouchMove, this), a.off(l.EventType.TOUCH_END, this.onTouchEnd, this), a.off(l.EventType.TOUCH_CANCEL, this.onTouchCancel, this), a.off(l.EventType.MOUSE_DOWN, this.onMouseDown, this), a.off(l.EventType.MOUSE_MOVE, this.onMouseMove, this), a.off(l.EventType.MOUSE_UP, this.onMouseUp, this), window.removeEventListener("keydown", this.keydown), window.removeEventListener("blur", this.onWindowBlur), null == (t = this.clock) || t.pause(), this.clock = null, null == (i = this.engine) || i.dispose(), this.engine = null, null == (n = this.effects) || n.dispose(), this.effects = null, this.art.dispose(), null == (s = this.audio) || s.dispose(), this.audio = null;
          for (var u = 0, d = Object.keys(this.audioClips); u < d.length; u++) {
            var h = d[u];
            this.releaseAudioClip(h);
          }
          null == (r = this.debugLease) || r.call(this), this.debugLease = null, this.debugRepo = null, null == (o = this.lease) || o.call(this), this.lease = null;
        }, o.update = function (e) {
          var t, i, n, s, r, o, a, l, u;
          !T.backgrounded && C.startup.tickForeground(1e3 * Math.max(0, e));
          t = null == (i = this.engine) ? void 0 : i.tick;
          if ("PLAYING" === this.screen && 0 === this.tutorialStep && this.clock && this.engine) try {
            if (this.clock.update(e).steps, this.clock.tick + this.baseTick !== this.engine.tick) throw new Error("CLOCK_ENGINE_TICK_DIVERGED");
            this.processEvents();
          } catch (e) {
            this.enterTechnicalError(String(e));
          }
          var d = null != (n = null == (s = this.engine) ? void 0 : s.renderStates()) ? n : null;
          this.syncViews(d), this.syncCupArt(), this.syncViewportBackgrounds(), this.engine && this.activeSaveRepository() && this.engine.tick - this.lastSaveTick >= 120 && (this.saveDirty = !0), this.saveAge += 1e3 * Math.max(0, e), this.saveDirty && !this.saveInFlight && "SETTLING" !== (null == (r = this.engine) ? void 0 : r.phase) && this.saveAge >= 250 && (this.saveAge = 0, this.commitCheckpoint(!1)), !this.engine || "SETTLING" !== this.engine.phase || this.resultFinalized || this.saveInFlight || this.commitResult(), this.pauseOwners.has("HOST_HIDDEN") || "REWARD" === this.screen || "REVIVE" === this.screen || (this.foregroundSeconds += Math.max(0, e)), null == (o = this.rewarded) || o.setForegroundSeconds(this.foregroundSeconds), null == (a = this.spillRevive) || a.setForegroundSeconds(this.foregroundSeconds), null == (l = this.effects) || l.setPaused("PAUSED" === this.screen || "REWARD" === this.screen || "REVIVE" === this.screen || this.pauseOwners.has("HOST_HIDDEN")), null == (u = this.effects) || u.update(Math.max(0, e)), this.uiRefreshElapsed >= .12 ? (this.uiRefreshElapsed = 0, this.refreshHud()) : this.uiRefreshElapsed += Math.max(0, e);
        }, o.isOwner = function () {
          return this.isValid && this.sceneId === r.nextSceneId - 1;
        }, o.onLifecycle = function (e) {
          var t;
          e.resumeRequired && this.pauseOwners.add("RESUME_REQUIRED");
          var i,
            n,
            s,
            r = "SETTLING" === (null == (t = this.engine) ? void 0 : t.phase);
          e.backgrounded ? (this.pauseOwners.add("HOST_HIDDEN"), this.cancelPointer(), null == (i = this.audio) || i.pauseForHidden(), this.engine && (this.engine.pause("HOST_HIDDEN"), null == (n = this.clock) || n.pause(), r || this.isModalScreen() || (this.screen = "PAUSED"), r || (this.notice = "应用已进入后台；返回后请点击“继续”。", this.saveDirty = !0, this.commitCheckpoint(!0)), this.render())) : (this.pauseOwners["delete"]("HOST_HIDDEN"), this.engine && e.resumeRequired && (this.engine.pause("RESUME_REQUIRED"), null == (s = this.clock) || s.pause(), r || this.isModalScreen() || (this.screen = "PAUSED"), r || (this.notice = "已返回前台；物理保持暂停，请点击“继续”。"), this.render()));
        }, o.initializeRewardedShake = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee8() {
            var e, t, i;
            return _regeneratorRuntime().wrap(function _callee8$(_context9) {
              while (1) switch (_context9.prev = _context9.next) {
                case 0:
                  e = J;
                  _context9.prev = 1;
                  _context9.next = 4;
                  return new Promise(function (e, t) {
                    return S.load("config/rewarded-ad-policy", _, function (i, n) {
                      return i || !n ? t(null != i ? i : new Error("激励广告策略缺失")) : e(n.json);
                    });
                  });
                case 4:
                  t = _context9.sent;
                  i = V.validate(t);
                  i.ok ? e = i.data : (this.rewardedPolicyError = i.error.message, console.warn("[reward] policy invalid", i.error.message));
                  _context9.next = 12;
                  break;
                case 9:
                  _context9.prev = 9;
                  _context9.t0 = _context9["catch"](1);
                  this.rewardedPolicyError = String(_context9.t0), console.warn("[reward] policy load failed", String(_context9.t0));
                case 12:
                  this.rewarded = B.create(z(n({}, e)), this.adSaveRepository(), function () {
                    return Date.now();
                  });
                case 13:
                case "end":
                  return _context9.stop();
              }
            }, _callee8, this, [[1, 9]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.bindRewardedShake = function () {
          this.rewarded && (this.rewardedHost || (this.rewardedHost = this.makeRewardedHost()), this.rewarded.setForegroundSeconds(this.foregroundSeconds), this.rewarded.bind(this.rewardedHost));
        }, o.makeRewardedHost = function () {
          var e = this;
          return {
            getActiveRunSnapshot: function getActiveRunSnapshot() {
              return e.activeRunSnapshot();
            },
            getBundle: function getBundle() {
              return e.bundle;
            },
            getSaveRevision: function getSaveRevision() {
              return e.bundleRevision;
            },
            isTutorialComplete: function isTutorialComplete() {
              var t;
              return e.bundle.profile.settings.tutorialCompleted || e.bundle.profile.tutorialRulesVersion === (null == (t = C.rules) ? void 0 : t.design_rules_version);
            },
            getForegroundSeconds: function getForegroundSeconds() {
              return e.foregroundSeconds;
            },
            pauseForRewardedAd: function pauseForRewardedAd() {
              e.adOverlayKind = "extra-shake", e.pauseForRewardedAd();
            },
            resumeFromRewardedAd: function resumeFromRewardedAd(t) {
              return e.resumeFromRewardedAd(t);
            },
            onRewardedShakeChanged: function onRewardedShakeChanged() {
              return e.onRewardedChanged();
            },
            onRewardedShakeCommitted: function onRewardedShakeCommitted(t, i) {
              e.bundle = t, e.bundleRevision = i;
            },
            applyCommittedExtraGrant: function applyCommittedExtraGrant(t) {
              if (!e.engine || !Number.isSafeInteger(t) || t <= 0) return !1;
              var i = e.engine.commitExtraGrant(t);
              return !!i.ok || (e.enterTechnicalError(i.error.message), !1);
            },
            waitForSaveIdle: function waitForSaveIdle() {
              return e.waitForSaveIdle();
            }
          };
        }, o.initializeSpillRevive = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee9() {
            var e, t, i;
            return _regeneratorRuntime().wrap(function _callee9$(_context10) {
              while (1) switch (_context10.prev = _context10.next) {
                case 0:
                  e = Z;
                  _context10.prev = 1;
                  _context10.next = 4;
                  return new Promise(function (e, t) {
                    return S.load("config/spill-revive-policy", _, function (i, n) {
                      return i || !n ? t(null != i ? i : new Error("复活广告策略缺失")) : e(n.json);
                    });
                  });
                case 4:
                  t = _context10.sent;
                  i = H.validate(t);
                  i.ok ? e = i.data : (this.spillRevivePolicyError = i.error.message, console.warn("[revive] policy invalid", i.error.message));
                  _context10.next = 12;
                  break;
                case 9:
                  _context10.prev = 9;
                  _context10.t0 = _context10["catch"](1);
                  this.spillRevivePolicyError = String(_context10.t0), console.warn("[revive] policy load failed", String(_context10.t0));
                case 12:
                  this.spillRevive = U.create(W(n({}, e)), this.adSaveRepository(), function () {
                    return Date.now();
                  });
                case 13:
                case "end":
                  return _context10.stop();
              }
            }, _callee9, this, [[1, 9]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.bindSpillRevive = function () {
          this.spillRevive && (this.spillReviveHost || (this.spillReviveHost = this.makeSpillReviveHost()), this.spillRevive.setForegroundSeconds(this.foregroundSeconds), this.spillRevive.bind(this.spillReviveHost));
        }, o.reviveOptions = function () {
          var e,
            t,
            i,
            n = null == (e = this.spillRevive) ? void 0 : e.policy;
          return {
            enabled: !(null == n || !n.enabled),
            clearanceDu: null != (t = null == n ? void 0 : n.clearanceDu) ? t : 0,
            autoDropDelayTicks: null != (i = null == n ? void 0 : n.autoDropDelayTicks) ? i : 0
          };
        }, o.makeSpillReviveHost = function () {
          var e = this;
          return {
            getActiveRunSnapshot: function getActiveRunSnapshot() {
              return e.activeRunSnapshot();
            },
            getBundle: function getBundle() {
              return e.bundle;
            },
            getSaveRevision: function getSaveRevision() {
              return e.bundleRevision;
            },
            isTutorialComplete: function isTutorialComplete() {
              var t;
              return e.bundle.profile.settings.tutorialCompleted || e.bundle.profile.tutorialRulesVersion === (null == (t = C.rules) ? void 0 : t.design_rules_version);
            },
            getForegroundSeconds: function getForegroundSeconds() {
              return e.foregroundSeconds;
            },
            pauseForRewardedAd: function pauseForRewardedAd() {
              e.adOverlayKind = "spill-revive", e.pauseForRewardedAd();
            },
            resumeFromRewardedAd: function resumeFromRewardedAd(t) {
              return e.resumeFromRewardedAd(t);
            },
            onSpillReviveChanged: function onSpillReviveChanged() {
              return e.onSpillReviveChanged();
            },
            onSpillReviveCommitted: function onSpillReviveCommitted(t, i) {
              e.bundle = t, e.bundleRevision = i;
            },
            projectRevive: function projectRevive(t) {
              return e.engine ? e.engine.projectRevive(t) : {
                ok: !1,
                error: {
                  code: "NO_RUN",
                  message: "no active run",
                  retryable: !1
                }
              };
            },
            applyCommittedRevive: function applyCommittedRevive(t) {
              var i;
              if (!e.engine) return !1;
              if (e.engine.reviveReceiptId === t) return !0;
              var n = e.engine.applyRevive(t);
              return n.ok ? (e.pauseOwners.add("AD"), null == (i = e.clock) || i.pause(), !0) : (e.notice = n.error.message, !1);
            },
            declineSpillRevive: function declineSpillRevive() {
              return e.declineSpillRevive();
            },
            waitForSaveIdle: function waitForSaveIdle() {
              return e.waitForSaveIdle();
            }
          };
        }, o.reviveView = function () {
          var e, t;
          return null != (e = null == (t = this.spillRevive) ? void 0 : t.getView()) ? e : null;
        }, o.onSpillReviveChanged = function () {
          var e;
          if (this.spillRevive) if ("REVIVE" !== this.screen) {
            var t = null == (e = this.reviveView()) ? void 0 : e.message;
            t && "PLAYING" === this.screen && (this.notice = t, this.render());
          } else this.render();
        }, o.declineSpillRevive = function () {
          var e,
            t,
            i,
            n = null != (e = null == (t = this.engine) ? void 0 : t.declineRevive()) ? e : null;
          if (n) return this.lastEvents.push(n), void this.processEvents();
          "SETTLING" === (null == (i = this.engine) ? void 0 : i.phase) ? this.screen = "RESULTS" : this.engine && (this.screen = "PAUSED"), this.render();
        }, o.enterSpillOffer = function () {
          var e;
          null == (e = this.clock) || e.pause(), this.cancelPointer(), this.screen = "REVIVE", this.notice = "", this.saveDirty = !0, this.render(), this.commitCheckpoint(!0);
        }, o.activeRunSnapshot = function () {
          var e,
            t = null == (e = this.engine) ? void 0 : e.snapshot();
          return t && this.bundle.profile.activeRunId === t.runId ? t : this.bundle.run;
        }, o.rewardView = function () {
          var e, t;
          return null != (e = null == (t = this.rewarded) ? void 0 : t.getView()) ? e : null;
        }, o.pauseForRewardedAd = function () {
          var e, t;
          (this.cancelPointer(), this.saveDirty = !1, this.pauseOwners.add("AD"), this.engine) && (this.engine.pause("AD"), null == (t = this.clock) || t.pause());
          null == (e = this.audio) || e.pauseForHidden(), this.screen = "spill-revive" === this.adOverlayKind ? "REVIVE" : "REWARD", this.notice = "", this.render();
        }, o.resumeFromRewardedAd = function (e) {
          this.pauseOwners["delete"]("AD"), this.screen = this.engine ? "PAUSED" : "MENU", this.notice = null != e ? e : "", this.render();
        }, o.onRewardedChanged = function () {
          var e;
          if (this.rewarded) if ("REWARD" !== this.screen) {
            var t = null == (e = this.rewardView()) ? void 0 : e.message;
            t && (this.notice = t, this.render());
          } else this.render();
        }, o.openRewardedOffer = function () {
          var e;
          return this.rewarded ? F.busy() ? (this.notice = "另有广告正在进行，请稍后再试。", void this.render()) : void (null != (e = this.rewardView()) && e.pendingAttempt ? this.rewarded.openPendingReview() : this.rewarded.openOffer()) : (this.notice = "广告奖励暂不可用", void this.render());
        }, o.renderReward = function () {
          var e,
            t = this,
            i = this.rewardView();
          if (this.themePanel("ui_panel_modal", 375, 667, 660, 800, !0), !i) return this.text("reward-title", "激励视频", 375, 930, 36), this.text("reward-message", "广告组件尚未就绪", 375, 820, 22), void this.button("reward-back", "返回游戏", 185, 540, 380, 96, function () {
            var e;
            return null == (e = t.rewarded) ? void 0 : e.closeOffer();
          });
          var n = "GRANTED" === i.phase ? "奖励已到账" : "ERROR" === i.phase ? "广告奖励" : "额外晃杯";
          this.text("reward-title", n, 375, 950, 38), this.text("reward-stats", "本局奖励 " + i.grantedThisRun + "/" + i.runLimit + "  ·  今日剩余 " + i.dailyRemaining, 375, 870, 22);
          var s = "OFFER" === i.phase ? "观看一段激励视频，本局额外获得 1 次晃杯。\n广告完整看完并保存成功后才计入本局。" : "PREPARING" === i.phase ? "正在准备激励视频…" : "SHOWING" === i.phase ? "广告播放中…" : "SETTLING" === i.phase ? "正在保存奖励…" : "GRANTED" === i.phase ? "奖励已保存。返回后点击“继续”恢复本局。" : null != (e = i.message) ? e : "广告暂时不可用。";
          this.text("reward-message", s, 375, 770, 23), "OFFER" === i.phase ? (this.button("reward-watch", "观看广告 +1 次", 185, 610, 380, 96, function () {
            var e;
            null == (e = t.rewarded) || e.watch();
          }), this.button("reward-cancel", "取消", 185, 480, 380, 96, function () {
            var e;
            return null == (e = t.rewarded) ? void 0 : e.closeOffer();
          })) : "GRANTED" === i.phase ? this.button("reward-continue", "继续游戏", 185, 520, 380, 96, function () {
            var e;
            return null == (e = t.rewarded) ? void 0 : e.acknowledgeGrant();
          }) : "ERROR" === i.phase && (i.retrySettle ? this.button("reward-retry", "重试领取", 185, 610, 380, 96, function () {
            var e;
            null == (e = t.rewarded) || e.retrySettlement();
          }) : i.pendingAttempt && this.button("reward-abandon", "放弃未确认奖励", 185, 610, 380, 96, function () {
            var e;
            null == (e = t.rewarded) || e.abandonPending();
          }), this.button("reward-back", "返回游戏", 185, 470, 380, 96, function () {
            var e;
            return null == (e = t.rewarded) ? void 0 : e.closeOffer();
          })), i.simulated && this.text("reward-mock", "Debug 模拟广告：不会展示真实视频", 375, 370, 20, new d(170, 70, 40));
        }, o.renderRevive = function () {
          var e,
            t,
            i = this,
            n = this.reviveView();
          this.themePanel("ui_panel_modal", 375, 667, 660, 900, !0), this.text("revive-title", "小料洒出来了", 375, 1010, 44, new d(103, 58, 32));
          if (this.text("revive-copy", "分数与进度保留。完整观看激励视频可复活本局一次。\n复活时会清理洒出的小料和杯口危险区，\n成功后 2 秒内不会落新料。", 375, 900, 23), null == (e = this.labels.get("revive-copy")) || null == (e = e.node.getComponent(h)) || e.setContentSize(560, 150), !n) return this.text("revive-status", "复活组件尚未就绪", 375, 790, 22), void this.button("revive-end", "结束本局", 185, 540, 380, 96, function () {
            return i.declineSpillRevive();
          });
          var s = "GRANTED" === n.phase ? "复活成功：分数已保留，点击继续。" : "PREPARING" === n.phase ? "正在准备激励视频…" : "SHOWING" === n.phase ? "广告播放中…" : "SETTLING" === n.phase ? "正在保存复活结果…" : "ERROR" === n.phase ? null != (t = n.message) ? t : "复活流程未完成" : null === n.block ? "本局可复活一次；完整观看后才发放。" : this.reviveBlockText(n.block);
          this.text("revive-status", s, 375, 790, 22), "GRANTED" !== n.phase ? "PREPARING" !== n.phase && "SHOWING" !== n.phase && "SETTLING" !== n.phase && ("ERROR" === n.phase ? (n.retrySettle ? this.button("revive-retry", "重试领取", 185, 620, 380, 96, function () {
            var e;
            null == (e = i.spillRevive) || e.retrySettlement();
          }) : n.pendingAttempt ? this.button("revive-abandon", "放弃未确认奖励", 185, 620, 380, 96, function () {
            var e;
            null == (e = i.spillRevive) || e.abandonPending();
          }) : null === n.block && this.button("revive-rewatch", "重新观看复活", 185, 620, 380, 96, function () {
            var e, t;
            null == (e = i.spillRevive) || e.retryWatch(), null == (t = i.spillRevive) || t.watch();
          }), this.button("revive-end", "结束本局", 185, 490, 380, 96, function () {
            var e;
            return null == (e = i.spillRevive) ? void 0 : e.closeOffer();
          })) : n.pendingAttempt ? (this.text("revive-status", "上次复活广告未得到可信完成确认，未发放。", 375, 790, 22), this.button("revive-abandon", "放弃并结算", 185, 560, 380, 96, function () {
            var e;
            null == (e = i.spillRevive) || e.abandonPending();
          })) : null === n.block ? (this.button("revive-watch", "观看广告复活", 185, 620, 380, 96, function () {
            var e, t;
            null == (e = i.spillRevive) || e.openOffer(), null == (t = i.spillRevive) || t.watch();
          }), this.button("revive-end", "结束本局（正常结算）", 185, 490, 380, 96, function () {
            var e;
            return null == (e = i.spillRevive) ? void 0 : e.closeOffer();
          })) : this.button("revive-end", "结束本局", 185, 520, 380, 96, function () {
            var e;
            return null == (e = i.spillRevive) ? void 0 : e.closeOffer();
          }), n.simulated && this.text("revive-mock", "Debug 模拟广告：不会展示真实视频", 375, 340, 20, new d(170, 70, 40))) : this.button("revive-continue", "继续游戏", 185, 560, 380, 96, function () {
            var e;
            return null == (e = i.spillRevive) ? void 0 : e.acknowledgeGrant();
          });
        }, o.reviveBlockText = function (e) {
          switch (e) {
            case "POLICY_DISABLED":
              return "洒出复活广告尚未开启";
            case "AD_UNCONFIGURED":
              return "未配置真实复活广告位";
            case "AD_UNSUPPORTED":
              return "当前环境不支持激励广告";
            case "NO_ACTIVE_RUN":
            case "NOT_SPILL_PENDING":
              return "当前没有可复活的洒出局";
            case "RUN_LIMIT":
              return "本局已使用过复活";
            case "TUTORIAL_REQUIRED":
              return "完成教程后可观看复活广告";
            case "FIRST_RUN_REQUIRED":
              return "完成一局真实游戏后可观看复活广告";
            case "FOREGROUND_REQUIRED":
              return "游戏时间稍短，暂不可观看复活广告";
            case "PENDING_ATTEMPT":
              return "有未确认的复活奖励";
            default:
              return "暂不可复活";
          }
        }, o.startNew = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee10(e, t, i) {
            var s, r, o, a, l, u, d, h, c, v, p, f, g, w, S, R, m, y, E, b, _, A, O;
            return _regeneratorRuntime().wrap(function _callee10$(_context11) {
              while (1) switch (_context11.prev = _context11.next) {
                case 0:
                  s = this;
                  void 0 === e && (e = !1);
                case 2:
                  if (!this.saveInFlight) {
                    _context11.next = 7;
                    break;
                  }
                  _context11.next = 5;
                  return this.waitForSaveIdle();
                case 5:
                  _context11.next = 2;
                  break;
                case 7:
                  if (!(!this.loading && "PLAYING" !== this.screen)) {
                    _context11.next = 51;
                    break;
                  }
                  this.loading = !0;
                  r = ++this.ownerEpoch, o = this.startupTraceId = C.startup.beginTrace(r);
                  this.notice = "", this.render(), C.startup.stage("START_REQUEST", "start", {
                    code: e ? "memory-only" : "start"
                  }, r, o), this.scheduleOnce(function () {
                    s.loading && s.isOwner() && r === s.ownerEpoch && s.showStartupOverlay("正在准备这杯…", "正在加载杯子与小料，请稍候。", []);
                  }, 0);
                  a = this.art.beginLoadScope(r, o, 15e3, "GAME_ART");
                  _context11.prev = 12;
                  if (this.artReady) {
                    _context11.next = 15;
                    break;
                  }
                  throw new Error("START_ART_FAILED: 美术资源尚未就绪");
                case 15:
                  C.startup.stage("GAME_ART", "start", {
                    assetId: "count:" + this.art.catalog.ids.length
                  }, r, o);
                  _context11.next = 18;
                  return this.loadGameArt();
                case 18:
                  if (!(!this.isOwner() || r !== this.ownerEpoch)) {
                    _context11.next = 20;
                    break;
                  }
                  return _context11.abrupt("return");
                case 20:
                  this.art.settleLoadScope(a), C.startup.stage("GAME_ART", "ok", {
                    assetId: "loaded:" + this.art.loadedCount
                  }, r, o);
                  d = C.rules;
                  this.runBestScoreAtStart = null != (l = null == (u = this.bundle.profile.bestScoresByRules) || null == (u = u[d.design_rules_version]) || null == (u = u.classic) ? void 0 : u.standard) ? l : 0;
                  h = this.makeUuid(), c = null != t ? t : this.seed();
                  C.startup.stage("WORLD_CREATE", "start", {
                    code: "classic"
                  }, r, o);
                  v = this.createWorld(), p = new I(v, d, h, c, void 0, this.reviveOptions());
                  p.setTimingDiagnostics(!1), this.adapter = v, this.engine = p, this.baseTick = 0, this.lastEvents = [], this.consumedDomainEventIds.clear(), this.resultSaved = !1, this.resultError = "", this.screen = "PLAYING", C.startup.stage("RUN_CREATE", "ok", {
                    code: h
                  }, r, o), this.tutorialStep = this.bundle.profile.tutorialRulesVersion === d.design_rules_version ? 0 : 1, this.tutorialReturnScreen = "PLAYING", this.pauseOwners.clear();
                  f = T.snapshot();
                  f.resumeRequired && this.pauseOwners.add("RESUME_REQUIRED"), f.backgrounded && this.pauseOwners.add("HOST_HIDDEN"), this.tutorialStep && (p.pause("MODAL"), this.pauseOwners.add("MODAL"));
                  g = p.snapshot(), w = this.bundle.profile.rewardedShake.pendingAttempt, S = this.bundle.profile.rewardedRevive.pendingAttempt, R = n({}, this.bundle, {
                    profile: n({}, this.bundle.profile, {
                      activeRunId: h,
                      revision: this.bundle.profile.revision + 1,
                      rewardedShake: w && w.runId !== h ? x.clearPending(this.bundle.profile.rewardedShake) : this.bundle.profile.rewardedShake,
                      rewardedRevive: S && S.runId !== h ? G.clearPending(this.bundle.profile.rewardedRevive) : this.bundle.profile.rewardedRevive
                    }),
                    run: g,
                    lastResult: null
                  }), m = this.activeSaveRepository();
                  if (!(C.startup.stage("INITIAL_SAVE", "start", {
                    code: "revision:" + this.bundleRevision
                  }, r, o), !e && m && this.persistent)) {
                    _context11.next = 39;
                    break;
                  }
                  _context11.next = 33;
                  return m.commitBundle(this.bundleRevision, null != (y = null == (E = this.bundle.run) ? void 0 : E.runId) ? y : null, R);
                case 33:
                  A = _context11.sent;
                  if (A.ok) {
                    _context11.next = 36;
                    break;
                  }
                  return _context11.abrupt("return", (C.startup.stage("INITIAL_SAVE", "error", {
                    code: A.error.code,
                    error: A.error
                  }, r, o), p.dispose(), this.engine = null, this.adapter = null, null == (_ = this.world) || _.destroy(), this.world = null, this.clock = null, this.hideOverlay(), this.screen = "ERROR", this.notice = "新局存档失败：" + A.error.message + "。可重试或明确选择仅内存新局。", this.resultError = this.notice, void this.render()));
                case 36:
                  this.bundleRevision = A.data.revision, this.bundle = R, this.notice = null != (b = A.data.warning) ? b : "", C.startup.stage("INITIAL_SAVE", "ok", {
                    code: "revision:" + this.bundleRevision
                  }, r, o);
                  _context11.next = 40;
                  break;
                case 39:
                  this.bundle = R, this.debugMode || (this.persistent = !1), this.notice = this.debugMode ? "" : "仅内存模式：此局不会跨关闭页面保存。", C.startup.stage("INITIAL_SAVE", "ok", {
                    code: e ? "memory-only" : "no-repository"
                  }, r, o);
                case 40:
                  if (!(!this.isOwner() || r !== this.ownerEpoch)) {
                    _context11.next = 42;
                    break;
                  }
                  return _context11.abrupt("return");
                case 42:
                  this.clock = new k(d.physics.fixed_hz, d.physics.max_catchup_steps, function () {
                    return s.advanceRunTick();
                  }), this.pauseOwners.size && (this.pauseOwners.has("MODAL") || (this.engine.pause(this.pauseOwners.has("HOST_HIDDEN") ? "HOST_HIDDEN" : "RESUME_REQUIRED"), this.screen = "PAUSED"), this.clock.pause()), this.previewX = d.cup.center_x_du, this.lastSaveTick = 0, this.resultFinalized = !1, this.resultSaved = !1, this.resultError = "", this.saveDirty = !0, this.bindRewardedShake(), this.bindSpillRevive(), this.render(), this.hideOverlay(), C.startup.stage("HUD_READY", "ok", {
                    assetId: "cup:" + this.art.loadedCount,
                    bundleName: "screen:" + this.screen
                  }, r, o);
                  _context11.next = 48;
                  break;
                case 45:
                  _context11.prev = 45;
                  _context11.t0 = _context11["catch"](12);
                  if (this.art.cancelScope(this.startupErrorCode(_context11.t0), a), this.isOwner() && r === this.ownerEpoch) {
                    O = this.startupErrorCode(_context11.t0);
                    C.startup.stage("START_ART_TIMEOUT" === O ? "GAME_ART" : "WORLD_CREATE", "error", {
                      code: O,
                      error: _context11.t0
                    }, r, o), this.showStartupFailure(O, String(_context11.t0), o);
                  }
                case 48:
                  _context11.prev = 48;
                  this.isOwner() && r === this.ownerEpoch && (this.loading = !1);
                  return _context11.finish(48);
                case 51:
                case "end":
                  return _context11.stop();
              }
            }, _callee10, this, [[12, 45, 48, 51]]);
          }));
          return function (t, i, n) {
            return e.apply(this, arguments);
          };
        }(), o.createWorld = function () {
          var e;
          null != (e = this.world) && e.isValid && this.world.destroy(), this.ingredientViews.clear(), this.shakeArcNodes = [], this.contactPairs.clear(), this.contactObjectTicks.clear(), this.lastContactFeedbackTick = -60, this.world = new u("P1BPhysicsWorld"), this.node.addChild(this.world), this.world.setSiblingIndex(Math.max(0, this.node.children.length - 2)), this.worldId = r.nextWorldId++;
          var t = C.rules,
            i = new A(this.world, t, C.mapper);
          return i.setTimingDiagnostics(!1), i.createCup("classic"), this.createCupArt(), i;
        }, o.createCupArt = function () {
          var e,
            t,
            i,
            n,
            s = C.rules;
          null != (e = this.rear) && e.isValid && this.rear.destroy(), null != (t = this.front) && t.isValid && this.front.destroy(), this.rear = new u("CupRearArt"), this.node.addChild(this.rear), this.rear.setSiblingIndex(Math.max(0, this.node.children.length - 3)), this.front = new u("CupFrontArt"), this.node.addChild(this.front), this.front.setSiblingIndex(Math.max(0, this.node.children.length - 2)), null != (i = this.fixedBackground) && i.isValid && this.fixedBackground.destroy(), this.fixedBackground = this.art.createSprite(this.node, "bg_shop_base", s.viewport.width_du, s.viewport.height_du, !0), this.fixedBackground.name = "FixedShopBackground", this.fixedBackground.setPosition(0, 0, -10), this.fixedBackground.setSiblingIndex(0), this.coverBackground(this.fixedBackground, "bg_shop_base"), this.art.createSprite(this.rear, "spr_cup_shadow", 512, 128).setPosition(0, this.localY(s.cup.inner_bottom_y_du - 30), 0);
          for (var r = 0, o = ["back", "tea", "rim_back"]; r < o.length; r++) {
            var a,
              l = "spr_cup_classic_" + o[r],
              h = this.art.catalog.select(l, 1e3),
              p = null != (a = h.display_size) ? a : h.size,
              f = this.art.createSprite(this.rear, l, p[0], p[1]);
            f.setPosition(-p[0] / 2, this.localY(312), 0), f.setScale(1, .8, 1);
          }
          for (var g = 0, w = ["front", "rim_front", "base", "label"]; g < w.length; g++) {
            var S,
              R = "spr_cup_classic_" + w[g],
              m = this.art.catalog.select(R, 1e3),
              y = null != (S = m.display_size) ? S : m.size,
              E = this.art.createSprite(this.front, R, y[0], y[1]);
            E.setPosition(-y[0] / 2, this.localY(312), 0), E.setScale(1, .8, 1);
          }
          for (var b = 0, _ = [-1, 1]; b < _.length; b++) for (var k = _[b], I = 0; I < 2; I++) {
            var T = new u("CupShakeArc-" + k + "-" + I);
            this.front.addChild(T), T.setPosition(k * (245 + 18 * I), this.localY(875), 2);
            var A = T.addComponent(c);
            A.opacity = 0;
            var O = T.addComponent(v);
            O.lineWidth = 5, O.strokeColor = new d(255, 232, 192, 230), O.arc(0, 0, 16 + 7 * I, k < 0 ? .25 : Math.PI + .25, k < 0 ? 2.9 : Math.PI + 2.9, !1), O.stroke(), this.shakeArcNodes.push({
              node: T,
              opacity: A
            });
          }
          null != (n = this.uiRoot) && n.isValid && this.uiRoot.setSiblingIndex(this.node.children.length - 1);
        }, o.syncCupArt = function () {
          var e,
            t,
            n,
            s,
            r,
            o = this.engine,
            a = null != (e = null == o ? void 0 : o.presentationCupOffsetXDu) ? e : 0,
            l = null != (t = null == o ? void 0 : o.presentationTick) ? t : 0,
            u = null != (n = null == o ? void 0 : o.presentationShakeStartTick) ? n : null,
            d = C.rules,
            h = 0;
          if (null !== u && d) {
            var c = Math.max(0, (l - u) / d.physics.fixed_hz),
              v = d.shake.duration_seconds;
            if (c < v) h = (this.reducedMotion ? Math.min(2, d.shake.visual_offset_max_du) : d.shake.visual_offset_max_du) * Math.pow(Math.sin(Math.PI * c / v), 2) * Math.sin(2 * Math.PI * d.shake.frequency_hz * c);
          }
          var p = a + h;
          null != (s = this.rear) && s.isValid && this.rear.setPosition(p, 0, 0), null != (r = this.front) && r.isValid && this.front.setPosition(p, 0, 0);
          var f = null !== u && d ? (l - u) / d.physics.fixed_hz : -1,
            g = 0;
          d && f >= 0 && f < d.shake.duration_seconds && (g = Math.min(1, f / .1, (d.shake.duration_seconds - f) / .15), this.reducedMotion && (g = Math.min(.55, g)));
          for (var w, S = i(this.shakeArcNodes); !(w = S()).done;) {
            var R = w.value;
            R.node.isValid && (R.opacity.opacity = Math.max(0, Math.round(255 * g)));
          }
        }, o.localY = function (e) {
          return e - C.rules.viewport.height_du / 2;
        }, o.syncViews = function (e) {
          var t,
            n = this;
          if (e && this.adapter && null != (t = this.world) && t.isValid) {
            for (var s, r = new Set(e.map(function (e) {
                return e.entityId;
              })), o = i(this.ingredientViews); !(s = o()).done;) {
              var a = s.value,
                l = a[0],
                u = a[1];
              r.has(l) && u.isValid || (u.isValid && u.destroy(), this.ingredientViews["delete"](l));
            }
            for (var d, h = function h() {
                var e,
                  t = d.value,
                  i = n.ingredientViews.get(t.entityId);
                if (null == (e = i) || !e.isValid) {
                  var s = C.rules.ingredients.find(function (e) {
                    return e.level === t.level;
                  });
                  (i = n.art.createSprite(n.world, D.ingredientId(s.id), D.ingredientEdgeDu(s.radius_du), D.ingredientEdgeDu(s.radius_du), !0)).name = "P1BIngredientVisual-" + t.entityId, n.ingredientViews.set(t.entityId, i);
                }
                i.setPosition(t.positionDu.x - C.rules.viewport.width_du / 2, t.positionDu.y - C.rules.viewport.height_du / 2, 0), i.angle = 180 * t.angleRadians / Math.PI;
              }, c = i(e); !(d = c()).done;) h();
          }
        }, o.processEvents = function () {
          if (this.lastEvents.length) {
            for (var e, t = i(this.lastEvents); !(e = t()).done;) {
              var n,
                s,
                r = e.value;
              if (!this.consumedDomainEventIds.has(r.eventId)) {
                var o, a, l, u, h, c, v, p, f, g, w;
                if (this.consumedDomainEventIds.add(r.eventId), this.consumedDomainEventIds.size > 4096 && this.consumedDomainEventIds["delete"](this.consumedDomainEventIds.values().next().value), "IngredientDropped" !== r.kind && "MergeCommitted" !== r.kind && "ShakeConsumed" !== r.kind || (this.saveDirty = !0), "IngredientDropped" === r.kind && (null == (n = this.audio) || n.play("drop")), "MergeCommitted" === r.kind) this.showMergeFeedback(r.positionDu, r.scoreDelta), null == (o = this.effects) || o.play("merge", r.positionDu.x, r.positionDu.y, r.eventId, this.reducedMotion), null == (a = this.effects) || a.play("combo", r.positionDu.x, r.positionDu.y + 72, r.eventId, this.reducedMotion);
                if ("MergeCommitted" === r.kind && (null == (s = this.audio) || s.play(r.childLevel <= 4 ? "merge_small" : "merge_large")), "ShakeConsumed" === r.kind) this.showTextFeedback("轻晃", 375, 1015, new d(247, 192, 115)), null == (l = this.effects) || l.play("tap", 375, 1015, r.eventId, this.reducedMotion), null == (u = this.audio) || u.play("shake_start");
                if ("DangerChanged" === r.kind && r.dangerTicks > 0 && r.tick - this.lastDangerCueTick >= 60) this.lastDangerCueTick = r.tick, null == (h = this.effects) || h.play("danger", 375, 740, r.eventId, !0), null == (c = this.audio) || c.play("danger_tick");
                if ("SpillReviveOffered" === r.kind) null == (v = this.audio) || v.play("result"), null == (p = this.effects) || p.play("result", 375, 805, r.eventId, this.reducedMotion), this.enterSpillOffer();
                if ("RunEnded" === r.kind) null == (f = this.audio) || f.play("result"), null == (g = this.effects) || g.play("result", 375, 805, r.eventId, this.reducedMotion), this.screen = "RESULTS", null == (w = this.clock) || w.pause(), this.resultSaved = !1, this.resultFinalized = !1;
              }
            }
            this.lastEvents.length = 0;
          }
        }, o.waitForSaveIdle = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee11() {
            var e;
            return _regeneratorRuntime().wrap(function _callee11$(_context12) {
              while (1) switch (_context12.prev = _context12.next) {
                case 0:
                  e = this;
                  _context12.t0 = this.saveInFlight;
                  if (!_context12.t0) {
                    _context12.next = 5;
                    break;
                  }
                  _context12.next = 5;
                  return new Promise(function (t) {
                    return e.saveIdleWaiters.push(t);
                  });
                case 5:
                case "end":
                  return _context12.stop();
              }
            }, _callee11, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.activeSaveRepository = function () {
          return this.debugMode ? this.debugRepo : this.persistent ? this.repo : null;
        }, o.adSaveRepository = function () {
          var e = this,
            t = function t() {
              var t;
              return null != (t = e.activeSaveRepository()) ? t : e.repo;
            };
          return {
            readBundle: function readBundle() {
              return t().readBundle();
            },
            commitBundle: function commitBundle(e, i, n) {
              return t().commitBundle(e, i, n);
            },
            acquireWriteLease: function acquireWriteLease() {
              return t().acquireWriteLease();
            }
          };
        }, o.beginSaveTask = function () {
          if (0 !== this.activeSaveTaskId) return null;
          var e = ++this.saveTaskSequence;
          return this.activeSaveTaskId = e, this.saveInFlight = !0, e;
        }, o.ownsSaveTask = function (e, t) {
          return this.activeSaveTaskId === e && t === this.ownerEpoch && this.isOwner();
        }, o.finishSaveTask = function (e) {
          var t;
          if (this.activeSaveTaskId === e) {
            this.activeSaveTaskId = 0, this.saveInFlight = !1;
            for (var n, s = this.saveIdleWaiters.splice(0), r = i(s); !(n = r()).done;) {
              (0, n.value)();
            }
            if (this.isOwner()) {
              if ("SETTLING" !== (null == (t = this.engine) ? void 0 : t.phase)) return this.settingsDirty && this.activeSaveRepository() ? (this.settingsDirty = !1, void this.persistSettings()) : void (this.saveDirty && this.activeSaveRepository() && this.engine && this.commitCheckpoint(!0));
              this.resultFinalized ? this.saveDirty = !1 : this.commitResult();
            }
          }
        }, o.commitCheckpoint = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee12(e) {
            var t, i, s, r, o, a, l, u, d, h, c, v, p, f, g, w, S, R, m, y, E, b, _, k;
            return _regeneratorRuntime().wrap(function _callee12$(_context13) {
              while (1) switch (_context13.prev = _context13.next) {
                case 0:
                  s = this.activeSaveRepository();
                  if (!(this.engine && s)) {
                    _context13.next = 37;
                    break;
                  }
                  if (!this.saveInFlight) {
                    _context13.next = 6;
                    break;
                  }
                  this.saveDirty = !0;
                  _context13.next = 35;
                  break;
                case 6:
                  r = this.beginSaveTask();
                  if (!(null !== r)) {
                    _context13.next = 34;
                    break;
                  }
                  this.saveDirty = !1;
                  o = this.ownerEpoch, a = this.engine.snapshot().runId, l = this.bundleRevision, u = null != (t = null == (i = this.bundle.run) ? void 0 : i.runId) ? t : null;
                  _context13.prev = 10;
                  S = L.sealSnapshot(this.engine.snapshot());
                  R = S.score;
                  m = S.rulesVersion;
                  y = "assisted" === S.boardType ? "assisted" : "standard";
                  E = null != (d = null == (h = this.bundle.profile.bestScoresByRules) || null == (h = h[m]) || null == (h = h.classic) ? void 0 : h[y]) ? d : 0;
                  b = n({}, this.bundle.profile, {
                    activeRunId: S.runId,
                    discoveredLevels: Array.from(new Set([].concat(this.bundle.profile.discoveredLevels, S.ingredients.map(function (e) {
                      return e.level;
                    })))).sort(),
                    bestScoresByRules: n({}, this.bundle.profile.bestScoresByRules, (f = {}, f[m] = n({}, null == (c = this.bundle.profile.bestScoresByRules) ? void 0 : c[m], {
                      classic: n({}, null == (v = this.bundle.profile.bestScoresByRules) || null == (v = v[m]) ? void 0 : v.classic, (p = {}, p[y] = Math.max(E, R), p))
                    }), f)),
                    revision: this.bundle.profile.revision + 1
                  });
                  _ = n({}, this.bundle, {
                    profile: b,
                    run: S
                  });
                  _context13.next = 20;
                  return s.commitBundle(l, u, _);
                case 20:
                  k = _context13.sent;
                  if (!(!this.ownsSaveTask(r, o) || (null == (g = this.engine) ? void 0 : g.snapshot().runId) !== a)) {
                    _context13.next = 23;
                    break;
                  }
                  return _context13.abrupt("return");
                case 23:
                  if (k.ok) this.bundle = _, this.bundleRevision = k.data.revision, k.data.warning && (this.notice = k.data.warning), this.lastSaveTick = S.tick;else if (this.saveDirty = !1, this.notice = "保存未完成：" + k.error.message, "CONFLICT_REVISION" === k.error.code) this.engine.pause("TECHNICAL_ERROR"), null == (w = this.clock) || w.pause(), this.pauseOwners.add("TECHNICAL_ERROR"), this.cancelPointer(), this.screen = "PAUSED", this.notice = "存档版本冲突；为保护现有存档，本局已冻结。请重新开始或重新加载。";
                  _context13.next = 29;
                  break;
                case 26:
                  _context13.prev = 26;
                  _context13.t0 = _context13["catch"](10);
                  this.ownsSaveTask(r, o) && (this.saveDirty = !0, this.notice = "保存失败：" + String(_context13.t0));
                case 29:
                  _context13.prev = 29;
                  this.finishSaveTask(r);
                  return _context13.finish(29);
                case 32:
                  _context13.next = 35;
                  break;
                case 34:
                  this.saveDirty = !0;
                case 35:
                  _context13.next = 38;
                  break;
                case 37:
                  this.saveDirty = !1;
                case 38:
                case "end":
                  return _context13.stop();
              }
            }, _callee12, this, [[10, 26, 29, 32]]);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), o.commitResult = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee13() {
            var e, t, i, s, r, o, a, l, u, d, h, c, v, p, f, g, w, S, R, m, y, E, b, _;
            return _regeneratorRuntime().wrap(function _callee13$(_context14) {
              while (1) switch (_context14.prev = _context14.next) {
                case 0:
                  if (!(this.engine && !this.saveInFlight && !this.resultFinalized)) {
                    _context14.next = 28;
                    break;
                  }
                  u = this.beginSaveTask();
                  if (!(null !== u)) {
                    _context14.next = 28;
                    break;
                  }
                  d = this.ownerEpoch, h = this.engine.snapshot().runId;
                  this.screen = "RESULTS", null == (e = this.clock) || e.pause(), this.render();
                  c = L.sealSnapshot(this.engine.snapshot()), v = null != (t = c.terminalReason) ? t : "ABANDONED", p = c.rulesVersion, f = "assisted" === c.boardType ? "assisted" : "standard", g = this.bundle.profile.rewardedShake.pendingAttempt, w = this.bundle.profile.rewardedRevive.pendingAttempt, S = {
                    profile: n({}, this.bundle.profile, {
                      activeRunId: null,
                      revision: this.bundle.profile.revision + 1,
                      firstNaturalRunCompleted: this.bundle.profile.firstNaturalRunCompleted || "standard" === c.boardType && ("CUP_FULL" === v || "SPILLED" === v),
                      rewardedShake: g && g.runId === c.runId ? x.clearPending(this.bundle.profile.rewardedShake) : this.bundle.profile.rewardedShake,
                      rewardedRevive: w && w.runId === c.runId ? G.clearPending(this.bundle.profile.rewardedRevive) : this.bundle.profile.rewardedRevive,
                      bestScoresByRules: n({}, this.bundle.profile.bestScoresByRules, (l = {}, l[p] = n({}, null == (i = this.bundle.profile.bestScoresByRules) ? void 0 : i[p], {
                        classic: n({}, null == (s = this.bundle.profile.bestScoresByRules) || null == (s = s[p]) ? void 0 : s.classic, (a = {}, a[f] = Math.max(null != (r = null == (o = this.bundle.profile.bestScoresByRules) || null == (o = o[p]) || null == (o = o.classic) ? void 0 : o[f]) ? r : 0, c.score), a))
                      }), l))
                    }),
                    run: null,
                    lastResult: {
                      runId: c.runId,
                      reason: v,
                      score: c.score,
                      maxLevel: c.maxLevel,
                      dropIndex: c.dropIndex,
                      baseUsed: c.shake.baseUsed,
                      extraUsed: c.shake.extraUsed,
                      boardType: c.boardType,
                      rulesVersion: p
                    }
                  };
                  _context14.prev = 6;
                  m = this.activeSaveRepository();
                  if (!m) {
                    _context14.next = 17;
                    break;
                  }
                  _context14.next = 11;
                  return m.commitBundle(this.bundleRevision, null != (y = null == (E = this.bundle.run) ? void 0 : E.runId) ? y : null, S);
                case 11:
                  _ = _context14.sent;
                  if (!(!this.ownsSaveTask(u, d) || (null == (b = this.engine) ? void 0 : b.snapshot().runId) !== h)) {
                    _context14.next = 14;
                    break;
                  }
                  return _context14.abrupt("return");
                case 14:
                  if (_.ok) {
                    _context14.next = 16;
                    break;
                  }
                  throw new Error(_.error.message);
                case 16:
                  this.bundleRevision = _.data.revision, _.data.warning && (this.resultError = _.data.warning);
                case 17:
                  if (!(!this.ownsSaveTask(u, d) || (null == (R = this.engine) ? void 0 : R.snapshot().runId) !== h)) {
                    _context14.next = 19;
                    break;
                  }
                  return _context14.abrupt("return");
                case 19:
                  this.bundle = S, this.resultSaved = !!this.activeSaveRepository(), this.resultFinalized = !0, this.resultError = this.resultSaved ? this.resultError : "仅内存模式，结果未保存。";
                  _context14.next = 25;
                  break;
                case 22:
                  _context14.prev = 22;
                  _context14.t0 = _context14["catch"](6);
                  this.ownsSaveTask(u, d) && (this.resultError = "结果尚未保存：" + String(_context14.t0), this.notice = this.resultError, this.resultFinalized = !0);
                case 25:
                  _context14.prev = 25;
                  this.ownsSaveTask(u, d) && (this.screen = "RESULTS", this.render()), this.finishSaveTask(u);
                  return _context14.finish(25);
                case 28:
                case "end":
                  return _context14.stop();
              }
            }, _callee13, this, [[6, 22, 25, 28]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.retryResultSave = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee14() {
            var e;
            return _regeneratorRuntime().wrap(function _callee14$(_context15) {
              while (1) switch (_context15.prev = _context15.next) {
                case 0:
                  _context15.t0 = "SETTLING" !== (null == (e = this.engine) ? void 0 : e.phase) || this.saveInFlight || this.resultSaved;
                  if (_context15.t0) {
                    _context15.next = 5;
                    break;
                  }
                  this.resultFinalized = !1;
                  _context15.next = 5;
                  return this.commitResult();
                case 5:
                case "end":
                  return _context15.stop();
              }
            }, _callee14, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.continueRun = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee15() {
            var e, t, i, n, s, r, o, a;
            return _regeneratorRuntime().wrap(function _callee15$(_context16) {
              while (1) switch (_context16.prev = _context16.next) {
                case 0:
                  s = /FIXTURE_(?:CREATE_CHILD|SECOND_COMMIT)_ONCE/.test(null != (e = null == (t = this.engine) ? void 0 : t.lastTickFault) ? e : "");
                  if (!(null != (i = this.engine) && i.lastTickFault && !s)) {
                    _context16.next = 3;
                    break;
                  }
                  return _context16.abrupt("return", (this.notice = "本局发生物理事务异常并已冻结。请重新开始；原完整存档边界已保留。", void this.render()));
                case 3:
                  if (!(!this.loading && this.engine && this.clock)) {
                    _context16.next = 17;
                    break;
                  }
                  r = T.snapshot();
                  if (!(r.backgrounded || this.pauseOwners.has("HOST_HIDDEN"))) {
                    _context16.next = 7;
                    break;
                  }
                  return _context16.abrupt("return", (this.notice = "当前仍在后台，不能继续。", void this.render()));
                case 7:
                  if (!(this.pauseOwners.has("AD") || this.pauseOwners.has("MODAL") || this.pauseOwners.has("TECHNICAL_ERROR") && !s || this.pauseOwners.has("RESTORING"))) {
                    _context16.next = 9;
                    break;
                  }
                  return _context16.abrupt("return", (this.notice = "请先关闭弹窗或处理错误后再继续。", void this.render()));
                case 9:
                  if (!(s && this.pauseOwners["delete"]("TECHNICAL_ERROR"), r.resumeRequired)) {
                    _context16.next = 13;
                    break;
                  }
                  o = T.confirmUserResume(r.hideEpoch, !0, !0, !0);
                  if (o.ok) {
                    _context16.next = 13;
                    break;
                  }
                  return _context16.abrupt("return", (this.notice = "暂时不能继续：" + o.reason, void this.render()));
                case 13:
                  a = this.engine.resume();
                  if (a.ok) {
                    _context16.next = 16;
                    break;
                  }
                  return _context16.abrupt("return", (this.notice = a.error.message, void this.render()));
                case 16:
                  this.pauseOwners.clear(), this.clock.resume(), null == (n = this.audio) || n.resumeAfterUserGesture(), this.screen = "PLAYING", this.notice = "已继续；后台时间不会补算。", this.saveDirty = !0, this.render();
                case 17:
                case "end":
                  return _context16.stop();
              }
            }, _callee15, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.togglePause = function () {
          var e, t;
          "PLAYING" === this.screen ? (null == (e = this.engine) || e.pause("MANUAL"), null == (t = this.clock) || t.pause(), this.pauseOwners.add("MANUAL"), this.cancelPointer(), this.screen = "PAUSED", this.notice = "已暂停。", this.saveDirty = !0, this.commitCheckpoint(!0), this.render()) : "PAUSED" === this.screen && this.continueRun();
        }, o.resumeByUser = function () {
          "PAUSED" === this.screen && this.continueRun();
        }, o.isModalScreen = function () {
          return "SETTINGS" === this.screen || "CONFIRM_RESTART" === this.screen || "CONFIRM_MENU" === this.screen || "REWARD" === this.screen || "REVIVE" === this.screen;
        }, o.openModal = function (e) {
          var t,
            i = this;
          (this.cancelPointer(), "SETTINGS" === e && (this.settingsReturnScreen = this.engine ? "PAUSED" : "MENU"), this.pauseOwners.add("MODAL"), this.engine) && (this.engine.pause("MODAL"), null == (t = this.clock) || t.pause());
          if (this.screen = e, this.render(), "SETTINGS" === e) {
            var n,
              s,
              r = this.ownerEpoch,
              o = this.art.beginLoadScope(r, this.startupTraceId, 15e3, "SETTINGS_UI");
            this.settingsArtBudget = o;
            var a = (null != (n = null == (s = this.art.catalog) ? void 0 : s.ids) ? n : []).filter(function (e) {
              return e.startsWith("ui_");
            });
            this.loadArtBatch(a).then(function () {
              i.art.settleLoadScope(o), i.settingsArtBudget === o && (i.settingsArtBudget = null), i.isOwner() && r === i.ownerEpoch && "SETTINGS" === i.screen && i.render();
            }, function () {
              i.art.cancelScope("SETTINGS_ART_CANCELLED", o), i.settingsArtBudget === o && (i.settingsArtBudget = null), i.isOwner() && r === i.ownerEpoch && "SETTINGS" === i.screen && (i.notice = "部分设置图片加载失败，文字控件仍可操作。", i.render());
            });
          }
        }, o.cancelSettingsArtScope = function () {
          var e = this.settingsArtBudget;
          this.settingsArtBudget = null, e && this.art.cancelScope("SETTINGS_ART_CANCELLED", e);
        }, o.closeModal = function () {
          this.cancelSettingsArtScope(), this.pauseOwners["delete"]("MODAL"), this.cancelPointer(), this.screen = "SETTINGS" === this.screen ? this.settingsReturnScreen : this.engine ? "PAUSED" : "MENU", this.render();
        }, o.restartConfirmed = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee16() {
            var e, t, i, n, s;
            return _regeneratorRuntime().wrap(function _callee16$(_context17) {
              while (1) switch (_context17.prev = _context17.next) {
                case 0:
                  s = this.ownerEpoch;
                case 1:
                  if (!this.saveInFlight) {
                    _context17.next = 6;
                    break;
                  }
                  _context17.next = 4;
                  return this.waitForSaveIdle();
                case 4:
                  _context17.next = 1;
                  break;
                case 6:
                  _context17.t0 = this.isOwner() && s === this.ownerEpoch;
                  if (!_context17.t0) {
                    _context17.next = 21;
                    break;
                  }
                  null == (e = this.engine) || e.pause("MANUAL");
                  null == (t = this.clock) || t.pause();
                  null == (i = this.engine) || i.dispose();
                  this.engine = null;
                  this.adapter = null;
                  this.clock = null;
                  null == (n = this.world) || n.destroy();
                  this.world = null;
                  this.ownerEpoch++;
                  this.screen = "MENU";
                  this.render();
                  _context17.next = 21;
                  return this.startNew();
                case 21:
                case "end":
                  return _context17.stop();
              }
            }, _callee16, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.returnToMenuConfirmed = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee17() {
            var e, t, i, n;
            return _regeneratorRuntime().wrap(function _callee17$(_context18) {
              while (1) switch (_context18.prev = _context18.next) {
                case 0:
                  i = this.ownerEpoch;
                case 1:
                  if (!this.saveInFlight) {
                    _context18.next = 6;
                    break;
                  }
                  _context18.next = 4;
                  return this.waitForSaveIdle();
                case 4:
                  _context18.next = 1;
                  break;
                case 6:
                  if (!(this.isOwner() && i === this.ownerEpoch)) {
                    _context18.next = 23;
                    break;
                  }
                  if (!(this.engine && !this.resultSaved)) {
                    _context18.next = 22;
                    break;
                  }
                  n = this.engine.abandon();
                  _context18.t0 = n;
                  if (!_context18.t0) {
                    _context18.next = 15;
                    break;
                  }
                  this.lastEvents.push(n);
                  this.processEvents();
                  _context18.next = 15;
                  return this.commitResult();
                case 15:
                  if (!this.saveInFlight) {
                    _context18.next = 20;
                    break;
                  }
                  _context18.next = 18;
                  return this.waitForSaveIdle();
                case 18:
                  _context18.next = 15;
                  break;
                case 20:
                  if (!(!this.isOwner() || i !== this.ownerEpoch || !this.resultSaved && this.activeSaveRepository())) {
                    _context18.next = 22;
                    break;
                  }
                  return _context18.abrupt("return", (this.notice = this.resultError || "结果仍未保存，保留当前局面供重试。", void this.render()));
                case 22:
                  null == (e = this.engine) || e.dispose(), this.engine = null, this.adapter = null, this.clock = null, null == (t = this.world) || t.destroy(), this.screen = "MENU", this.render();
                case 23:
                case "end":
                  return _context18.stop();
              }
            }, _callee17, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.startupErrorCode = function (e) {
          var t = (e instanceof Error ? e.message : String(e)).match(/START_[A-Z_]+/);
          return t ? t[0] : "START_ART_FAILED";
        }, o.clearOverlay = function () {
          var e;
          if (this.overlayButtons = [], this.overlayVisible = !1, null != (e = this.overlayRoot) && e.isValid) for (var t = 0, i = [].concat(this.overlayRoot.children); t < i.length; t++) {
            i[t].destroy();
          }
        }, o.hideOverlay = function () {
          this.clearOverlay();
        }, o.showStartupOverlay = function (e, t, i) {
          var n,
            s = this;
          if (null != (n = this.overlayRoot) && n.isValid) {
            this.clearOverlay(), this.overlayVisible = !0;
            var r = q(),
              o = this.overlayRoot,
              a = new u("StartupOverlayDim");
            o.addChild(a), a.addComponent(h).setContentSize(r.width, r.height);
            var l = a.addComponent(v);
            l.fillColor = new d(24, 18, 14, 205), l.rect(-r.width / 2, -r.height / 2, r.width, r.height), l.fill();
            var c = new u("StartupOverlayTitle");
            o.addChild(c), c.addComponent(h).setContentSize(680, 70), c.setPosition(0, 180, 0);
            var f = c.addComponent(p);
            f.string = e, f.fontSize = 38, f.lineHeight = 46, f.isBold = !0, f.color = new d(255, 244, 225);
            var g = new u("StartupOverlayDetail");
            o.addChild(g), g.addComponent(h).setContentSize(620, 150), g.setPosition(0, 70, 0);
            var w = g.addComponent(p);
            w.string = t, w.fontSize = 22, w.lineHeight = 30, w.color = new d(235, 220, 200), w.overflow = p.Overflow.CLAMP, w.enableWrapText = !0, i.forEach(function (e, t) {
              var i = new u("StartupOverlayButton-" + e.id);
              o.addChild(i);
              var n = 430,
                r = 88,
                a = 70 - 118 * (t + 1);
              i.setPosition(0, a, 0), i.addComponent(h).setContentSize(n, r);
              var l = i.addComponent(v);
              l.fillColor = new d(255, 207, 75), l.roundRect(-215, -44, n, r, 22), l.fill();
              var c = new u("Label");
              i.addChild(c), c.addComponent(h).setContentSize(406, 76);
              var f = c.addComponent(p);
              f.string = e.label, f.fontSize = 28, f.lineHeight = 34, f.isBold = !0, f.color = new d(103, 58, 32), f.overflow = p.Overflow.SHRINK, f.enableWrapText = !0, s.overlayButtons.push({
                id: e.id,
                label: e.label,
                rect: {
                  x: 160,
                  y: 667 + a - 44,
                  w: n,
                  h: r
                },
                action: e.action
              });
            });
          }
        }, o.showStartupFailure = function (e, t, i) {
          var n = this;
          this.screen = "ERROR", this.notice = e + "：" + t, this.loading = !1, this.artLoading = !1, this.render();
          this.showStartupOverlay("暂时无法开始", e + "\n" + t.slice(0, 180), [{
            id: "startup-retry",
            label: "重试准备",
            action: function action() {
              e.startsWith("START_ART") || !n.artReady ? n.retryArtAndStart() : n.startNew();
            }
          }, {
            id: "startup-menu",
            label: "返回菜单",
            action: function action() {
              return n.returnToMenuFromError();
            }
          }, {
            id: "startup-diagnostic",
            label: "查看诊断",
            action: function action() {
              return n.showStartupDiagnostics(i);
            }
          }]);
        }, o.returnToMenuFromError = function () {
          var e, t;
          this.cancelPointer(), this.clearOverlay(), this.pauseOwners.clear(), null == (e = this.engine) || e.dispose(), this.engine = null, this.adapter = null, this.clock = null, null == (t = this.world) || t.destroy(), this.world = null, this.ingredientViews.clear(), this.shakeArcNodes = [], this.lastEvents = [], this.consumedDomainEventIds.clear(), this.tutorialStep = 0, this.resultFinalized = !1, this.resultSaved = !1, this.resultError = "", this.saveDirty = !1, this.renderFailureShown = !1, this.screen = "MENU", this.notice = "", this.render();
        }, o.showStartupDiagnostics = function (e) {
          var t = this,
            i = C.startup.latest(32).map(function (e) {
              return "#" + e.value.traceId + " " + e.value.phase + " " + e.value.result + (e.value.code ? " " + e.value.code : "");
            }),
            n = "构建 " + C.buildId + "\ntrace " + e + " · 最近 " + i.length + " 条\n" + i.slice(-10).join("\n");
          try {
            console.info("[startup-trace]", C.startup.exportJson());
          } catch (e) {}
          this.showStartupOverlay("启动诊断", n, [{
            id: "startup-back",
            label: "返回",
            action: function action() {
              return t.hideOverlay();
            }
          }]);
        }, o.render = function () {
          try {
            this.renderUnsafe(), this.renderFailureShown = !1;
          } catch (n) {
            if (this.renderFailureShown) return;
            this.renderFailureShown = !0;
            try {
              C.startup.stage("RENDER", "error", {
                code: "RENDER_FAILED",
                error: n
              }, this.ownerEpoch, this.startupTraceId);
            } catch (e) {}
            try {
              var e;
              if (null != (e = this.uiRoot) && e.isValid) for (var t = 0, i = [].concat(this.uiRoot.children); t < i.length; t++) {
                i[t].destroy();
              }
              this.buttons = [], this.buttonSkins.clear();
            } catch (e) {}
            this.showStartupFailure("RENDER_FAILED", "界面渲染失败：" + String(n), this.startupTraceId);
          }
        }, o.renderUnsafe = function () {
          var e,
            t,
            i,
            n,
            s = this;
          if (null != (e = this.uiRoot) && e.isValid) {
            this.buttons = [], this.buttonSkins.clear(), this.previewGraphic = null;
            for (var r = 0, o = [].concat(this.uiRoot.children); r < o.length; r++) {
              o[r].destroy();
            }
            if (this.labels.clear(), this.artLoading) return this.themeBackground(!0), this.art.getLoadedVariant("ui_title_logo") ? this.themeSprite("ui_title_logo", 375, 900, 640, 224) : this.text("loading-brand", "奶茶挤挤", 375, 900, 72, new d(103, 58, 32)), this.text("loading", "正在准备杯子与小料…", 375, 480, 28), this.button("loading-start", "开始新局", 135, 330, 480, 104, function () {
              s.pendingStartRequested = !0, s.notice = "已收到开始请求，准备完成后立即进入游戏。", s.render();
            }), this.notice && (this.themePanel("ui_panel_toast", 375, 200, 670, 96), this.text("loading-notice", this.notice, 375, 200, 22)), void this.drawButtons();
            "MENU" !== this.screen && "SETTINGS" !== this.screen && "ERROR" !== this.screen && null != (t = this.world) && t.isValid || this.themeBackground("MENU" === this.screen), "MENU" === this.screen ? this.renderMenu() : "PLAYING" === this.screen ? this.renderGame() : "PAUSED" === this.screen ? this.renderPause() : "SETTINGS" === this.screen ? this.renderSettings() : "CONFIRM_RESTART" === this.screen || "CONFIRM_MENU" === this.screen ? this.renderConfirm() : "RESULTS" === this.screen ? this.renderResults() : "REWARD" === this.screen ? this.renderReward() : "REVIVE" === this.screen ? this.renderRevive() : this.renderError(), this.tutorialStep > 0 && this.renderTutorial(), this.drawButtons(), "MENU" === this.screen ? null == (i = this.effects) || i.ensureCat(620, 820) : null == (n = this.effects) || n.hideCat();
          }
        }, o.themeSprite = function (e, t, i, n, s, r) {
          if (void 0 === r && (r = this.uiRoot), !this.art.getLoadedVariant(e)) return null;
          var o = this.art.createSprite(r, e, n, s, !0);
          return o.setPosition(t - 375, i - 667, 0), o;
        }, o.themeBackground = function (e) {
          void 0 === e && (e = !1);
          var t = e ? "bg_brand" : "bg_shop_base",
            i = this.themeSprite(t, 375, 667, 750, 1334);
          if (i) return i.name = "ScreenBackground:" + t, void this.coverBackground(i, t);
          var n = q(),
            s = new u("CreamBackground");
          this.uiRoot.addChild(s), s.addComponent(h).setContentSize(n.width, n.height);
          var r = s.addComponent(v);
          r.fillColor = new d(255, 244, 225), r.rect(-n.width / 2, -n.height / 2, n.width, n.height), r.fill();
        }, o.coverBackground = function (e, t) {
          var i = this.art.getLoadedVariant(t);
          if (i) {
            var n = q(),
              s = Math.max(n.width / i.size[0], n.height / i.size[1]),
              r = e.getComponent(h),
              o = i.size[0] * s,
              a = i.size[1] * s;
            (Math.abs(r.width - o) > .001 || Math.abs(r.height - a) > .001) && r.setContentSize(o, a);
          }
        }, o.syncViewportBackgrounds = function () {
          var e;
          null != (e = this.fixedBackground) && e.isValid && this.coverBackground(this.fixedBackground, "bg_shop_base");
          for (var t, n = q(), s = i(null != (r = null == (o = this.uiRoot) ? void 0 : o.children) ? r : []); !(t = s()).done;) {
            var r,
              o,
              a = t.value;
            if (a.name.startsWith("ScreenBackground:")) this.coverBackground(a, a.name.substring("ScreenBackground:".length));else if ("ModalDim" === a.name || "CreamBackground" === a.name) {
              var l = a.getComponent(h),
                u = a.getComponent(v);
              l && u && (l.width !== n.width || l.height !== n.height) && (l.setContentSize(n.width, n.height), u.clear(), u.rect(-n.width / 2, -n.height / 2, n.width, n.height), u.fill());
            }
          }
        }, o.themePanel = function (e, t, i, n, s, r) {
          if (void 0 === r && (r = !1), r) {
            var o = q(),
              a = new u("ModalDim");
            this.uiRoot.addChild(a), a.addComponent(h).setContentSize(o.width, o.height);
            var l = a.addComponent(v);
            l.fillColor = new d(62, 34, 21, 130), l.rect(-o.width / 2, -o.height / 2, o.width, o.height), l.fill();
          }
          this.themeSprite(e, t, i, n, s);
        }, o.setButtonState = function (e, t) {
          var i = this.buttonSkins.get(e);
          null != i && i.node.isValid && this.art.setSpriteAsset(i.node, "ui_btn_" + i.family + "_" + t);
        }, o.renderMenu = function () {
          var e,
            t,
            i,
            n,
            s,
            r = this;
          this.themeSprite("ui_title_logo", 375, 1170, 650, 228), this.text("subtitle", "经典杯 · 挤出一杯好心情", 375, 1038, 28), this.themePanel("ui_panel_hud", 375, 962, 460, 74), this.text("record", "个人纪录  " + (null != (e = null == (t = this.bundle.profile.bestScoresByRules) || null == (t = t[null != (i = null == (n = C.rules) ? void 0 : n.design_rules_version) ? i : ""]) || null == (t = t.classic) ? void 0 : t.standard) ? e : 0), 375, 962, 30);
          var o = !!this.bundle.run && this.bundle.run.rulesVersion !== (null == (s = C.rules) ? void 0 : s.design_rules_version);
          this.bundle.run && this.button("continue", o ? "旧版局已保留" : "继续上局", 135, 354, 480, 100, function () {
            o ? (r.notice = "旧版局已保留，不能放入新杯；开始新杯前可随时返回。", r.render()) : r.restoreRun();
          }), this.button("new", "开始新局", 135, this.bundle.run ? 226 : 354, 480, 100, function () {
            return o ? r.openModal("CONFIRM_RESTART") : void r.startNew();
          }), this.button("settings", "游戏设置", 245, 102, 260, 90, function () {
            return r.openModal("SETTINGS");
          }), o && this.text("legacy-save", "旧局已保留，确认新杯后才替换旧局。", 375, 530, 23), this.persistent || this.text("storage", "当前仅内存模式，关闭后可能无法续局", 375, 65, 22), this.notice && (this.themePanel("ui_panel_toast", 375, 485, 670, 96), this.text("notice", this.notice, 375, 485, 23));
        }, o.renderGame = function () {
          var e,
            t,
            i,
            n,
            s = this,
            r = null == (e = this.engine) ? void 0 : e.snapshot();
          if (r) {
            this.themePanel("ui_panel_hud", 375, 1265, 700, 88), this.text("score", "分数 " + r.score + "  ·  纪录 " + (null != (t = null == (i = this.bundle.profile.bestScoresByRules) || null == (i = i[r.rulesVersion]) || null == (i = i.classic) ? void 0 : i.standard) ? t : 0), 375, 1265, 32), this.themePanel("ui_panel_hud", 338, 1175, 600, 76), this.text("next", "当前 " + this.levelName(r.currentLevel) + "  ·  最高 " + this.levelName(r.maxLevel), 330, 1175, 25), this.themePanel("ui_panel_next", 665, 1135, 110, 110), this.themeSprite(D.ingredientId(C.rules.ingredients[r.nextLevel - 1].id), 665, 1135, 76, 76), this.text("danger", r.dangerTicks ? "快满了 · " + Math.max(1, 3 - Math.floor(r.dangerTicks / 60)) : "同级相遇，合成更大颗", 375, 1100, 25, r.dangerTicks ? new d(185, 54, 43) : new d(103, 63, 38));
            var o = Math.max(0, r.autoDrop.nextDueTick - r.tick);
            this.themePanel("ui_panel_modal", 375, 250, 620, 142), this.text("preview", "自动落料 · " + Math.ceil(o / C.rules.physics.fixed_hz) + "秒后下一颗 · 按住杯子左右移动", 375, 250, 22);
            var a = r.autoDrop.pendingSpawn,
              l = new u("AutoDropSpawnPreview");
            this.uiRoot.addChild(l), l.setPosition(a.xDu - 375, Math.min(C.rules.cup.spawn_y_du, C.rules.viewport.height_du - 130) - 667, 0), l.addComponent(h).setContentSize(12, 12);
            var c = l.addComponent(v);
            c.fillColor = new d(255, 199, 93, 230), c.circle(0, 0, 6), c.fill(), this.drawGameIndicators(r);
            var p = Math.max(0, 2 - r.shake.baseUsed),
              f = Math.max(0, r.shake.extraGranted - r.shake.extraUsed),
              g = null === r.shake.activeStartTick ? 0 : Math.max(0, r.shake.activeStartTick + 48 - r.tick),
              w = Math.max(0, r.shake.cooldownUntilTick - r.tick),
              S = null == (n = this.rewarded) ? void 0 : n.getView(),
              R = g > 0 ? "晃杯中…" : w > 0 ? "晃杯冷却" : p > 0 ? "晃杯 " + p : f > 0 ? "广告晃杯 " + f : null != S && S.pendingAttempt ? "奖励待确认" : "看广告 +1 次";
            this.button("shake", R, 42, 48, 200, 96, function () {
              p > 0 || f > 0 ? s.enqueue("SHAKE") : s.openRewardedOffer();
            }), this.button("pause", "暂停", 508, 48, 200, 96, function () {
              return s.togglePause();
            }), this.notice && /失败|错误|异常|冲突|无法/.test(this.notice) && (this.themePanel("ui_panel_toast", 375, 340, 650, 52), this.text("notice", this.notice, 375, 340, 20));
          }
        }, o.renderPause = function () {
          var e = this;
          this.themePanel("ui_panel_modal", 375, 685, 620, 850, !0), this.text("paused", "休息一下", 375, 1010, 44), this.button("resume", "继续游戏", 185, 800, 380, 96, function () {
            e.continueRun();
          }), this.button("settings", "设置", 185, 670, 380, 96, function () {
            return e.openModal("SETTINGS");
          }), this.button("restart", "重新开始", 185, 540, 380, 96, function () {
            return e.openModal("CONFIRM_RESTART");
          }), this.button("menu", "返回菜单", 185, 410, 380, 96, function () {
            return e.openModal("CONFIRM_MENU");
          }), this.notice && this.text("notice", this.notice, 375, 330, 22);
        }, o.renderGameBase = function () {
          var e,
            t = null == (e = this.engine) ? void 0 : e.snapshot();
          t && this.text("score", "分数 " + t.score + "  ·  当前 " + this.levelName(t.currentLevel) + " / 下份 " + this.levelName(t.nextLevel), 375, 1260, 30);
        }, o.drawGameIndicators = function (e) {
          var t,
            i,
            n,
            s = C.rules,
            r = s.viewport.width_du / 2,
            o = s.viewport.height_du / 2,
            a = new u("P1BDangerLine");
          this.uiRoot.addChild(a);
          var l = a.addComponent(v);
          l.lineWidth = 4, l.strokeColor = new d(220, 86, 54, 210);
          for (var h = s.cup.center_x_du + e.cupMotion.offsetXDu, c = h - s.cup.top_width_du / 2 - r, p = h + s.cup.top_width_du / 2 - r, g = s.cup.danger_line_y_du - o, w = c; w < p; w += 28) l.moveTo(w, g), l.lineTo(Math.min(p, w + 17), g);
          l.stroke();
          var S = null != (t = null == (i = s.ingredients.find(function (t) {
              return t.level === e.currentLevel;
            })) ? void 0 : i.radius_du) ? t : 18,
            R = this.themeSprite(D.ingredientId(s.ingredients[e.currentLevel - 1].id), this.previewX, s.cup.spawn_y_du, 2 * S / .9, 2 * S / .9);
          this.previewGraphic = null != (n = null == R ? void 0 : R.getComponent(f)) ? n : null;
        }, o.updatePreviewPosition = function () {
          var e,
            t = C.rules;
          t && null != (e = this.previewGraphic) && null != (e = e.node) && e.isValid && this.previewGraphic.node.setPosition(this.previewX - t.viewport.width_du / 2, t.cup.spawn_y_du - t.viewport.height_du / 2, 0);
        }, o.renderSettings = function () {
          var e = this;
          this.themePanel("ui_panel_modal", 375, 730, 650, 1110, !0), this.text("settings-title", "设置", 375, 1170, 48);
          var t = this.bundle.profile.settings;
          this.drawVolume("music", this.bundle.profile.settings.musicGain, 998), this.drawVolume("sfx", this.bundle.profile.settings.sfxGain, 778), this.text("music-gain", "音乐音量  " + Math.round(100 * t.musicGain) + "%", 375, 1050, 30), this.button("music-down", "−", 135, 950, 100, 96, function () {
            return e.changeGain("musicGain", -.1);
          }), this.button("music-up", "+", 515, 950, 100, 96, function () {
            return e.changeGain("musicGain", .1);
          }), this.text("sfx-gain", "音效音量  " + Math.round(100 * t.sfxGain) + "%", 375, 830, 30), this.button("sfx-down", "−", 135, 730, 100, 96, function () {
            return e.changeGain("sfxGain", -.1);
          }), this.button("sfx-up", "+", 515, 730, 100, 96, function () {
            return e.changeGain("sfxGain", .1);
          }), this.button("motion", "弱动态：" + (this.reducedMotion ? "开启" : "关闭"), 185, 460, 380, 96, function () {
            e.reducedMotion = !e.reducedMotion, e.persistSettings(), e.render();
          }), this.button("tutorial-replay", "重看三步引导", 185, 340, 380, 96, function () {
            return e.beginTutorial();
          }), this.button("back", "返回", 185, 220, 380, 96, function () {
            return e.closeModal();
          }), this.audioFailure && this.button("retry-audio", this.audioLoading ? "正在重试…" : "重试声音加载", 185, 130, 380, 96, function () {
            e.loadAudioClips(!0);
          });
          var i = this.audioFailures.size ? "声音资源缺失 " + this.audioFailures.size + " 项，可点击重试" : this.audio ? "声音已加载" : "首次操作后自动加载声音",
            n = this.persistent ? "设置自动保存到本机" : "仅内存模式：设置不保证跨关闭保留";
          this.themePanel("ui_panel_toast", 375, 105, 670, 104), this.text("settings-status", i + "\n" + n, 375, 105, 21);
        }, o.drawVolume = function (e, t, i) {
          this.themeSprite("ui_slider_track_empty", 375, i, 264, 25);
          var n = this.themeSprite("ui_slider_fill_full", 375, i, 264, 25),
            s = null == n ? void 0 : n.getComponent(f);
          s && (s.type = f.Type.FILLED, s.fillType = f.FillType.HORIZONTAL, s.fillStart = 0, s.fillRange = t), this.themeSprite("ui_slider_knob", 251 + 248 * t, i, 42, 42), this.themeSprite("music" === e ? "ui_icon_music_on" : "ui_icon_sfx_on", 100, i + 52, 40, 40);
        }, o.changeGain = function (e, t) {
          var i,
            s,
            r = this.bundle.profile.settings,
            o = Math.max(0, Math.min(100, Math.round(100 * r[e] + 100 * t)));
          this.bundle = n({}, this.bundle, {
            profile: n({}, this.bundle.profile, {
              settings: n({}, r, (i = {}, i[e] = o / 100, i))
            })
          }), null == (s = this.audio) || s.setVolumes(this.bundle.profile.settings.musicGain, this.bundle.profile.settings.sfxGain), this.persistSettings(), this.render();
        }, o.unlockAudioFromGesture = function () {
          this.audioUnlockRequested = !0, this.audio ? this.audio.requestMusicFromGesture() : this.audioLoading || this.audioFailures.size || this.loadAudioClips();
        }, o.loadAudioClips = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee19(e) {
            var t, n, r, o, a, l, u, d, h, c, v;
            return _regeneratorRuntime().wrap(function _callee19$(_context20) {
              while (1) switch (_context20.prev = _context20.next) {
                case 0:
                  t = this;
                  if (!(void 0 === e && (e = !1), !this.audioLoading)) {
                    _context20.next = 22;
                    break;
                  }
                  this.audioLoading = !0, e && this.audioFailures.clear();
                  n = ["bgm_classic", "ui_tap", "drop", "collision_soft", "merge_small", "merge_large", "shake_start", "danger_tick", "result"].filter(function (i) {
                    return !t.audioClips[i] && (e || !t.audioFailures.has(i));
                  });
                  _context20.prev = 4;
                  _context20.next = 7;
                  return Promise.all(n.map(s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee18(e) {
                    return _regeneratorRuntime().wrap(function _callee18$(_context19) {
                      while (1) switch (_context19.prev = _context19.next) {
                        case 0:
                          _context19.prev = 0;
                          _context19.t0 = e;
                          _context19.next = 4;
                          return t.loadAudioClip(e);
                        case 4:
                          _context19.t1 = _context19.sent;
                          return _context19.abrupt("return", {
                            cue: _context19.t0,
                            clip: _context19.t1,
                            error: null
                          });
                        case 8:
                          _context19.prev = 8;
                          _context19.t2 = _context19["catch"](0);
                          return _context19.abrupt("return", {
                            cue: e,
                            clip: null,
                            error: _context19.t2 instanceof Error ? _context19.t2 : new Error(String(_context19.t2))
                          });
                        case 11:
                        case "end":
                          return _context19.stop();
                      }
                    }, _callee18, null, [[0, 8]]);
                  }))));
                case 7:
                  o = _context20.sent;
                  if (this.isOwner()) {
                    _context20.next = 11;
                    break;
                  }
                  for (l = i(o); !(a = l()).done;) {
                    u = a.value;
                    u.clip && S.release("audio/p1c/" + u.cue, w);
                  }
                  return _context20.abrupt("return");
                case 11:
                  !this.audio && o.some(function (e) {
                    return e.clip;
                  }) && (this.audio = new M(this.node, {}, this.bundle.profile.settings.musicGain, this.bundle.profile.settings.sfxGain));
                  for (h = i(o); !(d = h()).done;) {
                    v = d.value;
                    if (v.clip) this.audioClips[v.cue] = v.clip, null == (c = this.audio) || c.addClip(v.cue, v.clip);else this.audioFailures.add(v.cue), this.releaseAudioClip(v.cue);
                  }
                  this.audioFailure = this.audioFailures.size ? Array.from(this.audioFailures).join("、") : "", this.audioUnlockRequested && (null == (r = this.audio) || r.requestMusicFromGesture());
                  _context20.next = 19;
                  break;
                case 16:
                  _context20.prev = 16;
                  _context20.t0 = _context20["catch"](4);
                  this.audioFailure = String(_context20.t0);
                case 19:
                  _context20.prev = 19;
                  this.audioLoading = !1, "PLAYING" !== this.screen && this.render();
                  return _context20.finish(19);
                case 22:
                case "end":
                  return _context20.stop();
              }
            }, _callee19, this, [[4, 16, 19, 22]]);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), o.loadAudioClip = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee20(e) {
            var t, i;
            return _regeneratorRuntime().wrap(function _callee20$(_context21) {
              while (1) switch (_context21.prev = _context21.next) {
                case 0:
                  t = "audio/p1c/" + e;
                  if (!S.getInfoWithPath(t, w)) {
                    _context21.next = 5;
                    break;
                  }
                  _context21.t0 = S;
                  _context21.next = 8;
                  break;
                case 5:
                  _context21.next = 7;
                  return this.loadClassicBundle();
                case 7:
                  _context21.t0 = _context21.sent;
                case 8:
                  i = _context21.t0;
                  if (i) {
                    _context21.next = 11;
                    break;
                  }
                  throw new Error("音频包缺失: " + e);
                case 11:
                  _context21.next = 13;
                  return new Promise(function (n, s) {
                    return i.load(t, w, null, function (t, i) {
                      return t || !i ? s(null != t ? t : new Error("音频缺失: " + e)) : n(i);
                    });
                  });
                case 13:
                  return _context21.abrupt("return", _context21.sent);
                case 14:
                case "end":
                  return _context21.stop();
              }
            }, _callee20, this);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), o.loadRequiredArt = function () {
          var e = this;
          if (!C.rules) throw new Error("配置未初始化");
          return s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee21() {
            var t;
            return _regeneratorRuntime().wrap(function _callee21$(_context22) {
              while (1) switch (_context22.prev = _context22.next) {
                case 0:
                  _context22.t0 = e.art.catalog.ids.includes("ui_title_logo");
                  if (!_context22.t0) {
                    _context22.next = 5;
                    break;
                  }
                  _context22.next = 4;
                  return e.art.load("ui_title_logo", 750);
                case 4:
                  e.artLoading && e.isOwner() && e.render();
                case 5:
                  t = e.art.catalog.ids.filter(function (e) {
                    return "bg_brand" === e || "ui_title_logo" === e || "ui_panel_hud" === e || "ui_panel_toast" === e || e.startsWith("ui_btn_") || ["ui_icon_play", "ui_icon_continue", "ui_icon_settings", "ui_icon_warning", "ui_icon_close", "ui_icon_back"].includes(e);
                  });
                  _context22.next = 8;
                  return e.loadArtBatch(t);
                case 8:
                case "end":
                  return _context22.stop();
              }
            }, _callee21);
          }))();
        }, o.loadArtBatch = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee22(e) {
            var t, i;
            return _regeneratorRuntime().wrap(function _callee22$(_context23) {
              while (1) switch (_context23.prev = _context23.next) {
                case 0:
                  t = this, i = 0;
                case 1:
                  if (!(i < e.length)) {
                    _context23.next = 7;
                    break;
                  }
                  _context23.next = 4;
                  return Promise.all(e.slice(i, i + 4).map(function (e) {
                    return t.art.load(e, e.startsWith("spr_ing_") ? 700 : 1e3);
                  }));
                case 4:
                  i += 4;
                  _context23.next = 1;
                  break;
                case 7:
                case "end":
                  return _context23.stop();
              }
            }, _callee22, this);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), o.loadGameArt = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee23() {
            return _regeneratorRuntime().wrap(function _callee23$(_context24) {
              while (1) switch (_context24.prev = _context24.next) {
                case 0:
                  _context24.next = 2;
                  return this.loadArtBatch(this.art.catalog.ids.filter(function (e) {
                    return !e.startsWith("bg_shop_extend_");
                  }));
                case 2:
                case "end":
                  return _context24.stop();
              }
            }, _callee23, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.retryArtAndStart = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee25() {
            var e, t, i, n, r;
            return _regeneratorRuntime().wrap(function _callee25$(_context26) {
              while (1) switch (_context26.prev = _context26.next) {
                case 0:
                  e = this;
                  if (!this.artRetryTask) {
                    _context26.next = 3;
                    break;
                  }
                  return _context26.abrupt("return", this.artRetryTask);
                case 3:
                  if (this.loading) {
                    _context26.next = 6;
                    break;
                  }
                  t = this.ownerEpoch, i = ++this.artLoadGeneration, n = this.startupTraceId = C.startup.beginTrace(t), r = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee24() {
                    var s, r, o;
                    return _regeneratorRuntime().wrap(function _callee24$(_context25) {
                      while (1) switch (_context25.prev = _context25.next) {
                        case 0:
                          e.loading = !0, e.artLoading = !0, e.notice = "正在重试资源加载…", e.render();
                          s = e.art.beginLoadScope(t, n, 15e3, "GAME_ART");
                          _context25.prev = 2;
                          if (e.art.catalog) {
                            _context25.next = 12;
                            break;
                          }
                          C.startup.stage("ART_CATALOG", "start", void 0, t, n);
                          _context25.next = 7;
                          return e.art.initialize();
                        case 7:
                          if (!(!e.isOwner() || t !== e.ownerEpoch || i !== e.artLoadGeneration)) {
                            _context25.next = 9;
                            break;
                          }
                          return _context25.abrupt("return");
                        case 9:
                          e.artReady = !0;
                          r = e.art.catalog;
                          C.startup.stage("ART_CATALOG", "ok", {
                            assetId: "ids:" + r.ids.length,
                            bundleName: "variants:" + r.variantCount
                          }, t, n);
                        case 12:
                          C.startup.stage("GAME_ART", "start", void 0, t, n);
                          _context25.next = 15;
                          return e.loadRequiredArt();
                        case 15:
                          if (!(!e.isOwner() || t !== e.ownerEpoch || i !== e.artLoadGeneration)) {
                            _context25.next = 17;
                            break;
                          }
                          return _context25.abrupt("return");
                        case 17:
                          e.art.settleLoadScope(s), e.artLoading = !1, e.screen = "MENU", e.hideOverlay(), e.notice = e.bundle.run ? "资源已恢复。请选择继续上局或开始新局。" : "", e.render(), e.loadAudioClips(), C.startup.stage("MENU_READY", "ok", {
                            assetId: "loaded:" + e.art.loadedCount
                          }, t, n);
                          _context25.next = 23;
                          break;
                        case 20:
                          _context25.prev = 20;
                          _context25.t0 = _context25["catch"](2);
                          if (e.art.cancelScope(e.startupErrorCode(_context25.t0), s), e.isOwner() && t === e.ownerEpoch && i === e.artLoadGeneration) {
                            o = e.startupErrorCode(_context25.t0);
                            C.startup.stage("GAME_ART", "error", {
                              code: o,
                              error: _context25.t0
                            }, t, n), e.showStartupFailure(o, String(_context25.t0), n);
                          }
                        case 23:
                          _context25.prev = 23;
                          e.isOwner() && t === e.ownerEpoch && i === e.artLoadGeneration && (e.loading = !1, e.artRetryTask = null);
                          return _context25.finish(23);
                        case 26:
                        case "end":
                          return _context25.stop();
                      }
                    }, _callee24, null, [[2, 20, 23, 26]]);
                  }))();
                  return _context26.abrupt("return", (this.artRetryTask = r, r));
                case 6:
                case "end":
                  return _context26.stop();
              }
            }, _callee25, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.loadClassicBundle = function () {
          var e = this;
          if (this.classicBundle) return Promise.resolve(this.classicBundle);
          if (this.classicBundleLoad) return this.classicBundleLoad;
          var t = new Promise(function (e) {
            return g.loadBundle("classic", function (t, i) {
              return e(t || !i ? null : i);
            });
          }).then(function (t) {
            return e.classicBundle = t, t;
          });
          this.classicBundleLoad = t;
          var i = function i() {
            e.classicBundleLoad === t && (e.classicBundleLoad = null);
          };
          return t.then(i, i), t;
        }, o.releaseAudioClip = function (e) {
          this.classicBundle ? this.classicBundle.release("audio/p1c/" + e, w) : S.release("audio/p1c/" + e, w);
        }, o.beginTutorial = function () {
          var e;
          (this.tutorialReturnScreen = this.screen, this.tutorialStep = 1, this.cancelPointer(), this.pauseOwners.add("MODAL"), this.engine) && (this.engine.pause("MODAL"), null == (e = this.clock) || e.pause());
          this.render();
        }, o.renderTutorial = function () {
          var e,
            t = this;
          this.buttons = [];
          var i = new u("TutorialScrim");
          this.uiRoot.addChild(i), i.addComponent(h).setContentSize(750, 1334);
          var n = i.addComponent(v);
          n.fillColor = new d(35, 28, 22, 185), n.rect(-375, -667, 750, 1334), n.fill(), this.themePanel("ui_panel_modal", 375, 850, 680, 700);
          var s = [["第 1 步 · 自动落料", "小料会定时落下，按住杯子左右移动来接料。"], ["第 2 步 · 同级会合成", "相同等级的小料相遇会合成，留意杯内危险线。"], ["第 3 步 · 晃杯与暂停", "每局可晃杯两次；暂停后明确继续，稍等一秒再落料。"]][this.tutorialStep - 1];
          this.text("tutorial-title", s[0], 375, 1080, 33), this.text("tutorial-copy", s[1], 375, 950, 27), null == (e = this.labels.get("tutorial-copy")) || null == (e = e.node.getComponent(h)) || e.setContentSize(560, 125), this.themeSprite(1 === this.tutorialStep ? "ui_tutorial_hand_move" : 2 === this.tutorialStep ? "fx_merge_ring" : "ui_icon_shake", 375, 805, 130, 130), this.button("tutorial-next", 3 === this.tutorialStep ? "开始这杯" : "下一步", 80, 650, 270, 96, function () {
            t.tutorialStep < 3 ? (t.tutorialStep++, t.render()) : t.finishTutorial(!0);
          }), this.button("tutorial-skip", "跳过并开始", 400, 650, 270, 96, function () {
            t.finishTutorial(!0);
          });
        }, o.finishTutorial = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee26(e) {
            var t, i, s;
            return _regeneratorRuntime().wrap(function _callee26$(_context27) {
              while (1) switch (_context27.prev = _context27.next) {
                case 0:
                  this.tutorialStep = 0, this.pauseOwners["delete"]("MODAL"), e && (this.bundle = n({}, this.bundle, {
                    profile: n({}, this.bundle.profile, {
                      tutorialRulesVersion: null == (t = C.rules) ? void 0 : t.design_rules_version,
                      settings: n({}, this.bundle.profile.settings, {
                        tutorialCompleted: !0
                      })
                    })
                  }));
                  i = this.tutorialReturnScreen;
                  if (this.screen = i, "PLAYING" === i && this.engine && this.clock) {
                    s = T.snapshot();
                    if (s.backgrounded || s.resumeRequired) this.screen = "PAUSED", this.pauseOwners.add(s.backgrounded ? "HOST_HIDDEN" : "RESUME_REQUIRED");else this.engine.resume().ok && (this.pauseOwners.clear(), this.clock.resume());
                  }
                  this.render(), e && this.persistSettings();
                case 4:
                case "end":
                  return _context27.stop();
              }
            }, _callee26, this);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), o.showMergeFeedback = function (e, t) {
          var i = e.x - 375,
            n = e.y - 667;
          this.showTextFeedback("+" + t, i, n, new d(112, 57, 25));
          var s = this.themeSprite("fx_merge_ring", e.x, e.y, 110, 110);
          if (s) {
            s.name = "MergeRing-" + ++this.feedbackSequence;
            var r = s.addComponent(c),
              o = this.reducedMotion ? .14 : .22;
            R(s).to(o, {
              scale: new m(this.reducedMotion ? 1.25 : 1.7, this.reducedMotion ? 1.25 : 1.7, 1)
            }).start(), R(r).to(o, {
              opacity: 0
            }).call(function () {
              return s.destroy();
            }).start();
          }
        }, o.showTextFeedback = function (e, t, i, n) {
          var s;
          if (null != (s = this.uiRoot) && s.isValid) {
            var r = new u("Feedback-" + ++this.feedbackSequence);
            this.uiRoot.addChild(r), r.setPosition(t, i, 0), r.addComponent(h).setContentSize(240, 64);
            var o = r.addComponent(p);
            o.string = e, o.fontSize = 32, o.lineHeight = 38, o.color = n, o.isBold = !0;
            var a = r.addComponent(c),
              l = this.reducedMotion ? .12 : .48;
            R(r).to(l, {
              position: new m(t, i + (this.reducedMotion ? 8 : 24), 0)
            }).start(), R(a).delay(.45 * l).to(.55 * l, {
              opacity: 0
            }).call(function () {
              return r.destroy();
            }).start();
          }
        }, o.readContactFeedback = function () {
          var e,
            t,
            n = this;
          if (this.adapter && this.engine) {
            for (var s, r = this.engine.tick, o = new Set(this.engine.snapshot().ingredients.map(function (e) {
                return e.entityId;
              })), a = i(this.contactObjectTicks.keys()); !(s = a()).done;) {
              var l = s.value;
              o.has(l) || this.contactObjectTicks["delete"](l);
            }
            for (var u, d = new Set(), h = .5 * (null != (e = null == (t = C.rules) ? void 0 : t.viewport.du_per_spec_physics_unit) ? e : 100), c = function c() {
                var e,
                  t,
                  s = u.value;
                if (d.add(s.contactId), n.contactPairs.has(s.contactId) || Math.abs(s.normalSpeed) < h || r - n.lastContactFeedbackTick < 10) return 0;
                var a = [s.firstId, s.secondId].filter(function (e) {
                  return null !== e && o.has(e);
                });
                if (!a.length || a.some(function (e) {
                  var t;
                  return r - (null != (t = n.contactObjectTicks.get(e)) ? t : -60) < 8;
                })) return 0;
                n.lastContactFeedbackTick = r;
                var l = n.engine.snapshot().ingredients.find(function (e) {
                  return a.includes(e.entityId);
                });
                l && (null == (e = n.effects) || e.play(null === s.secondId ? "drop" : "collision", l.positionDu.x, l.positionDu.y, r + ":" + s.contactId, n.reducedMotion)), null == (t = n.audio) || t.play("collision_soft");
                for (var c, v = i(a); !(c = v()).done;) {
                  var p = c.value;
                  n.contactObjectTicks.set(p, r);
                }
                for (var f, g = i(a); !(f = g()).done;) {
                  var w,
                    S = f.value,
                    y = null == (w = n.world) ? void 0 : w.getChildByName("P1BIngredientVisual-" + S);
                  if (null != y && y.isValid) {
                    b.stopAllByTarget(y);
                    var E = n.reducedMotion ? .96 : .92;
                    R(y).to(.06, {
                      scale: new m(1.04, E, 1)
                    }).to(.08, {
                      scale: new m(1, 1, 1)
                    }).start();
                  }
                }
              }, v = i(this.adapter.getContacts()); !(u = v()).done;) c();
            this.contactPairs = d;
          }
        }, o.renderConfirm = function () {
          var e,
            t = this;
          this.themePanel("ui_panel_modal", 375, 885, 660, 470, !0);
          var i = "CONFIRM_RESTART" === this.screen && !this.engine && !!this.bundle.run && this.bundle.run.rulesVersion !== (null == (e = C.rules) ? void 0 : e.design_rules_version);
          this.text("confirm", i ? "玩法规则已更新。取消会完整保留旧局；确认后新局使用窄杯自动落料，旧纪录与设置保留。" : "确认重新开始？未保存进度将按最近完整保存恢复。", 375, 930, 26), this.button("yes", "确认", 60, 790, 270, 96, function () {
            return "CONFIRM_RESTART" === t.screen ? void t.restartConfirmed() : void t.returnToMenuConfirmed();
          }), this.button("no", "取消", 420, 790, 270, 96, function () {
            return t.closeModal();
          });
        }, o.renderResults = function () {
          var e,
            t,
            i,
            n,
            s,
            r,
            o,
            a,
            l,
            u,
            h,
            c = this;
          this.themePanel("ui_panel_results", 375, 720, 650, 1e3, !0);
          var v = this.bundle.lastResult,
            p = null == (e = this.engine) ? void 0 : e.snapshot();
          (null != (t = null != (i = null == v ? void 0 : v.score) ? i : null == p ? void 0 : p.score) ? t : 0) > this.runBestScoreAtStart && this.themeSprite("ui_badge_record", 375, 1140, 170, 85), this.text("result-title", "SPILLED" === (null == v ? void 0 : v.reason) ? "小料洒出来了" : "这杯加满了", 375, 1050, 44), this.text("result-score", "得分 " + (null != (n = null != (s = null == v ? void 0 : v.score) ? s : null == p ? void 0 : p.score) ? n : 0) + "  ·  最高等级 " + (null != (r = null != (o = null == v ? void 0 : v.maxLevel) ? o : null == p ? void 0 : p.maxLevel) ? r : 1), 375, 940, 30), this.text("result-drops", "投放 " + (null != (a = null != (l = null == v ? void 0 : v.dropIndex) ? l : null == p ? void 0 : p.dropIndex) ? a : 0) + " 次  ·  晃杯 " + (null != (u = null != (h = null == v ? void 0 : v.baseUsed) ? h : null == p ? void 0 : p.shake.baseUsed) ? u : 0) + "/2", 375, 875, 24), this.text("save-status", this.resultSaved ? "已保存" : this.resultError || "正在保存结算…", 375, 790, 22, this.resultSaved ? new d(49, 114, 72) : new d(160, 74, 41)), this.button("again", "再来一杯", 160, 650, 430, 96, function () {
            c.restartConfirmed();
          }), this.button("menu", "回菜单", 160, 510, 430, 96, function () {
            var e, t;
            c.screen = "MENU", null == (e = c.engine) || e.dispose(), c.engine = null, c.clock = null, null == (t = c.world) || t.destroy(), c.render();
          }), !this.resultSaved && this.activeSaveRepository() && this.button("retry-save", "重试保存", 160, 370, 430, 96, function () {
            c.retryResultSave();
          });
        }, o.renderError = function () {
          var e,
            t = this,
            i = this.notice.includes("PHYSICS_");
          if (this.themePanel("ui_panel_modal", 375, 780, 670, 850, !0), this.themeSprite("ui_icon_warning", 375, 1130, 80, 80), this.text("error", i ? "本局暂时遇到问题" : "暂时无法开始", 375, 990, 40), this.text("error-detail", i ? this.notice : /图片|加载/.test(this.notice) ? "图片暂时没加载完成，请点击重试。\n已有存档会保留。" : this.notice || "请重试或重新打开游戏。", 375, 860, 26), null == (e = this.labels.get("error-detail")) || null == (e = e.node.getComponent(h)) || e.setContentSize(560, 150), i) {
            if (this.engine && this.recoveryUsedRunId !== this.engine.snapshot().runId && (this.engine.recoveryCheckpoint || this.activeSaveRepository()) && this.button("retry-checkpoint", "恢复本局", 160, 650, 430, 96, function () {
              t.retryTechnicalRecovery();
            }), this.button("error-menu", "返回菜单", 160, 510, 430, 96, function () {
              return t.returnToMenuFromError();
            }), this.button("physics-details", "查看错误详情", 160, 390, 430, 72, function () {
              t.showPhysicsDiagnostics = !t.showPhysicsDiagnostics, t.render();
            }), this.showPhysicsDiagnostics) {
              var n,
                s,
                r,
                o = (null != (n = null == (s = this.engine) ? void 0 : s.lastTickFault) ? n : "无可用错误摘要").slice(0, 240);
              this.text("physics-diagnostic", "构建 " + C.buildId + "\n" + o, 375, 290, 18), null == (r = this.labels.get("physics-diagnostic")) || null == (r = r.node.getComponent(h)) || r.setContentSize(560, 140);
            }
          } else this.button("retry-load", "重试资源加载", 160, 680, 430, 96, function () {
            t.retryArtAndStart();
          }), this.artReady && this.button("memory-new", "仅内存新局", 160, 540, 430, 96, function () {
            t.startNew(!0);
          });
        }, o.retryTechnicalRecovery = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee27() {
            var e, t, i, s, r, o, a, l, u, d, h, c, v, p, f, g;
            return _regeneratorRuntime().wrap(function _callee27$(_context28) {
              while (1) switch (_context28.prev = _context28.next) {
                case 0:
                  t = this, i = null == (e = this.engine) ? void 0 : e.snapshot().runId;
                  if (!(i && this.recoveryUsedRunId !== i && !this.loading)) {
                    _context28.next = 47;
                    break;
                  }
                  this.loading = !0;
                  s = this.ownerEpoch;
                  _context28.prev = 4;
                case 5:
                  if (!this.saveInFlight) {
                    _context28.next = 10;
                    break;
                  }
                  _context28.next = 8;
                  return this.waitForSaveIdle();
                case 8:
                  _context28.next = 5;
                  break;
                case 10:
                  if (!(!this.isOwner() || s !== this.ownerEpoch)) {
                    _context28.next = 12;
                    break;
                  }
                  return _context28.abrupt("return");
                case 12:
                  l = null != (r = null == (o = this.engine) ? void 0 : o.recoveryCheckpoint) ? r : null;
                  if (l) {
                    _context28.next = 23;
                    break;
                  }
                  u = this.activeSaveRepository();
                  if (!u) {
                    _context28.next = 23;
                    break;
                  }
                  _context28.next = 18;
                  return u.readBundle();
                case 18:
                  h = _context28.sent;
                  if (!(!this.isOwner() || s !== this.ownerEpoch)) {
                    _context28.next = 21;
                    break;
                  }
                  return _context28.abrupt("return");
                case 21:
                  c = h.ok ? h.data.envelope : null;
                  (null == c || null == (d = c.payload.run) ? void 0 : d.runId) === i && (l = c.payload.run, this.bundle = c.payload, this.bundleRevision = c.revision);
                case 23:
                  if (!(!l || l.runId !== i)) {
                    _context28.next = 25;
                    break;
                  }
                  return _context28.abrupt("return", (this.notice = "本次页面内没有可恢复的完整局面，请返回菜单重新开始。错误编号 PHYSICS_CHECKPOINT_UNAVAILABLE", void this.render()));
                case 25:
                  l = L.sealSnapshot(l);
                  v = N.snapshot(l);
                  if (v.valid) {
                    _context28.next = 29;
                    break;
                  }
                  throw new Error("CHECKPOINT_INVALID:" + v.code);
                case 29:
                  null == (a = this.engine) || a.dispose(), this.engine = null, this.adapter = null;
                  f = this.createWorld();
                  _context28.prev = 31;
                  p = new I(f, C.rules, l.runId, l.rng.state, l, this.reviveOptions());
                  _context28.next = 38;
                  break;
                case 35:
                  _context28.prev = 35;
                  _context28.t0 = _context28["catch"](31);
                  throw f.dispose(), _context28.t0;
                case 38:
                  this.adapter = f, this.engine = p, this.baseTick = l.tick, this.clock = new k(C.rules.physics.fixed_hz, C.rules.physics.max_catchup_steps, function () {
                    return t.advanceRunTick();
                  }), this.clock.pause(), this.bundle = n({}, this.bundle, {
                    profile: n({}, this.bundle.profile, {
                      activeRunId: i
                    }),
                    run: p.snapshot()
                  }), this.recoveryUsedRunId = i, this.pauseOwners.clear(), this.bindRewardedShake(), this.bindSpillRevive(), this.screen = p.spillPending ? "REVIVE" : "PAUSED", this.notice = p.spillPending ? "已恢复洒出局面：可观看广告复活一次，或结束本局。" : "已恢复本页最近完整局面；点击“继续游戏”后再操作。", this.render();
                  _context28.next = 44;
                  break;
                case 41:
                  _context28.prev = 41;
                  _context28.t1 = _context28["catch"](4);
                  null == (g = this.clock) || g.pause(), this.screen = "ERROR", this.notice = "恢复未完成，请返回菜单；已有存档未覆盖。错误编号 PHYSICS_RECOVERY_FAILED " + String(_context28.t1).slice(0, 120), this.render();
                case 44:
                  _context28.prev = 44;
                  this.isOwner() && s === this.ownerEpoch && (this.loading = !1);
                  return _context28.finish(44);
                case 47:
                case "end":
                  return _context28.stop();
              }
            }, _callee27, this, [[4, 41, 44, 47], [31, 35]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.drawButtons = function () {
          for (var e, t = i(this.buttons); !(e = t()).done;) {
            var n = e.value,
              s = new u("P1BButton-" + n.id);
            this.uiRoot.addChild(s), s.setPosition(n.rect.x - 375 + n.rect.w / 2, n.rect.y - 667 + n.rect.h / 2, 0), s.addComponent(h).setContentSize(n.rect.w, n.rect.h);
            var r = ["new", "continue", "resume", "yes", "again", "tutorial-next", "drop"].includes(n.id),
              o = n.rect.w <= 110,
              a = o ? "icon" : r ? "primary" : "secondary",
              l = "ui_btn_" + a + "_" + (!1 === n.enabled ? "disabled" : "normal");
            if (this.art.getLoadedVariant(l)) {
              var c = this.art.createSprite(s, l, n.rect.w, n.rect.h, !0);
              c.name = "ButtonSkin", this.buttonSkins.set(n.id, {
                node: c,
                family: a
              });
            } else {
              var f = s.addComponent(v);
              f.fillColor = new d(255, 207, 75), f.roundRect(-n.rect.w / 2, -n.rect.h / 2, n.rect.w, n.rect.h, 24), f.fill();
            }
            var g = {
              "new": "play",
              "continue": "continue",
              resume: "continue",
              settings: "settings",
              restart: "restart",
              again: "restart",
              menu: "home",
              pause: "pause",
              shake: "shake",
              back: "back",
              yes: "check",
              no: "close",
              motion: "reduced_motion",
              "tutorial-replay": "info"
            }[n.id];
            if (g && !o && this.art.getLoadedVariant("ui_icon_" + g)) this.art.createSprite(s, "ui_icon_" + g, 38, 38, !0).setPosition(-n.rect.w / 2 + 43, 0, 0);
            var w = new u("Label");
            s.addChild(w), w.addComponent(h).setContentSize(n.rect.w - (g ? 78 : 20), n.rect.h - 12), w.setPosition(g ? 19 : 0, 0, 0);
            var S = w.addComponent(p);
            S.string = n.label, S.fontSize = o ? 34 : 28, S.lineHeight = 34, S.color = new d(103, 58, 32), S.isBold = !0, S.overflow = p.Overflow.SHRINK, S.enableWrapText = !0;
          }
        }, o.text = function (e, t, i, n, s, r) {
          void 0 === r && (r = new d(66, 48, 38));
          var o = new u("P1BText-" + e);
          this.uiRoot.addChild(o), o.setPosition(i - 375, n - 667, 0), o.addComponent(h).setContentSize(700, 60);
          var a = o.addComponent(p);
          a.string = t, a.fontSize = s, a.lineHeight = s + 8, a.color = r, a.isBold = !0, a.overflow = p.Overflow.SHRINK, a.enableWrapText = !0, this.labels.set(e, a);
        }, o.button = function (e, t, i, n, s, r, o) {
          this.buttons.push({
            id: e,
            label: t,
            rect: {
              x: i,
              y: n,
              w: s,
              h: r
            },
            action: o
          });
        }, o.refreshHud = function () {
          var e, t, i, n, s, r;
          if ("PLAYING" === this.screen) {
            var o = null == (e = this.engine) ? void 0 : e.snapshot();
            if (o) {
              var a = this.labels.get("score"),
                l = this.labels.get("next"),
                u = this.labels.get("danger"),
                d = "assisted" === o.boardType ? "assisted" : "standard";
              a && (a.string = "分数 " + o.score + "  ·  纪录 " + (null != (t = null == (i = this.bundle.profile.bestScoresByRules) || null == (i = i[o.rulesVersion]) || null == (i = i.classic) ? void 0 : i[d]) ? t : 0)), l && (l.string = "当前 " + this.levelName(o.currentLevel) + "  ·  最高 " + this.levelName(o.maxLevel)), u && (u.string = o.dangerTicks ? "快满了 · " + Math.max(1, 3 - Math.floor(o.dangerTicks / 60)) : "同级相遇，合成更大颗");
              var h = Math.round(C.rules.shake.duration_seconds * C.rules.physics.fixed_hz),
                c = Math.max(0, 2 - o.shake.baseUsed),
                v = Math.max(0, o.shake.extraGranted - o.shake.extraUsed),
                f = null === o.shake.activeStartTick ? 0 : Math.max(0, o.shake.activeStartTick + h - o.tick),
                g = Math.max(0, o.shake.cooldownUntilTick - o.tick),
                w = f > 0 ? "晃杯中" : g > 0 ? "稍等片刻" : c > 0 ? "晃杯 " + c : v > 0 ? "奖励晃杯 " + v : null != (n = this.rewarded) && n.policy.enabled && null === (null == (s = this.rewardView()) ? void 0 : s.block) ? "看广告 +1 次" : "本局次数已用完",
                S = null == (r = this.uiRoot) || null == (r = r.getChildByName("P1BButton-shake")) || null == (r = r.getChildByName("Label")) ? void 0 : r.getComponent(p);
              S && (S.string = w);
            }
          }
        }, o.enqueue = function (e, t) {
          if (this.engine && "PLAYING" === this.screen) {
            var i = this.engine.snapshot();
            if (!("SHAKE" === e && i.shake.baseUsed >= 2 && 0 === Math.max(0, i.shake.extraGranted - i.shake.extraUsed))) {
              var n = this.makeUuid(),
                s = {
                  kind: e,
                  runId: i.runId,
                  commandId: n,
                  sequence: i.nextCommandSequence,
                  tick: i.tick + 1
                };
              "DROP" === e ? s.xDu = null != t ? t : this.previewX : s.source = i.shake.baseUsed < 2 ? "base" : "rewarded_ad";
              var r = this.engine.dispatch({
                command: s,
                ownerEpoch: i.epoch
              });
              return r.ok ? void 0 : (this.notice = r.error.message, void this.render());
            }
            this.openRewardedOffer();
          }
        }, o.onTouchStart = function (e) {
          var t;
          this.ignoreMouseUntil = Date.now() + 600, this.beginPointer(e, null != (t = null == e.getID ? void 0 : e.getID()) ? t : 0);
        }, o.onTouchMove = function (e) {
          var t;
          this.updatePressedState(e), "cup" === this.pointerKind && this.primaryPointer === (null != (t = null == e.getID ? void 0 : e.getID()) ? t : 0) && this.moveCup(e);
        }, o.onTouchEnd = function (e) {
          var t;
          this.primaryPointer === (null != (t = null == e.getID ? void 0 : e.getID()) ? t : 0) && this.endPointer(e);
        }, o.onTouchCancel = function (e) {
          var t;
          this.primaryPointer === (null != (t = null == e.getID ? void 0 : e.getID()) ? t : 0) && this.cancelPointer();
        }, o.onMouseDown = function (e) {
          Date.now() < this.ignoreMouseUntil || this.beginPointer(e, -1);
        }, o.onMouseMove = function (e) {
          Date.now() < this.ignoreMouseUntil || (this.updatePressedState(e), "cup" === this.pointerKind && -1 === this.primaryPointer && this.moveCup(e));
        }, o.onMouseUp = function (e) {
          Date.now() < this.ignoreMouseUntil || -1 === this.primaryPointer && this.endPointer(e);
        }, o.updatePressedState = function (e) {
          var t = this;
          if ("ui" === this.pointerKind && this.startedInButton) {
            var i = this.buttons.find(function (e) {
                return e.id === t.startedInButton;
              }),
              n = this.point(e);
            i && this.setButtonState(i.id, this.contains(i.rect, n.x, n.y) ? "pressed" : "normal");
          }
        }, o.inDropBand = function (e) {
          return e.x >= 80 && e.x <= 670 && e.y >= 180 && e.y <= 320;
        }, o.beginPointer = function (e, t) {
          var i = this;
          if (null === this.primaryPointer) {
            var n = this.point(e);
            if (this.overlayVisible) {
              var s,
                r = this.overlayButtons.find(function (e) {
                  return i.contains(e.rect, n.x, n.y);
                });
              return this.primaryPointer = t, this.pointerKind = "overlay", void (this.startedInOverlay = null != (s = null == r ? void 0 : r.id) ? s : null);
            }
            var o,
              a = this.buttons.find(function (e) {
                return i.contains(e.rect, n.x, n.y);
              });
            if (this.primaryPointer = t, a) return this.pointerKind = "ui", this.startedInButton = a.id, null == (o = this.effects) || o.play("tap", n.x, n.y, "button:" + a.id, this.reducedMotion), void (!1 !== a.enabled && this.setButtonState(a.id, "pressed"));
            if ("PLAYING" === this.screen && this.hitCup(n)) {
              this.pointerKind = "cup";
              var l = this.engine.snapshot();
              return this.cupPointerStartX = n.x, void (this.cupPointerStartOffset = l.cupMotion.offsetXDu);
            }
            this.pointerKind = "ui", this.startedInButton = null;
          }
        }, o.hitCup = function (e) {
          var t,
            i,
            n = C.rules.cup,
            s = n.center_x_du + (null != (t = null == (i = this.engine) ? void 0 : i.snapshot().cupMotion.offsetXDu) ? t : 0),
            r = Math.abs(e.x - s);
          return e.y >= 180 && e.y <= 340 ? r <= n.bottom_width_du / 2 + 16 : !(e.y < 360 || e.y > 720) && r <= n.bottom_width_du / 2 + (e.y - 360) * (n.top_width_du - n.bottom_width_du) / 1280 + 16;
        }, o.moveCup = function (e) {
          var t,
            i,
            n,
            s = this.point(e);
          null == (t = this.engine) || t.setCupTarget(this.cupPointerStartOffset + (s.x - this.cupPointerStartX) * (null != (i = null == (n = C.rules) ? void 0 : n.cup_motion.input_gain) ? i : 1));
        }, o.moveDrop = function (e) {
          var t = this.point(e);
          this.inDropBand(t) && (this.previewX = this.clampPreview(this.dropStartPreviewX + 2 * (t.x - this.dropStartX)), this.updatePreviewPosition());
        }, o.endPointer = function (e) {
          var t = this,
            i = this.point(e);
          if ("overlay" !== this.pointerKind) {
            if ("ui" === this.pointerKind && this.startedInButton) {
              var n,
                s = this.buttons.find(function (e) {
                  return e.id === t.startedInButton && t.contains(e.rect, i.x, i.y);
                });
              if (this.setButtonState(this.startedInButton, "normal"), s && !1 !== s.enabled) this.unlockAudioFromGesture(), null == (n = this.audio) || n.play("ui_tap"), s.action();
            } else if ("cup" === this.pointerKind && "PLAYING" === this.screen) {
              var r;
              this.moveCup(e), null == (r = this.engine) || r.releaseCup(), this.unlockAudioFromGesture();
            } else if ("drop" === this.pointerKind && "PLAYING" === this.screen && this.inDropBand(i)) {
              this.buttons.some(function (e) {
                return t.contains(e.rect, i.x, i.y);
              }) || (this.previewX = this.clampPreview(this.dropStartPreviewX + 2 * (i.x - this.dropStartX)), this.updatePreviewPosition(), this.unlockAudioFromGesture(), "drag_release" === this.mode && this.enqueue("DROP", this.previewX));
            }
            this.primaryPointer = null, this.pointerKind = null, this.startedInButton = null;
          } else {
            var o,
              a = this.startedInOverlay ? this.overlayButtons.find(function (e) {
                return e.id === t.startedInOverlay && t.contains(e.rect, i.x, i.y);
              }) : null;
            this.primaryPointer = null, this.pointerKind = null, this.startedInOverlay = null, a && (this.unlockAudioFromGesture(), null == (o = this.audio) || o.play("ui_tap"), a.action());
          }
        }, o.cancelPointer = function () {
          var e;
          this.startedInButton && this.setButtonState(this.startedInButton, "normal"), "cup" === this.pointerKind && (null == (e = this.engine) || e.cancelCupInput(!1)), this.primaryPointer = null, this.pointerKind = null, this.startedInButton = null, this.startedInOverlay = null, this.dropStartX = 0, this.dropStartPreviewX = this.previewX;
        }, o.point = function (e) {
          var t,
            i,
            n = null != (t = null != (i = null == e.getUILocation ? void 0 : e.getUILocation()) ? i : null == e.getLocation ? void 0 : e.getLocation()) ? t : new y();
          return K(n, C.rules.viewport);
        }, o.contains = function (e, t, i) {
          return t >= e.x && t <= e.x + e.w && i >= e.y && i <= e.y + e.h;
        }, o.clampPreview = function (e) {
          var t,
            i,
            n = this,
            s = null != (t = null == (i = C.rules.ingredients.find(function (e) {
              var t;
              return e.level === (null == (t = n.engine) ? void 0 : t.snapshot().currentLevel);
            })) ? void 0 : i.radius_du) ? t : 18,
            r = C.rules.cup;
          return Math.max(r.center_x_du - r.top_width_du / 2 + s, Math.min(r.center_x_du + r.top_width_du / 2 - s, e));
        }, o.restoreRun = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee28() {
            var e, t, i, n, s, r, o, a, l, u, d, h, c;
            return _regeneratorRuntime().wrap(function _callee28$(_context29) {
              while (1) switch (_context29.prev = _context29.next) {
                case 0:
                  r = this;
                  if (!(!this.loading && this.bundle.run)) {
                    _context29.next = 34;
                    break;
                  }
                  if (!(this.runBestScoreAtStart = null != (e = null != (t = null == (i = this.bundle.profile.bestScoresByRules) || null == (i = i[this.bundle.run.rulesVersion]) || null == (i = i.classic) ? void 0 : i.standard) ? t : null == (n = this.bundle.profile.bestScores[this.bundle.run.stageId]) ? void 0 : n.standard) ? e : 0, this.bundle.run.rulesVersion !== (null == (s = C.rules) ? void 0 : s.design_rules_version))) {
                    _context29.next = 4;
                    break;
                  }
                  return _context29.abrupt("return", (this.notice = "这是旧杯型的未完成局，已保留但不会载入新杯。确认开始新杯后才替换。", void this.render()));
                case 4:
                  this.loading = !0, this.screen = "PAUSED", this.render();
                  o = ++this.ownerEpoch, a = this.startupTraceId = C.startup.beginTrace(o), l = this.art.beginLoadScope(o, a, 15e3, "GAME_ART");
                  _context29.prev = 6;
                  _context29.next = 9;
                  return this.repo.readBundle();
                case 9:
                  u = _context29.sent;
                  if (!(!this.isOwner() || o !== this.ownerEpoch)) {
                    _context29.next = 12;
                    break;
                  }
                  return _context29.abrupt("return");
                case 12:
                  if (u.ok) {
                    _context29.next = 14;
                    break;
                  }
                  throw new Error(u.error.message);
                case 14:
                  if (u.data.envelope) {
                    _context29.next = 16;
                    break;
                  }
                  throw new Error("没有可续局档案");
                case 16:
                  this.bundle = u.data.envelope.payload;
                  this.bundleRevision = u.data.envelope.revision;
                  C.startup.stage("GAME_ART", "start", {
                    assetId: "count:" + this.art.catalog.ids.length
                  }, o, a);
                  _context29.next = 21;
                  return this.loadGameArt();
                case 21:
                  if (!(!this.isOwner() || o !== this.ownerEpoch)) {
                    _context29.next = 23;
                    break;
                  }
                  return _context29.abrupt("return");
                case 23:
                  this.art.settleLoadScope(l), C.startup.stage("GAME_ART", "ok", {
                    assetId: "loaded:" + this.art.loadedCount
                  }, o, a);
                  d = C.rules, h = this.bundle.run;
                  this.adapter = this.createWorld(), this.engine = new I(this.adapter, d, h.runId, h.rng.state, h, this.reviveOptions()), this.engine.setTimingDiagnostics(!1), this.baseTick = h.tick, this.clock = new k(d.physics.fixed_hz, d.physics.max_catchup_steps, function () {
                    return r.advanceRunTick();
                  }), this.clock.pause(), this.pauseOwners = new Set(["RESTORING"]), this.pauseOwners["delete"]("RESTORING"), T.snapshot().resumeRequired && this.pauseOwners.add("RESUME_REQUIRED"), this.screen = this.engine.spillPending ? "REVIVE" : "PAUSED", this.notice = this.engine.spillPending ? "已恢复洒出局面：可观看广告复活一次，或结束本局。" : "已从最近完整保存恢复；点击“继续”后才推进。", this.bindRewardedShake(), this.bindSpillRevive(), this.render(), this.hideOverlay(), C.startup.stage("HUD_READY", "ok", {
                    assetId: "screen:" + this.screen
                  }, o, a);
                  _context29.next = 31;
                  break;
                case 28:
                  _context29.prev = 28;
                  _context29.t0 = _context29["catch"](6);
                  if (this.art.cancelScope(this.startupErrorCode(_context29.t0), l), this.isOwner() && o === this.ownerEpoch) {
                    c = this.startupErrorCode(_context29.t0);
                    C.startup.stage("GAME_ART", "error", {
                      code: c,
                      error: _context29.t0
                    }, o, a), this.showStartupFailure(c, String(_context29.t0), a);
                  }
                case 31:
                  _context29.prev = 31;
                  this.isOwner() && o === this.ownerEpoch && (this.loading = !1);
                  return _context29.finish(31);
                case 34:
                case "end":
                  return _context29.stop();
              }
            }, _callee28, this, [[6, 28, 31, 34]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.persistSettings = function () {
          var e = s( /*#__PURE__*/_regeneratorRuntime().mark(function _callee29() {
            var e, t, i, s, r, o, a, l, u, d;
            return _regeneratorRuntime().wrap(function _callee29$(_context30) {
              while (1) switch (_context30.prev = _context30.next) {
                case 0:
                  i = this.activeSaveRepository();
                  if (!i) {
                    _context30.next = 29;
                    break;
                  }
                  if (!this.saveInFlight) {
                    _context30.next = 6;
                    break;
                  }
                  this.settingsDirty = !0;
                  _context30.next = 27;
                  break;
                case 6:
                  s = this.beginSaveTask();
                  if (!(null !== s)) {
                    _context30.next = 26;
                    break;
                  }
                  r = this.ownerEpoch, o = this.bundleRevision, a = null != (e = null == (t = this.bundle.run) ? void 0 : t.runId) ? e : null, l = n({}, this.bundle.profile, {
                    settings: n({}, this.bundle.profile.settings, {
                      dropMode: this.mode,
                      reducedMotion: this.reducedMotion
                    }),
                    revision: this.bundle.profile.revision + 1
                  }), u = n({}, this.bundle, {
                    profile: l
                  });
                  _context30.prev = 9;
                  _context30.next = 12;
                  return i.commitBundle(o, a, u);
                case 12:
                  d = _context30.sent;
                  if (this.ownsSaveTask(s, r)) {
                    _context30.next = 15;
                    break;
                  }
                  return _context30.abrupt("return");
                case 15:
                  d.ok ? (this.bundle = u, this.bundleRevision = d.data.revision) : this.notice = "设置未保存：" + d.error.message;
                  _context30.next = 21;
                  break;
                case 18:
                  _context30.prev = 18;
                  _context30.t0 = _context30["catch"](9);
                  this.ownsSaveTask(s, r) && (this.notice = "设置未保存：" + String(_context30.t0));
                case 21:
                  _context30.prev = 21;
                  this.ownsSaveTask(s, r) && "PLAYING" !== this.screen && this.render(), this.finishSaveTask(s);
                  return _context30.finish(21);
                case 24:
                  _context30.next = 27;
                  break;
                case 26:
                  this.settingsDirty = !0;
                case 27:
                  _context30.next = 30;
                  break;
                case 29:
                  this.notice = "设置仅保存在当前页面内存中。";
                case 30:
                case "end":
                  return _context30.stop();
              }
            }, _callee29, this, [[9, 18, 21, 24]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), o.advanceRunTick = function () {
          var e,
            t,
            i,
            n,
            s = null != (e = null == (t = this.engine) ? void 0 : t.advanceOneTick()) ? e : [];
          if (this.engine && (this.readContactFeedback(), ("SETTLING" === this.engine.phase || this.engine.spillPending) && (null == (n = this.clock) || n.pause()), this.engine.lastTickFault)) {
            var r;
            null == (r = this.clock) || r.pause(), this.pauseOwners.add("TECHNICAL_ERROR"), this.cancelPointer(), this.screen = "ERROR";
            var o = this.engine.lastTickFault.includes("|ROLLBACK:");
            return this.notice = o ? "本局恢复未完成，原存档保持不变。错误编号 PHYSICS_ROLLBACK_FAILED" : "本局遇到问题，已恢复到上一个完整物理步。错误编号 PHYSICS_TICK_ROLLED_BACK", o ? this.saveDirty = !1 : (this.saveDirty = !0, this.commitCheckpoint(!0)), this.render(), !1;
          }
          return this.startupTraceId !== this.firstTickTraceId && this.engine && (this.firstTickTraceId = this.startupTraceId, C.startup.stage("FIRST_TICK", "ok", {
            code: "tick:" + this.engine.tick
          }, this.ownerEpoch, this.startupTraceId)), (i = this.lastEvents).push.apply(i, s), !0;
        }, o.levelName = function (e) {
          var t, i;
          return null != (t = null == (i = C.rules.ingredients.find(function (t) {
            return t.level === e;
          })) ? void 0 : i.name) ? t : "等级" + e;
        }, o.makeUuid = function () {
          var e = globalThis.crypto;
          if (null != e && e.randomUUID) return e.randomUUID();
          var t = new Uint8Array(16);
          if (null != e && e.getRandomValues) e.getRandomValues(t);else for (var i = 0; i < t.length; i++) t[i] = Math.floor(256 * Math.random());
          t[6] = 15 & t[6] | 64, t[8] = 63 & t[8] | 128;
          var n = Array.from(t, function (e) {
            return e.toString(16).padStart(2, "0");
          }).join("");
          return n.slice(0, 8) + "-" + n.slice(8, 12) + "-" + n.slice(12, 16) + "-" + n.slice(16, 20) + "-" + n.slice(20);
        }, o.seed = function () {
          var e,
            t = new Uint32Array(1);
          return null != (e = globalThis.crypto) && e.getRandomValues ? globalThis.crypto.getRandomValues(t) : t[0] = Math.floor(4294967296 * Math.random()), t[0] || 1;
        }, o.enterTechnicalError = function (e) {
          var t, i;
          null == (t = this.clock) || t.pause(), null == (i = this.engine) || i.pause("TECHNICAL_ERROR"), this.pauseOwners.add("TECHNICAL_ERROR"), this.screen = "ERROR", this.notice = "物理/运行错误已冻结现场：" + e, this.commitCheckpoint(!0), this.render();
        }, r;
      }(E)).nextSceneId = 1, j.nextWorldId = 1, X = j)) || X);
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/HostLifecycleCoordinator.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (e) {
  var i, n, t, s, r;
  return {
    setters: [function (e) {
      i = e.createClass, n = e.createForOfIteratorHelperLoose;
    }, function (e) {
      t = e.cclegacy, s = e.game, r = e.Game;
    }],
    execute: function execute() {
      var o;
      t._RF.push({}, "3f5cfo+HdxAQKyMI5gYetCy", "HostLifecycleCoordinator", void 0);
      var d = e("HostResumeLatch", function () {
          function e() {
            this._backgrounded = !1, this._resumeRequired = !1, this._hideEpoch = 0, this._confirmedHideEpoch = 0;
          }
          var n = e.prototype;
          return n.setBackgrounded = function (e) {
            return e !== this._backgrounded && (this._backgrounded = e, e && (this._hideEpoch++, this._resumeRequired = !0), !0);
          }, n.confirmResume = function (e, i, n, t) {
            return i ? !n || this._backgrounded ? {
              ok: !1,
              reason: "BACKGROUND",
              confirmed: !1
            } : t ? this._resumeRequired ? e !== this._hideEpoch ? {
              ok: !1,
              reason: "STALE_HIDE_EPOCH",
              confirmed: !1
            } : (this._resumeRequired = !1, this._confirmedHideEpoch = e, {
              ok: !0,
              reason: null,
              confirmed: !0
            }) : {
              ok: !0,
              reason: null,
              confirmed: !1
            } : {
              ok: !1,
              reason: "PAUSE_GUARD",
              confirmed: !1
            } : {
              ok: !1,
              reason: "INITIALIZING",
              confirmed: !1
            };
          }, e.verifyTransitions = function () {
            var i = new e(),
              n = {};
            n.normalStartupStaysOpen = !i.resumeRequired && 0 === i.hideEpoch, i.setBackgrounded(!0);
            var t = i.hideEpoch;
            i.setBackgrounded(!1), n.showDoesNotAcknowledge = i.resumeRequired && i.hideEpoch === t, n.notReadyCannotAcknowledge = !i.confirmResume(t, !1, !0, !0).ok && i.resumeRequired, n.galleryGuardCannotAcknowledge = !i.confirmResume(t, !0, !0, !1).ok && i.resumeRequired, n.validResumeConfirmsCurrentHide = i.confirmResume(t, !0, !0, !0).confirmed && !i.resumeRequired && i.confirmedHideEpoch === t, i.setBackgrounded(!0);
            var s = i.hideEpoch;
            return i.setBackgrounded(!1), n.oldResumeCannotClearNewHide = s > t && !i.confirmResume(t, !0, !0, !0).ok && i.resumeRequired, n.hiddenCannotAcknowledge = !i.confirmResume(s, !0, !1, !0).ok && i.resumeRequired, n.newValidResumeConfirmsNewHide = i.confirmResume(s, !0, !0, !0).confirmed && !i.resumeRequired && i.confirmedHideEpoch === s, n;
          }, i(e, [{
            key: "backgrounded",
            get: function get() {
              return this._backgrounded;
            }
          }, {
            key: "resumeRequired",
            get: function get() {
              return this._resumeRequired;
            }
          }, {
            key: "hideEpoch",
            get: function get() {
              return this._hideEpoch;
            }
          }, {
            key: "confirmedHideEpoch",
            get: function get() {
              return this._confirmedHideEpoch;
            }
          }]), e;
        }()),
        u = e("HostLifecycleCoordinator", function () {
          function e() {}
          return e.install = function () {
            var e = this;
            this.installed || (this.installed = !0, s.on(r.EVENT_HIDE, this.onEngineHide, this), s.on(r.EVENT_SHOW, this.onEngineShow, this), "undefined" != typeof document && (this.visibilityListener = function (i) {
              return e.setDomHidden("hidden" === document.visibilityState, i.isTrusted);
            }, document.addEventListener("visibilitychange", this.visibilityListener), this.setDomHidden("hidden" === document.visibilityState, null)), this.record("install", this.backgrounded, null));
          }, e.subscribe = function (e) {
            var i = this;
            return this.listeners.add(e), e(this.snapshot()), function () {
              i.listeners["delete"](e);
            };
          }, e.snapshot = function () {
            return {
              domHidden: this.domHidden,
              engineHidden: this.engineHidden,
              backgrounded: this.backgrounded,
              resumeRequired: this.resumeLatch.resumeRequired,
              hideEpoch: this.resumeLatch.hideEpoch,
              confirmedHideEpoch: this.resumeLatch.confirmedHideEpoch,
              revision: this.revision,
              eventCount: this.totalEvents,
              events: this.events.slice()
            };
          }, e.confirmUserResume = function (e, i, t, s) {
            var r = this.resumeLatch.confirmResume(e, i, t, s);
            if (r.confirmed) {
              this.revision++, this.record("resume-confirm", !1, null);
              for (var o, d = this.snapshot(), u = n(this.listeners); !(o = u()).done;) {
                (0, o.value)(d);
              }
            }
            return r;
          }, e.verifyResumeTransitionsForTests = function () {
            return d.verifyTransitions();
          }, e.disposeForTests = function () {
            this.installed && (s.off(r.EVENT_HIDE, this.onEngineHide, this), s.off(r.EVENT_SHOW, this.onEngineShow, this), this.visibilityListener && "undefined" != typeof document && document.removeEventListener("visibilitychange", this.visibilityListener), this.visibilityListener = null, this.installed = !1, this.listeners.clear());
          }, e.setDomHidden = function (e, i) {
            if (this.domHidden !== e) {
              var n = this.backgrounded;
              this.domHidden = e, this.publish("dom", e, i, n);
            } else this.record("dom", e, i);
          }, e.setEngineHidden = function (e) {
            if (this.engineHidden !== e) {
              var i = this.backgrounded;
              this.engineHidden = e, this.publish("engine", e, null, i);
            } else this.record("engine", e, null);
          }, e.publish = function (e, i, t, s) {
            s !== this.backgrounded && (this.revision++, this.resumeLatch.setBackgrounded(this.backgrounded)), this.record(e, i, t);
            for (var r, o = this.snapshot(), d = n(this.listeners); !(r = d()).done;) {
              (0, r.value)(o);
            }
          }, e.record = function (e, i, n) {
            this.totalEvents++, this.events.push({
              source: e,
              hidden: i,
              backgrounded: this.backgrounded,
              trusted: n,
              atMs: "undefined" != typeof performance ? performance.now() : Date.now(),
              revision: this.revision
            }), this.events.length > 128 && this.events.shift();
          }, i(e, null, [{
            key: "backgrounded",
            get: function get() {
              return this.domHidden || this.engineHidden;
            }
          }]), e;
        }());
      o = u, u.domHidden = !1, u.engineHidden = !1, u.revision = 0, u.totalEvents = 0, u.installed = !1, u.listeners = new Set(), u.resumeLatch = new d(), u.events = [], u.visibilityListener = null, u.onEngineHide = function () {
        return o.setEngineHidden(!0);
      }, u.onEngineShow = function () {
        return o.setEngineHidden(!1);
      }, t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/LocalSaveRepository.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./CloneState.ts", "./SaveCodec.ts", "./SaveMigration.ts", "./SaveValidator.ts"], function (e) {
  var r, t, n, o, i, l, a;
  return {
    setters: [function (e) {
      r = e["extends"], t = e.asyncToGenerator;
    }, function (e) {
      n = e.cclegacy;
    }, function (e) {
      o = e.cloneState;
    }, function (e) {
      i = e.SaveCodec;
    }, function (e) {
      l = e.SaveMigration;
    }, function (e) {
      a = e.SaveValidator;
    }],
    execute: function execute() {
      var s;
      n._RF.push({}, "6b825kCf/1EhqsIUbW4AlNx", "LocalSaveRepository", void 0);
      var u = function u(e, r, t) {
          return void 0 === t && (t = !1), {
            ok: !1,
            error: {
              code: e,
              message: r,
              retryable: t
            }
          };
        },
        p = function p(e) {
          return {
            ok: !0,
            data: e
          };
        },
        c = e("LocalSaveRepository", function () {
          function e(e, r) {
            this.memory = new Map(), this.storage = null, this.leaseMode = "memory-only", this.leaseRelease = null, this.failOnce = null, this.tapStorage = !1, this.debugNamespace = e;
            var t = globalThis.tap;
            if (!r && t && "function" == typeof t.getStorageSync && "function" == typeof t.setStorageSync && "function" == typeof t.removeStorageSync) this.tapStorage = !0, this.storage = {
              getItem: function getItem(e) {
                var r = t.getStorageSync(e);
                return null == r || "" === r ? null : "string" == typeof r ? r : JSON.stringify(r);
              },
              setItem: function setItem(e, r) {
                return t.setStorageSync(e, r);
              },
              removeItem: function removeItem(e) {
                return t.removeStorageSync(e);
              }
            };else try {
              this.storage = null != r ? r : "undefined" != typeof localStorage ? localStorage : null;
            } catch (e) {
              this.storage = null;
            }
          }
          var n = e.prototype;
          return n.injectFaultOnce = function (e) {
            this.failOnce = e;
          }, n.acquireWriteLease = function () {
            var r = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee31() {
              var r, n, o, i, l, a, s, c, v;
              return _regeneratorRuntime().wrap(function _callee31$(_context32) {
                while (1) switch (_context32.prev = _context32.next) {
                  case 0:
                    n = this;
                    if (!this.leaseRelease) {
                      _context32.next = 3;
                      break;
                    }
                    return _context32.abrupt("return", u("SAVE_LEASE_HELD", "本页面已持有存档写租约"));
                  case 3:
                    o = this.debugNamespace ? e.prefix + ".debug." + this.debugNamespace + ".writer" : e.prefix + ".writer";
                    if (!(this.tapStorage && this.storage)) {
                      _context32.next = 10;
                      break;
                    }
                    if (!e.tapWriters.has(o)) {
                      _context32.next = 7;
                      break;
                    }
                    return _context32.abrupt("return", u("SAVE_WRITER_EXISTS", "当前小游戏已有存档写入者", !0));
                  case 7:
                    e.tapWriters.add(o), this.leaseMode = "persistent";
                    i = function r() {
                      n.leaseRelease === r && (e.tapWriters["delete"](o), n.leaseRelease = null, n.leaseMode = "memory-only");
                    };
                    return _context32.abrupt("return", (this.leaseRelease = i, p({
                      mode: "persistent",
                      release: i
                    })));
                  case 10:
                    l = null == (r = globalThis.navigator) ? void 0 : r.locks;
                    if (!(null == l || !l.request || !this.storage)) {
                      _context32.next = 13;
                      break;
                    }
                    return _context32.abrupt("return", (this.leaseMode = "memory-only", p({
                      mode: "memory-only",
                      release: function release() {}
                    })));
                  case 13:
                    a = null, s = null, c = new Promise(function (e, r) {
                      a = e, s = r;
                    }), v = new Promise(function (e) {
                      n.leaseRelease = e;
                    });
                    l.request(o, {
                      mode: "exclusive",
                      ifAvailable: !0
                    }, t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee30(e) {
                      return _regeneratorRuntime().wrap(function _callee30$(_context31) {
                        while (1) switch (_context31.prev = _context31.next) {
                          case 0:
                            if (e) {
                              _context31.next = 2;
                              break;
                            }
                            return _context31.abrupt("return", (n.leaseRelease = null, void (null == s || s(new Error("SAVE_WRITER_EXISTS")))));
                          case 2:
                            n.leaseMode = "persistent";
                            null == a || a();
                            _context31.next = 6;
                            return v;
                          case 6:
                            n.leaseRelease = null;
                          case 7:
                          case "end":
                            return _context31.stop();
                        }
                      }, _callee30);
                    })))["catch"](function (e) {
                      n.leaseRelease = null, null == s || s(e);
                    });
                    _context32.prev = 15;
                    _context32.next = 18;
                    return c;
                  case 18:
                    return _context32.abrupt("return", p({
                      mode: "persistent",
                      release: function release() {
                        return null == n.leaseRelease ? void 0 : n.leaseRelease();
                      }
                    }));
                  case 21:
                    _context32.prev = 21;
                    _context32.t0 = _context32["catch"](15);
                    return _context32.abrupt("return", u("SAVE_WRITER_EXISTS", String(_context32.t0), !0));
                  case 24:
                  case "end":
                    return _context32.stop();
                }
              }, _callee31, this, [[15, 21]]);
            }));
            return function () {
              return r.apply(this, arguments);
            };
          }(), n.readBundle = function () {
            var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee32() {
              var e, r, t, n, o, l, a;
              return _regeneratorRuntime().wrap(function _callee32$(_context33) {
                while (1) switch (_context33.prev = _context33.next) {
                  case 0:
                    _context33.prev = 0;
                    t = this.readSlot("A"), n = this.readSlot("B");
                    _context33.next = 7;
                    break;
                  case 4:
                    _context33.prev = 4;
                    _context33.t0 = _context33["catch"](0);
                    return _context33.abrupt("return", u("STORAGE_IO_ERROR", "读取存档失败：" + String(_context33.t0), !0));
                  case 7:
                    if (!(t.unknownVersion || n.unknownVersion)) {
                      _context33.next = 9;
                      break;
                    }
                    return _context33.abrupt("return", u("SAVE_VERSION_UNSUPPORTED", "发现较新或不支持的存档版本；为保护原档，已禁止回退与写入"));
                  case 9:
                    if (!(t.ioError || n.ioError)) {
                      _context33.next = 11;
                      break;
                    }
                    return _context33.abrupt("return", u("STORAGE_IO_ERROR", "读取存档失败：" + (null != (e = t.ioError) ? e : n.ioError), !0));
                  case 11:
                    if (!(t.error && n.error)) {
                      _context33.next = 13;
                      break;
                    }
                    return _context33.abrupt("return", u("STORAGE_CORRUPT", "双槽均不可恢复：A=" + t.error + "；B=" + n.error));
                  case 13:
                    if (!(t.envelope && n.envelope && t.envelope.revision === n.envelope.revision && i.canonicalJson(t.envelope.payload) !== i.canonicalJson(n.envelope.payload))) {
                      _context33.next = 15;
                      break;
                    }
                    return _context33.abrupt("return", u("SAVE_REVISION_CONFLICT", "相同revision存在不同有效档；原始槽均保留"));
                  case 15:
                    o = t.envelope ? n.envelope ? t.envelope.revision >= n.envelope.revision ? t.envelope : n.envelope : t.envelope : n.envelope, l = o === t.envelope ? "A" : o === n.envelope ? "B" : null, a = t.error || n.error ? "一槽损坏，已回退到另一完整槽；坏槽字节保留。" + (null != (r = t.error) ? r : n.error) : void 0;
                    return _context33.abrupt("return", o ? {
                      ok: !0,
                      data: {
                        envelope: o,
                        recoveredFromSlot: l,
                        warning: a
                      }
                    } : {
                      ok: !0,
                      data: {
                        envelope: null,
                        recoveredFromSlot: null
                      }
                    });
                  case 17:
                  case "end":
                    return _context33.stop();
                }
              }, _callee32, this, [[0, 4]]);
            }));
            return function () {
              return e.apply(this, arguments);
            };
          }(), n.commitBundle = function () {
            var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee33(e, t, n) {
              var l, s, c, v, d, f, h, m, y, S, E, g, I, R, A, V, _, O;
              return _regeneratorRuntime().wrap(function _callee33$(_context34) {
                while (1) switch (_context34.prev = _context34.next) {
                  case 0:
                    if (!("persistent" !== this.leaseMode)) {
                      _context34.next = 2;
                      break;
                    }
                    return _context34.abrupt("return", u("SAVE_MEMORY_ONLY", "当前浏览器缺少可靠跨标签锁，存档仅在内存可用", !0));
                  case 2:
                    _context34.next = 4;
                    return this.readBundle();
                  case 4:
                    v = _context34.sent;
                    if (v.ok) {
                      _context34.next = 7;
                      break;
                    }
                    return _context34.abrupt("return", v);
                  case 7:
                    f = v.data.envelope, h = null != (l = null == f ? void 0 : f.revision) ? l : 0, m = null != (s = null == f || null == (c = f.payload.run) ? void 0 : c.runId) ? s : null;
                    if (!(h !== e || m !== t)) {
                      _context34.next = 10;
                      break;
                    }
                    return _context34.abrupt("return", u("CONFLICT_REVISION", "存档已由新操作更新，请先重新读取"));
                  case 10:
                    _context34.prev = 10;
                    d = r({}, o(n), {
                      run: n.run ? i.sealSnapshot(n.run) : null
                    });
                    _context34.next = 17;
                    break;
                  case 14:
                    _context34.prev = 14;
                    _context34.t0 = _context34["catch"](10);
                    return _context34.abrupt("return", u("SAVE_NORMALIZE_FAILED", "档案规范化失败：" + String(_context34.t0)));
                  case 17:
                    y = a.bundle(d);
                    if (y.valid) {
                      _context34.next = 20;
                      break;
                    }
                    return _context34.abrupt("return", u(y.code, y.message));
                  case 20:
                    S = i.createEnvelopeV2(h + 1, d), E = "A" === v.data.recoveredFromSlot ? "B" : "A", g = this.key(E);
                    _context34.prev = 21;
                    I = this.getItem(g);
                    if (!(null !== I)) {
                      _context34.next = 28;
                      break;
                    }
                    if (!this.readSlot(E).error) {
                      _context34.next = 28;
                      break;
                    }
                    R = this.key("backup-" + E);
                    if (!(null === this.getItem(R) && this.setItem(R, I), this.getItem(R) !== I)) {
                      _context34.next = 28;
                      break;
                    }
                    return _context34.abrupt("return", u("SAVE_CORRUPT_BACKUP_FAILED", "损坏槽原始字节备份失败，拒绝覆盖"));
                  case 28:
                    if (!this.fault("write-before")) {
                      _context34.next = 30;
                      break;
                    }
                    throw new Error("INJECTED_WRITE_BEFORE");
                  case 30:
                    A = i.canonicalJson(S), V = this.fault("partial-slot") ? Math.max(1, Math.floor(A.length / 2)) : A.length;
                    if (!(this.setItem(g, A.slice(0, V)), V !== A.length)) {
                      _context34.next = 33;
                      break;
                    }
                    throw new Error("INJECTED_PARTIAL_SLOT");
                  case 33:
                    if (!this.fault("slot-complete")) {
                      _context34.next = 35;
                      break;
                    }
                    return _context34.abrupt("return", this.resolveAmbiguousCommit(S, E, "INJECTED_SLOT_COMPLETE"));
                  case 35:
                    _ = this.getItem(g);
                    if (_) {
                      _context34.next = 38;
                      break;
                    }
                    throw new Error("SAVE_READBACK_EMPTY");
                  case 38:
                    O = JSON.parse(_);
                    if (!this.fault("readback")) {
                      _context34.next = 41;
                      break;
                    }
                    throw new Error("INJECTED_READBACK");
                  case 41:
                    if (!(!a.envelope(O) || O.checksum !== S.checksum)) {
                      _context34.next = 43;
                      break;
                    }
                    throw new Error("SAVE_READBACK_INVALID");
                  case 43:
                    if (!this.fault("pre-pointer")) {
                      _context34.next = 45;
                      break;
                    }
                    throw new Error("INJECTED_PRE_POINTER");
                  case 45:
                    _context34.prev = 45;
                    if (!this.fault("pointer")) {
                      _context34.next = 48;
                      break;
                    }
                    throw new Error("INJECTED_POINTER");
                  case 48:
                    this.setItem(this.key("pointer"), E);
                    _context34.next = 54;
                    break;
                  case 51:
                    _context34.prev = 51;
                    _context34.t1 = _context34["catch"](45);
                    return _context34.abrupt("return", p({
                      revision: S.revision,
                      committed: !0,
                      pointerUpdated: !1,
                      warning: "档案已提交，但指针未更新：" + String(_context34.t1)
                    }));
                  case 54:
                    return _context34.abrupt("return", p({
                      revision: S.revision,
                      committed: !0,
                      pointerUpdated: !0
                    }));
                  case 57:
                    _context34.prev = 57;
                    _context34.t2 = _context34["catch"](21);
                    return _context34.abrupt("return", this.resolveAmbiguousCommit(S, E, String(_context34.t2)));
                  case 60:
                  case "end":
                    return _context34.stop();
                }
              }, _callee33, this, [[10, 14], [21, 57], [45, 51]]);
            }));
            return function (r, t, n) {
              return e.apply(this, arguments);
            };
          }(), n.exportRaw = function () {
            return {
              A: this.getItem(this.key("A")),
              B: this.getItem(this.key("B")),
              pointer: this.getItem(this.key("pointer"))
            };
          }, n.clearDebugNamespace = function () {
            if (this.debugNamespace) for (var e = 0, r = Object.keys(this.exportRaw()); e < r.length; e++) {
              var t = r[e];
              this.removeItem(this.key(t));
            }
          }, n.fault = function (e) {
            return this.failOnce === e && (this.failOnce = null, !0);
          }, n.key = function (r) {
            return this.debugNamespace ? "milktea.p1b.debug." + this.debugNamespace + "." + r : "backup-A" === r || "backup-B" === r ? e.prefix + "." + r : e.keys[r];
          }, n.readSlot = function (e) {
            var t;
            try {
              t = this.getItem(this.key(e));
            } catch (e) {
              return {
                envelope: null,
                error: null,
                ioError: String(e)
              };
            }
            if (null === t) return {
              envelope: null,
              error: null
            };
            try {
              var n, o, s;
              if (t.length > 2e6) return {
                envelope: null,
                error: "SAVE_TOO_LARGE"
              };
              var u = JSON.parse(t);
              if (u && "object" == _typeof(u) && Number.isInteger(u.schemaVersion) && 1 !== u.schemaVersion && 2 !== u.schemaVersion) return {
                envelope: null,
                error: "SAVE_VERSION_UNSUPPORTED",
                unknownVersion: !0
              };
              if (a.envelope(u)) return {
                envelope: u,
                error: null
              };
              if (2 === (null == u ? void 0 : u.schemaVersion) && null === (null == (n = u.payload) ? void 0 : n.run) && i.verifyEnvelopeV2(u) && a.profileV2(u.payload.profile)) {
                var p = r({}, u.payload, {
                  profile: l.profileV2(u.payload.profile),
                  run: null
                });
                return {
                  envelope: i.createEnvelopeV2(u.revision, p),
                  error: null,
                  migrated: !0
                };
              }
              if (2 === (null == u ? void 0 : u.schemaVersion) && 4 === (null == (o = u.payload) || null == (o = o.run) ? void 0 : o.saveSchemaVersion) && i.verifyEnvelopeV2(u) && a.profileV2(u.payload.profile) && a.legacySnapshotV4(u.payload.run).valid) {
                var c = r({}, u.payload, {
                  profile: l.profileV2(u.payload.profile),
                  run: l.runV4(u.payload.run)
                });
                return {
                  envelope: i.createEnvelopeV2(u.revision, c),
                  error: null,
                  migrated: !0
                };
              }
              if (2 === (null == u ? void 0 : u.schemaVersion) && 3 === (null == (s = u.payload) || null == (s = s.run) ? void 0 : s.saveSchemaVersion) && i.verifyEnvelopeV2(u) && a.profileV2(u.payload.profile) && a.legacySnapshot(u.payload.run, 3).valid) {
                var v = r({}, u.payload, {
                  profile: l.profileV2(u.payload.profile),
                  run: l.runV3(u.payload.run)
                });
                return {
                  envelope: i.createEnvelopeV2(u.revision, v),
                  error: null,
                  migrated: !0
                };
              }
              if (a.legacyEnvelope(u)) {
                var d = l.bundle(u.payload);
                return {
                  envelope: i.createEnvelopeV2(u.revision, d),
                  error: null,
                  migrated: !0
                };
              }
              return {
                envelope: null,
                error: "SAVE_INVALID"
              };
            } catch (e) {
              return {
                envelope: null,
                error: "SAVE_PARSE:" + String(e)
              };
            }
          }, n.resolveAmbiguousCommit = function (e, r, t) {
            try {
              var n,
                o = this.getItem(this.key(r));
              if (null !== o) {
                var i = JSON.parse(o);
                if (a.envelope(i) && i.revision === e.revision && i.checksum === e.checksum) return p({
                  revision: e.revision,
                  committed: !0,
                  pointerUpdated: !1,
                  warning: "写入后发生异常，但operation内容核对确认已提交：" + t
                });
              }
              var l = this.readSlot("A" === r ? "B" : "A");
              return (null == (n = l.envelope) ? void 0 : n.revision) === e.revision && l.envelope.checksum === e.checksum ? p({
                revision: e.revision,
                committed: !0,
                pointerUpdated: !1,
                warning: "异常后由双槽核对确认已提交：" + t
              }) : u("SAVE_COMMIT_UNCERTAIN", "写入异常且无法确认提交状态，禁止盲目重试：" + t, !1);
            } catch (e) {
              return u("SAVE_COMMIT_UNCERTAIN", "写入异常且读取核对失败，禁止盲目重试：" + String(e), !1);
            }
          }, n.getItem = function (e) {
            var r, t, n;
            return null != (r = null != (t = null == (n = this.storage) ? void 0 : n.getItem(e)) ? t : this.memory.get(e)) ? r : null;
          }, n.setItem = function (e, r) {
            this.storage ? this.storage.setItem(e, r) : this.memory.set(e, r);
          }, n.removeItem = function (e) {
            this.storage ? this.storage.removeItem(e) : this.memory["delete"](e);
          }, e.emptyBundle = function () {
            return {
              profile: {
                schemaVersion: 3,
                settings: {
                  musicGain: .35,
                  sfxGain: .7,
                  reducedMotion: !1,
                  dropMode: "drag_release",
                  tutorialCompleted: !1
                },
                discoveredLevels: [],
                unlockedStageIds: ["classic"],
                bestScores: {},
                activeRunId: null,
                revision: 0,
                firstNaturalRunCompleted: !1,
                rewardedShake: {
                  dayKey: null,
                  dailyGranted: 0,
                  pendingAttempt: null,
                  receipts: []
                },
                rewardedRevive: {
                  dayKey: null,
                  dailyGranted: 0,
                  pendingAttempt: null,
                  receipts: []
                }
              },
              run: null,
              lastResult: null
            };
          }, e;
        }());
      s = c, c.prefix = "milktea.p1b.local.v1", c.keys = {
        A: s.prefix + ".slotA",
        B: s.prefix + ".slotB",
        pointer: s.prefix + ".pointer"
      }, c.tapWriters = new Set(), n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/main", ["./migrate-canvas.ts", "./RewardedAdCoordinator.ts", "./RewardedShakeService.ts", "./SpillReviveService.ts", "./AppRoot.ts", "./Viewport.ts", "./types.ts", "./AppRuntime.ts", "./ArtLoadBudget.ts", "./Clock.ts", "./CloneState.ts", "./ConfigLoader.ts", "./DiagnosticRing.ts", "./EventIdentity.ts", "./HostLifecycleCoordinator.ts", "./RewardedAdPolicyLoader.ts", "./RunEngine.ts", "./RunRng.ts", "./Sha256.ts", "./SpawnRng.ts", "./SpillRevivePolicyLoader.ts", "./StartupTrace.ts", "./EffectsController.ts", "./LocalSaveRepository.ts", "./ReviveLedger.ts", "./RewardLedger.ts", "./SaveCodec.ts", "./SaveMigration.ts", "./SaveValidator.ts", "./CocosPhysicsAdapter.ts", "./CoordinateMapper.ts", "./CupGeometry.ts", "./CupSweepProbe.ts", "./RewardedAdProviderFactory.ts", "./TapRewardedAdProvider.ts", "./ArtAssets.ts", "./ArtCatalog.ts", "./GameAudio.ts", "./GameRoot.ts"], function () {
  return {
    setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
    execute: function execute() {}
  };
});
System.register("chunks:///_virtual/migrate-canvas.ts", ["cc"], function () {
  var n, e, t, i, r, o, a;
  return {
    setters: [function (c) {
      n = c.cclegacy, e = c.director, t = c.Director, i = c.Canvas, r = c.Camera, o = c.game, a = c.Node;
    }],
    execute: function execute() {
      n._RF.push({}, "622c5UGaqFGkYU+n9gQB/We", "migrate-canvas", void 0);
      var c = 1048575;
      function l(n, e) {
        for (var t = 0, i = n.children.length; t < i; t++) n.children[t].layer = e, l(n.children[t], e);
      }
      e.on(t.EVENT_AFTER_SCENE_LAUNCH, function () {
        var n,
          t,
          a,
          s = null == (n = e.getScene()) ? void 0 : n.children,
          m = null == (t = e.getScene()) ? void 0 : t.getComponentsInChildren(i);
        if (!(m.length <= 1)) {
          m = m.filter(function (n) {
            return !!n.cameraComponent;
          });
          var v = null == (a = e.getScene()) ? void 0 : a.getComponentsInChildren(r),
            p = 0;
          v.forEach(function (n) {
            return p |= n.visibility & c;
          });
          for (var u = [], f = 0, C = s.length; f < C; f++) {
            var h = s[f];
            if (o.isPersistRootNode(h)) {
              var d = h.getComponentsInChildren(i);
              0 !== d.length && u.push.apply(u, d.filter(function (n) {
                return !!n.cameraComponent;
              }));
            }
          }
          u.forEach(function (n) {
            if (m.find(function (e) {
              return e !== n && e.cameraComponent.visibility & n.cameraComponent.visibility & c;
            })) {
              var e = ~p,
                t = e & ~(e - 1);
              n.cameraComponent.visibility = t | 4293918720 & n.cameraComponent.visibility, l(n.node, t), p |= e;
            }
          });
        }
      });
      var s = a.prototype.setParent;
      function m(n) {
        var e = 0,
          t = n.getComponent(i);
        return t && t.cameraComponent ? e = t.cameraComponent.visibility & t.node.layer ? t.node.layer : t.cameraComponent.visibility & ~(t.cameraComponent.visibility - 1) : (n.parent && (e = m(n.parent)), e);
      }
      a.prototype.setParent = function (n, e) {
        if (s.call(this, n, e), n) {
          var t = m(this);
          t && (this.layer = t, l(this, t));
        }
      }, n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/ReviveLedger.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (e) {
  var n, t;
  return {
    setters: [function (e) {
      n = e["extends"];
    }, function (e) {
      t = e.cclegacy;
    }],
    execute: function execute() {
      t._RF.push({}, "6403ai5TQtCi4CVfgygUQCU", "ReviveLedger", void 0), e("ReviveLedger", function () {
        function e() {}
        return e.dayKey = function (e) {
          return new Date(e + 288e5).toISOString().slice(0, 10);
        }, e.normalize = function (e, t) {
          return e.dayKey === t ? e : n({}, e, {
            dayKey: t,
            dailyGranted: e.receipts.filter(function (e) {
              return e.dayKey === t;
            }).length
          });
        }, e.grantedForDay = function (e, n) {
          var t = e.receipts.filter(function (e) {
            return e.dayKey === n;
          }).length;
          return Math.max(e.dayKey === n ? e.dailyGranted : 0, t);
        }, e.pendingForRun = function (e, n) {
          var t;
          return n && (null == (t = e.pendingAttempt) ? void 0 : t.runId) === n ? e.pendingAttempt : null;
        }, e.hasReceipt = function (e, n) {
          return e.receipts.some(function (e) {
            return e.attemptId === n;
          });
        }, e.checkOffer = function (e) {
          var n = e.policy,
            t = e.capability,
            r = e.profile,
            i = e.run,
            a = e.foregroundSeconds,
            d = e.tutorialComplete;
          e.nowMs;
          return n.enabled ? "UNCONFIGURED" === t ? {
            allowed: !1,
            block: "AD_UNCONFIGURED"
          } : "SUPPORTED" !== t ? {
            allowed: !1,
            block: "AD_UNSUPPORTED"
          } : i && "PAUSED" === i.state && i.revive.pendingFailure ? i.revive.used >= n.maxRevivesPerRun ? {
            allowed: !1,
            block: "RUN_LIMIT"
          } : n.requireTutorialComplete && !d ? {
            allowed: !1,
            block: "TUTORIAL_REQUIRED"
          } : r.firstNaturalRunCompleted || a >= n.minForegroundSecondsFirstSession ? n.requireFirstNaturalRunCompleted && !r.firstNaturalRunCompleted ? {
            allowed: !1,
            block: "FIRST_RUN_REQUIRED"
          } : this.pendingForRun(r.rewardedRevive, i.runId) ? {
            allowed: !1,
            block: "PENDING_ATTEMPT"
          } : {
            allowed: !0,
            block: null
          } : {
            allowed: !1,
            block: "FOREGROUND_REQUIRED"
          } : {
            allowed: !1,
            block: "NOT_SPILL_PENDING"
          } : {
            allowed: !1,
            block: "POLICY_DISABLED"
          };
        }, e.receiptFor = function (e, n) {
          return {
            attemptId: e.attemptId,
            runId: e.runId,
            failureId: e.failureId,
            rewardKind: "spill_revive",
            amount: 1,
            policyVersion: e.policyVersion,
            dayKey: e.dayKey,
            status: "COMMITTED",
            grantedAt: n
          };
        }, e.grant = function (e, n, t) {
          var r = e.receipts.find(function (e) {
            return e.attemptId === n.attemptId;
          });
          if (r) {
            if (r.runId !== n.runId || r.failureId !== n.failureId || r.rewardKind !== n.rewardKind || r.amount !== n.amount || r.policyVersion !== n.policyVersion || r.dayKey !== n.dayKey) throw new Error("REWARD_RECEIPT_CONFLICT");
            return e;
          }
          var i = this.prune([].concat(e.receipts, [n]), n.dayKey, t),
            a = this.grantedForDay(e, n.dayKey),
            d = a > e.receipts.filter(function (e) {
              return e.dayKey === n.dayKey;
            }).length ? a + 1 : i.filter(function (e) {
              return e.dayKey === n.dayKey;
            }).length,
            l = !!e.dayKey && e.dayKey > n.dayKey;
          return {
            dayKey: l ? e.dayKey : n.dayKey,
            dailyGranted: l ? e.dailyGranted : d,
            pendingAttempt: null,
            receipts: i
          };
        }, e.clearPending = function (e) {
          return n({}, e, {
            pendingAttempt: null
          });
        }, e.prune = function (e, n, t) {
          var r = new Date(n + "T00:00:00Z").getTime() - 5184e5;
          return e.filter(function (e) {
            return e.runId === t || new Date(e.dayKey + "T00:00:00Z").getTime() >= r;
          }).slice(-64);
        }, e;
      }()).EMPTY = {
        dayKey: null,
        dailyGranted: 0,
        pendingAttempt: null,
        receipts: []
      }, t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RewardedAdCoordinator.ts", ["cc"], function (t) {
  var e;
  return {
    setters: [function (t) {
      e = t.cclegacy;
    }],
    execute: function execute() {
      e._RF.push({}, "9e0a7xiUdRLip82jC0edKWw", "RewardedAdCoordinator", void 0), t("RewardedAdCoordinator", function () {
        function t() {}
        return t.claim = function (t) {
          return !this.active && (this.active = t, !0);
        }, t.release = function (t) {
          this.active === t && (this.active = null);
        }, t.busy = function () {
          return null !== this.active;
        }, t.current = function () {
          return this.active;
        }, t;
      }()).active = null, e._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RewardedAdPolicyLoader.ts", ["cc"], function (e) {
  var r;
  return {
    setters: [function (e) {
      r = e.cclegacy;
    }],
    execute: function execute() {
      r._RF.push({}, "af3076NZ4NJ06JQhIA/LqfO", "RewardedAdPolicyLoader", void 0);
      e("RewardedAdPolicyLoader", function () {
        function e() {}
        return e.validate = function (e) {
          try {
            if (!e || "object" != _typeof(e) || Array.isArray(e)) throw new Error("激励广告策略必须是对象");
            var r = e;
            if ("string" != typeof r.policyVersion || !r.policyVersion.trim()) throw new Error("policyVersion 缺失");
            if ("boolean" != typeof r.enabled) throw new Error("enabled 必须是 boolean");
            if (null !== r.adUnitId && ("string" != typeof r.adUnitId || !r.adUnitId.trim())) throw new Error("adUnitId 必须是 null 或非空字符串");
            if ("extra-shake" !== r.placement) throw new Error("placement 必须为 extra-shake");
            var o = function o(e, _o) {
                var a = r[e];
                if (!Number.isSafeInteger(a) || Number(a) < 0 || Number(a) > _o) throw new Error(e + " 必须是 0.." + _o + " 的整数");
                return Number(a);
              },
              a = o("maxExtraShakesPerRun", 5),
              t = o("maxDailyRewardedShakes", 5),
              n = o("minForegroundSecondsFirstSession", 600);
            if ("boolean" != typeof r.requireTutorialComplete || "boolean" != typeof r.requireFirstNaturalRunCompleted) throw new Error("资格开关必须是 boolean");
            if (a < 1) throw new Error("maxExtraShakesPerRun 至少为 1");
            if (t > 5) throw new Error("maxDailyRewardedShakes 不得超过每日 5 次");
            var i = {
              enabled: r.enabled,
              policyVersion: r.policyVersion,
              adUnitId: r.adUnitId,
              placement: "extra-shake",
              maxExtraShakesPerRun: a,
              maxDailyRewardedShakes: t,
              minForegroundSecondsFirstSession: n,
              requireTutorialComplete: r.requireTutorialComplete,
              requireFirstNaturalRunCompleted: r.requireFirstNaturalRunCompleted
            };
            return {
              ok: !0,
              data: Object.freeze(i)
            };
          } catch (e) {
            return {
              ok: !1,
              error: {
                code: "REWARD_POLICY_INVALID",
                message: e instanceof Error ? e.message : String(e),
                retryable: !1
              }
            };
          }
        }, e;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RewardedAdProviderFactory.ts", ["cc", "./TapRewardedAdProvider.ts"], function (e) {
  var r, n;
  return {
    setters: [function (e) {
      r = e.cclegacy;
    }, function (e) {
      n = e.TapRewardedAdProvider;
    }],
    execute: function execute() {
      e({
        createReviveAdEnvironment: function createReviveAdEnvironment(e) {
          return {
            provider: new n(e),
            policy: e
          };
        },
        createRewardedAdEnvironment: function createRewardedAdEnvironment(e) {
          return {
            provider: new n(e),
            policy: e
          };
        }
      }), r._RF.push({}, "f4ef87DbTlNw4zysVhouORa", "RewardedAdProviderFactory", void 0), r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RewardedShakeService.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./RewardLedger.ts", "./RewardedAdCoordinator.ts"], function (e) {
  var t, i, n, s, r, a;
  return {
    setters: [function (e) {
      t = e.createClass, i = e.asyncToGenerator, n = e["extends"];
    }, function (e) {
      s = e.cclegacy;
    }, function (e) {
      r = e.RewardLedger;
    }, function (e) {
      a = e.RewardedAdCoordinator;
    }],
    execute: function execute() {
      s._RF.push({}, "9f659ujAaJPc4/BnCI89N/p", "RewardedShakeService", void 0);
      var h = function h(e) {
        return JSON.parse(JSON.stringify(e));
      };
      e("RewardedShakeService", function () {
        function e(e, t, i) {
          this.phase = "IDLE", this.message = null, this.retrySettle = !1, this.busy = !1, this.stalePending = !1, this.pendingAttempt = null, this.trustedCompletionAttempt = null, this.foregroundSeconds = 0, this.host = null, this.boundRunId = null, this.hostGeneration = 0, this.clearingAttemptId = null, this.env = e, this.repo = t, this.now = i;
        }
        e.create = function (t, i, n) {
          void 0 === n && (n = function n() {
            return Date.now();
          });
          var s = new e(t, i, n),
            r = globalThis;
          return r.__milkteaRewardedShake ? (s.env.provider.dispose(), r.__milkteaRewardedShake) : (r.__milkteaRewardedShake = s, s);
        };
        var s = e.prototype;
        return s.bind = function (e) {
          var t,
            i,
            n,
            s,
            r = null != (t = null == (i = e.getActiveRunSnapshot()) ? void 0 : i.runId) ? t : null;
          (this.host !== e || this.boundRunId !== r) && (this.hostGeneration++, this.boundRunId = r, this.busy = !1, this.pendingAttempt = null, this.trustedCompletionAttempt = null, "PREPARING" !== this.phase && "SHOWING" !== this.phase && "SETTLING" !== this.phase || (this.phase = "IDLE", this.message = null, this.retrySettle = !1)), this.host = e;
          var a = null == (n = e.getBundle()) ? void 0 : n.profile.rewardedShake,
            h = e.getActiveRunSnapshot();
          this.stalePending = !(null == a || !a.pendingAttempt || !h || a.pendingAttempt.runId !== h.runId);
          var o,
            d,
            l = h ? null == a || null == (s = a.receipts) ? void 0 : s.find(function (e) {
              return e.runId === h.runId && "extra_shake" === e.rewardKind && 1 === e.amount;
            }) : void 0;
          this.stalePending && h && !l && (this.stalePending = !1, this.clearStalePending(e, {
            attemptId: null != (o = null == a || null == (d = a.pendingAttempt) ? void 0 : d.attemptId) ? o : null,
            runId: h.runId,
            revision: e.getSaveRevision(),
            generation: this.hostGeneration
          }));
          if (h && l) {
            var u,
              p = null == (u = e.getBundle()) ? void 0 : u.run;
            this.busy = !1, this.pendingAttempt = null, this.trustedCompletionAttempt = null, this.retrySettle = !1;
            var c = p && p.runId === h.runId ? p.shake.extraGranted - h.shake.extraGranted : 0;
            return c > 0 && !e.applyCommittedExtraGrant(c) ? (this.phase = "ERROR", this.retrySettle = !1, void (this.message = "奖励已保存，但本次恢复未完成；重新进入对局后自动生效。")) : (this.phase = "GRANTED", void (this.message = null));
          }
          this.busy || (this.phase = "IDLE", this.message = this.stalePending ? "上次广告奖励未得到可信完成确认，未发放。" : null, this.retrySettle = !1);
        }, s.unbind = function (e) {
          this.host === e && (this.host = null);
        }, s.releaseBusy = function (e, t) {
          this.host === e && this.hostGeneration === t && (this.busy = !1);
        }, s.setForegroundSeconds = function (e) {
          this.foregroundSeconds = Math.max(0, e);
        }, s.providerDisposed = function () {
          return !1;
        }, s.dispose = function () {
          this.env.provider.dispose();
        }, s.getView = function () {
          var e,
            t,
            i,
            n,
            s,
            a,
            h,
            o,
            d = null != (e = null == (t = this.host) ? void 0 : t.getBundle()) ? e : null,
            l = null != (i = null == (n = this.host) ? void 0 : n.getActiveRunSnapshot()) ? i : null,
            u = d && l ? r.checkOffer({
              policy: this.env.policy,
              capability: this.env.provider.capability(),
              profile: d.profile,
              run: l,
              foregroundSeconds: this.foregroundSeconds,
              tutorialComplete: null != (s = null == (a = this.host) ? void 0 : a.isTutorialComplete()) && s,
              nowMs: this.now()
            }) : {
              allowed: !1,
              block: "NO_ACTIVE_RUN"
            },
            p = null != (h = null == d ? void 0 : d.profile.rewardedShake) ? h : r.EMPTY,
            c = r.dayKey(this.now());
          return {
            phase: this.phase,
            block: this.stalePending ? "PENDING_ATTEMPT" : u.block,
            message: this.message,
            retrySettle: this.retrySettle,
            capability: this.env.provider.capability(),
            providerName: this.env.provider.providerName,
            availableExtra: void 0 !== (null == l ? void 0 : l.shake.extraGranted) ? Math.max(0, l.shake.extraGranted - l.shake.extraUsed) : 0,
            grantedThisRun: null != (o = null == l ? void 0 : l.shake.extraGranted) ? o : 0,
            runLimit: this.env.policy.maxExtraShakesPerRun,
            dailyRemaining: r.dailyRemaining(p, this.env.policy, c),
            pendingAttempt: this.stalePending || !(!p.pendingAttempt || !l || p.pendingAttempt.runId !== l.runId),
            simulated: "tap" !== this.env.provider.providerName
          };
        }, s.canOffer = function () {
          var e = this.getView();
          return "IDLE" === e.phase && null === e.block;
        }, s.openOffer = function () {
          if (this.host && !this.busy) {
            var e = this.check();
            if (!e.allowed) return this.message = this.blockMessage(e.block), void this.changed();
            this.phase = "OFFER", this.message = null, this.retrySettle = !1, this.host.pauseForRewardedAd(), this.changed();
          }
        }, s.closeOffer = function () {
          !this.host || "OFFER" !== this.phase && "ERROR" !== this.phase || (this.phase = "IDLE", this.message = null, this.retrySettle = !1, this.changed(), this.host.resumeFromRewardedAd(null));
        }, s.openPendingReview = function () {
          var e;
          if (this.host && !this.busy) {
            var t = null == (e = this.host.getBundle()) ? void 0 : e.profile.rewardedShake,
              i = this.host.getActiveRunSnapshot();
            null != t && t.pendingAttempt && i && t.pendingAttempt.runId === i.runId && (this.stalePending = !0, this.phase = "ERROR", this.retrySettle = !1, this.message = "上次广告奖励未得到可信完成确认，未发放。可放弃后重新观看。", this.host.pauseForRewardedAd(), this.changed());
          }
        }, s.watch = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee34() {
            var e, t, i, s, o, d, l, u, p, c, v, g, R, m, f, y, I, A;
            return _regeneratorRuntime().wrap(function _callee34$(_context35) {
              while (1) switch (_context35.prev = _context35.next) {
                case 0:
                  if (!(this.host && "OFFER" === this.phase && !this.busy)) {
                    _context35.next = 72;
                    break;
                  }
                  e = this.check();
                  if (e.allowed) {
                    _context35.next = 4;
                    break;
                  }
                  return _context35.abrupt("return", (this.message = this.blockMessage(e.block), void this.changed()));
                case 4:
                  t = this.host, i = this.hostGeneration, s = t.getBundle(), o = t.getActiveRunSnapshot();
                  if (!(!s || !o)) {
                    _context35.next = 7;
                    break;
                  }
                  return _context35.abrupt("return", (this.message = "当前局不可用", void this.changed()));
                case 7:
                  if (!("SUPPORTED" !== this.env.provider.capability())) {
                    _context35.next = 9;
                    break;
                  }
                  return _context35.abrupt("return", (this.message = this.blockMessage("AD_UNSUPPORTED"), this.phase = "ERROR", void this.changed()));
                case 9:
                  if (a.claim("extra-shake")) {
                    _context35.next = 11;
                    break;
                  }
                  return _context35.abrupt("return", (this.message = "另有广告正在进行，请稍后再试。", this.phase = "ERROR", void this.changed()));
                case 11:
                  this.busy = !0, this.phase = "PREPARING", this.message = null, this.changed();
                  _context35.prev = 12;
                  _context35.next = 15;
                  return this.host.waitForSaveIdle();
                case 15:
                  if (!(this.host !== t || i !== this.hostGeneration || (null == (d = t.getActiveRunSnapshot()) ? void 0 : d.runId) !== o.runId)) {
                    _context35.next = 17;
                    break;
                  }
                  throw new Error("REWARD_ATTEMPT_OWNER_CHANGED");
                case 17:
                  _context35.next = 19;
                  return this.repo.readBundle();
                case 19:
                  c = _context35.sent;
                  if (!(this.host !== t || i !== this.hostGeneration || (null == (l = t.getActiveRunSnapshot()) ? void 0 : l.runId) !== o.runId)) {
                    _context35.next = 22;
                    break;
                  }
                  throw new Error("REWARD_ATTEMPT_OWNER_CHANGED");
                case 22:
                  if (c.ok && c.data.envelope) {
                    g = c.data.envelope.payload;
                    g.profile.activeRunId === o.runId && (null == (v = g.run) ? void 0 : v.runId) === o.runId && c.data.envelope.revision !== t.getSaveRevision() && t.onRewardedShakeCommitted(g, c.data.envelope.revision);
                  }
                  if (!(s = t.getBundle(), o = t.getActiveRunSnapshot(), !s || !o)) {
                    _context35.next = 25;
                    break;
                  }
                  throw new Error("REWARD_ATTEMPT_RUN_MISSING");
                case 25:
                  R = function () {
                    var e = globalThis.crypto;
                    if (null != e && e.randomUUID) return e.randomUUID();
                    var t = new Uint8Array(16);
                    if (null != e && e.getRandomValues) e.getRandomValues(t);else for (var i = 0; i < t.length; i++) t[i] = Math.floor(256 * Math.random());
                    t[6] = 15 & t[6] | 64, t[8] = 63 & t[8] | 128;
                    var n = Array.from(t, function (e) {
                      return e.toString(16).padStart(2, "0");
                    }).join("");
                    return n.slice(0, 8) + "-" + n.slice(8, 12) + "-" + n.slice(12, 16) + "-" + n.slice(16, 20) + "-" + n.slice(20);
                  }(), m = {
                    attemptId: R,
                    runId: o.runId,
                    policyVersion: this.env.policy.policyVersion,
                    amount: 1,
                    dayKey: r.dayKey(this.now()),
                    startedAt: this.now()
                  }, f = h(s);
                  f.profile.rewardedShake = n({}, r.normalize(f.profile.rewardedShake, m.dayKey), {
                    pendingAttempt: m
                  });
                  _context35.next = 29;
                  return this.repo.commitBundle(t.getSaveRevision(), s.profile.activeRunId, f);
                case 29:
                  y = _context35.sent;
                  if (!(this.host !== t || i !== this.hostGeneration || (null == (u = t.getActiveRunSnapshot()) ? void 0 : u.runId) !== o.runId)) {
                    _context35.next = 32;
                    break;
                  }
                  throw new Error("REWARD_ATTEMPT_OWNER_CHANGED");
                case 32:
                  if (y.ok) {
                    _context35.next = 34;
                    break;
                  }
                  return _context35.abrupt("return", (this.busy = !1, this.phase = "ERROR", this.retrySettle = !1, this.message = "无法写入待确认的广告奖励，广告未展示。", void this.changed()));
                case 34:
                  t.onRewardedShakeCommitted(f, y.data.revision), this.pendingAttempt = R, this.trustedCompletionAttempt = null;
                  _context35.next = 37;
                  return this.env.provider.prepare();
                case 37:
                  I = _context35.sent;
                  if (!(this.host !== t || i !== this.hostGeneration)) {
                    _context35.next = 40;
                    break;
                  }
                  throw new Error("REWARD_ATTEMPT_OWNER_CHANGED");
                case 40:
                  if (I.ok) {
                    _context35.next = 46;
                    break;
                  }
                  _context35.next = 43;
                  return this.clearPending("广告暂时无法加载，未发放奖励。");
                case 43:
                  if (_context35.sent) {
                    _context35.next = 45;
                    break;
                  }
                  throw new Error("REWARD_PENDING_CLEAR_FAILED");
                case 45:
                  return _context35.abrupt("return", void this.releaseBusy(t, i));
                case 46:
                  this.phase = "SHOWING", this.changed();
                  _context35.next = 49;
                  return this.env.provider.show(R);
                case 49:
                  A = _context35.sent;
                  if (!(this.host !== t || i !== this.hostGeneration || (null == (p = t.getActiveRunSnapshot()) ? void 0 : p.runId) !== o.runId)) {
                    _context35.next = 52;
                    break;
                  }
                  return _context35.abrupt("return");
                case 52:
                  if (!("COMPLETED" !== A.kind)) {
                    _context35.next = 58;
                    break;
                  }
                  _context35.next = 55;
                  return this.clearPending("CANCELLED" === A.kind ? "观看未完成，未发放奖励。" : "广告播放失败，未发放奖励。");
                case 55:
                  if (_context35.sent) {
                    _context35.next = 57;
                    break;
                  }
                  throw new Error("REWARD_PENDING_CLEAR_FAILED");
                case 57:
                  return _context35.abrupt("return", void this.releaseBusy(t, i));
                case 58:
                  this.trustedCompletionAttempt = R;
                  this.phase = "SETTLING";
                  this.changed();
                  _context35.next = 63;
                  return this.settle(R);
                case 63:
                  this.releaseBusy(t, i);
                  _context35.next = 69;
                  break;
                case 66:
                  _context35.prev = 66;
                  _context35.t0 = _context35["catch"](12);
                  this.host === t && i === this.hostGeneration && (this.phase = "ERROR", this.retrySettle = !!this.pendingAttempt && this.trustedCompletionAttempt === this.pendingAttempt, this.message = "广告流程暂时未完成；存档保持待确认状态，可重试或返回游戏。", this.changed());
                case 69:
                  _context35.prev = 69;
                  this.host === t && i === this.hostGeneration && "SHOWING" !== this.phase && (this.busy = !1), a.release("extra-shake");
                  return _context35.finish(69);
                case 72:
                case "end":
                  return _context35.stop();
              }
            }, _callee34, this, [[12, 66, 69, 72]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), s.retrySettlement = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee35() {
            var e, t;
            return _regeneratorRuntime().wrap(function _callee35$(_context36) {
              while (1) switch (_context36.prev = _context36.next) {
                case 0:
                  if (!(this.host && !this.busy && this.pendingAttempt && this.trustedCompletionAttempt === this.pendingAttempt)) {
                    _context36.next = 16;
                    break;
                  }
                  e = this.host, t = this.hostGeneration;
                  this.busy = !0, this.phase = "SETTLING", this.message = null, this.changed();
                  _context36.prev = 3;
                  _context36.next = 6;
                  return this.settle(this.pendingAttempt);
                case 6:
                  _context36.next = 13;
                  break;
                case 8:
                  _context36.prev = 8;
                  _context36.t0 = _context36["catch"](3);
                  if (!(this.host !== e || t !== this.hostGeneration)) {
                    _context36.next = 12;
                    break;
                  }
                  return _context36.abrupt("return");
                case 12:
                  this.phase = "ERROR", this.retrySettle = !0, this.message = "奖励保存仍未完成，可稍后重试。", this.changed();
                case 13:
                  _context36.prev = 13;
                  this.releaseBusy(e, t);
                  return _context36.finish(13);
                case 16:
                case "end":
                  return _context36.stop();
              }
            }, _callee35, this, [[3, 8, 13, 16]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), s.abandonPending = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee36() {
            var e, t, i;
            return _regeneratorRuntime().wrap(function _callee36$(_context37) {
              while (1) switch (_context37.prev = _context37.next) {
                case 0:
                  if (!(this.host && !this.busy)) {
                    _context37.next = 10;
                    break;
                  }
                  e = this.host, t = this.hostGeneration;
                  this.busy = !0;
                  _context37.next = 5;
                  return this.clearPending("已放弃未确认的广告奖励。");
                case 5:
                  i = _context37.sent;
                  if (!(this.host === e && t === this.hostGeneration)) {
                    _context37.next = 10;
                    break;
                  }
                  if (i) {
                    _context37.next = 9;
                    break;
                  }
                  return _context37.abrupt("return", (this.busy = !1, this.phase = "ERROR", this.message = "放弃操作未能保存，请重试。", void this.changed()));
                case 9:
                  this.stalePending = !1, this.pendingAttempt = null, this.trustedCompletionAttempt = null, this.retrySettle = !1, this.phase = "IDLE", this.busy = !1, this.changed(), this.host.resumeFromRewardedAd("已放弃未确认的广告奖励。");
                case 10:
                case "end":
                  return _context37.stop();
              }
            }, _callee36, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), s.acknowledgeGrant = function () {
          this.host && "GRANTED" === this.phase && (this.phase = "IDLE", this.message = null, this.changed(), this.host.resumeFromRewardedAd(null));
        }, s.check = function () {
          var e,
            t,
            i,
            n,
            s,
            a,
            h = null != (e = null == (t = this.host) ? void 0 : t.getBundle()) ? e : null,
            o = null != (i = null == (n = this.host) ? void 0 : n.getActiveRunSnapshot()) ? i : null;
          return h && o ? r.checkOffer({
            policy: this.env.policy,
            capability: this.env.provider.capability(),
            profile: h.profile,
            run: o,
            foregroundSeconds: this.foregroundSeconds,
            tutorialComplete: null != (s = null == (a = this.host) ? void 0 : a.isTutorialComplete()) && s,
            nowMs: this.now()
          }) : {
            allowed: !1,
            block: "NO_ACTIVE_RUN"
          };
        }, s.clearStalePending = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee37(e, t) {
            var i, n, s, a, o, d, l;
            return _regeneratorRuntime().wrap(function _callee37$(_context38) {
              while (1) switch (_context38.prev = _context38.next) {
                case 0:
                  if (!(t.attemptId && this.clearingAttemptId !== t.attemptId)) {
                    _context38.next = 26;
                    break;
                  }
                  this.clearingAttemptId = t.attemptId;
                  _context38.prev = 2;
                  _context38.next = 5;
                  return this.repo.readBundle();
                case 5:
                  s = _context38.sent;
                  if (!(!s.ok || !s.data.envelope)) {
                    _context38.next = 8;
                    break;
                  }
                  return _context38.abrupt("return");
                case 8:
                  a = s.data.envelope.payload, o = null == (i = a.profile.rewardedShake) ? void 0 : i.pendingAttempt;
                  if (!(!o || o.attemptId !== t.attemptId || o.runId !== t.runId)) {
                    _context38.next = 11;
                    break;
                  }
                  return _context38.abrupt("return");
                case 11:
                  d = h(a);
                  d.profile.rewardedShake = r.clearPending(d.profile.rewardedShake);
                  _context38.next = 15;
                  return this.repo.commitBundle(s.data.envelope.revision, a.profile.activeRunId, d);
                case 15:
                  l = _context38.sent;
                  if (l.ok) {
                    _context38.next = 18;
                    break;
                  }
                  return _context38.abrupt("return");
                case 18:
                  this.host === e && this.hostGeneration === t.generation && (null == (n = e.getActiveRunSnapshot()) ? void 0 : n.runId) === t.runId && e.onRewardedShakeCommitted(d, l.data.revision);
                  _context38.next = 23;
                  break;
                case 21:
                  _context38.prev = 21;
                  _context38.t0 = _context38["catch"](2);
                case 23:
                  _context38.prev = 23;
                  this.clearingAttemptId === t.attemptId && (this.clearingAttemptId = null);
                  return _context38.finish(23);
                case 26:
                case "end":
                  return _context38.stop();
              }
            }, _callee37, this, [[2, 21, 23, 26]]);
          }));
          return function (t, i) {
            return e.apply(this, arguments);
          };
        }(), s.clearPending = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee38(e) {
            var t, i, n, s, a, o, d, l, u;
            return _regeneratorRuntime().wrap(function _callee38$(_context39) {
              while (1) switch (_context39.prev = _context39.next) {
                case 0:
                  n = this.host, s = this.hostGeneration;
                  if (n) {
                    _context39.next = 3;
                    break;
                  }
                  return _context39.abrupt("return", !1);
                case 3:
                  a = null != (t = null == (i = n.getActiveRunSnapshot()) ? void 0 : i.runId) ? t : null, o = n.getBundle();
                  if (!o) {
                    _context39.next = 21;
                    break;
                  }
                  u = h(o);
                  u.profile.rewardedShake = r.clearPending(u.profile.rewardedShake);
                  _context39.prev = 7;
                  _context39.next = 10;
                  return this.repo.commitBundle(n.getSaveRevision(), o.profile.activeRunId, u);
                case 10:
                  l = _context39.sent;
                  _context39.next = 16;
                  break;
                case 13:
                  _context39.prev = 13;
                  _context39.t0 = _context39["catch"](7);
                  return _context39.abrupt("return", !1);
                case 16:
                  if (!(this.host !== n || s !== this.hostGeneration || !l.ok)) {
                    _context39.next = 18;
                    break;
                  }
                  return _context39.abrupt("return", !1);
                case 18:
                  if (!(null !== a && (null == (d = n.getActiveRunSnapshot()) ? void 0 : d.runId) !== a)) {
                    _context39.next = 20;
                    break;
                  }
                  return _context39.abrupt("return", !1);
                case 20:
                  n.onRewardedShakeCommitted(u, l.data.revision);
                case 21:
                  return _context39.abrupt("return", (this.pendingAttempt = null, this.phase = "ERROR", this.retrySettle = !1, this.message = e, this.changed(), this.trustedCompletionAttempt = null, n.resumeFromRewardedAd(e), !0));
                case 22:
                case "end":
                  return _context39.stop();
              }
            }, _callee38, this, [[7, 13]]);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), s.settle = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee39(e) {
            var t, i, s, a, o, d, l, u, p, c, v, g, R, m, f, y, I, A, S, E, k;
            return _regeneratorRuntime().wrap(function _callee39$(_context40) {
              while (1) switch (_context40.prev = _context40.next) {
                case 0:
                  o = this.host, d = this.hostGeneration;
                  if (!o) {
                    _context40.next = 47;
                    break;
                  }
                  l = o.getBundle(), u = o.getActiveRunSnapshot();
                  _context40.t0 = l && u;
                  if (!_context40.t0) {
                    _context40.next = 8;
                    break;
                  }
                  _context40.next = 7;
                  return o.waitForSaveIdle();
                case 7:
                  _context40.t0 = this.host === o && d === this.hostGeneration && (null == (t = o.getActiveRunSnapshot()) ? void 0 : t.runId) === u.runId && (l = o.getBundle());
                case 8:
                  if (!_context40.t0) {
                    _context40.next = 47;
                    break;
                  }
                  p = l.profile.rewardedShake;
                  if (!r.hasReceipt(p, e)) {
                    _context40.next = 16;
                    break;
                  }
                  c = p.receipts.find(function (t) {
                    return t.attemptId === e;
                  }), v = l.run;
                  if (!(!c || c.runId !== u.runId || !v || v.runId !== u.runId || v.shake.extraGranted < u.shake.extraGranted)) {
                    _context40.next = 14;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "奖励凭证与当前局不匹配，未应用。", void this.changed()));
                case 14:
                  g = v.shake.extraGranted - u.shake.extraGranted;
                  return _context40.abrupt("return", g > 0 && !o.applyCommittedExtraGrant(g) ? (this.phase = "ERROR", this.retrySettle = !0, this.message = "奖励已保存，但本次恢复未完成，可重试领取。", void this.changed()) : (g > 0 && (this.pendingAttempt = null), this.phase = "GRANTED", this.message = null, this.retrySettle = !1, this.pendingAttempt = null, void this.changed()));
                case 16:
                  if (!((null == (i = p.pendingAttempt) ? void 0 : i.attemptId) !== e || p.pendingAttempt.runId !== u.runId)) {
                    _context40.next = 18;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "找不到本局待确认的广告奖励记录，未发放。", void this.changed()));
                case 18:
                  if (!(u.shake.extraGranted + 1 > this.env.policy.maxExtraShakesPerRun)) {
                    _context40.next = 20;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "本局奖励晃杯已达上限，未发放。", void this.changed()));
                case 20:
                  R = p.pendingAttempt, m = r.normalize(p, R.dayKey);
                  if (!(this.env.policy.maxDailyRewardedShakes - m.dailyGranted < 1)) {
                    _context40.next = 23;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "今日广告奖励已达上限，未发放。", void this.changed()));
                case 23:
                  f = r.grant(p, r.receiptFor(R, this.now()), u.runId), y = h(u);
                  y.shake = n({}, y.shake, {
                    extraGranted: y.shake.extraGranted + 1,
                    extraUsed: y.shake.extraUsed
                  }), y.revision += 1;
                  I = h(l);
                  I.profile.rewardedShake = f, I.run = y;
                  _context40.next = 29;
                  return this.repo.commitBundle(o.getSaveRevision(), u.runId, I);
                case 29:
                  A = _context40.sent;
                  if (!(this.host === o && d === this.hostGeneration && (null == (s = o.getActiveRunSnapshot()) ? void 0 : s.runId) === u.runId)) {
                    _context40.next = 47;
                    break;
                  }
                  if (A.ok) {
                    _context40.next = 33;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "广告已完成，但奖励保存失败；请在稍后重试领取。", void this.changed()));
                case 33:
                  _context40.next = 35;
                  return this.repo.readBundle();
                case 35:
                  S = _context40.sent;
                  if (!(this.host === o && d === this.hostGeneration)) {
                    _context40.next = 47;
                    break;
                  }
                  if (!(!S.ok || !S.data.envelope || !r.hasReceipt(S.data.envelope.payload.profile.rewardedShake, e))) {
                    _context40.next = 39;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "奖励已提交但回读未确认，可重试领取。", void this.changed()));
                case 39:
                  E = S.data.envelope.payload;
                  if (!((null == (a = E.run) ? void 0 : a.runId) !== u.runId || E.run.shake.extraGranted < u.shake.extraGranted + 1)) {
                    _context40.next = 42;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "奖励账本与本局额度未能一致回读，可重试领取。", void this.changed()));
                case 42:
                  o.onRewardedShakeCommitted(E, A.data.revision);
                  k = E.run.shake.extraGranted - u.shake.extraGranted;
                  if (!(k > 0 && !o.applyCommittedExtraGrant(k))) {
                    _context40.next = 46;
                    break;
                  }
                  return _context40.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "奖励已提交但未能应用到当前局，可重试领取。", void this.changed()));
                case 46:
                  this.pendingAttempt = null, this.stalePending = !1, this.phase = "GRANTED", this.message = null, this.retrySettle = !1, this.changed();
                case 47:
                case "end":
                  return _context40.stop();
              }
            }, _callee39, this);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), s.changed = function () {
          var e;
          null == (e = this.host) || e.onRewardedShakeChanged();
        }, s.blockMessage = function (e) {
          switch (e) {
            case "POLICY_DISABLED":
              return "广告奖励尚未开启";
            case "AD_UNCONFIGURED":
              return "未配置真实广告位";
            case "AD_UNSUPPORTED":
              return "当前环境不支持激励广告";
            case "NO_ACTIVE_RUN":
            case "NOT_PLAYING":
              return "当前局不可用";
            case "BASE_SHAKES_REMAINING":
              return "还有基础晃杯次数";
            case "RUN_LIMIT":
              return "本局奖励晃杯已达上限";
            case "DAILY_LIMIT":
              return "今日广告奖励已达上限";
            case "TUTORIAL_REQUIRED":
              return "完成教程后可观看广告";
            case "FIRST_RUN_REQUIRED":
              return "完成一局真实游戏后可观看广告";
            case "FOREGROUND_REQUIRED":
              return "游戏时间稍短，暂不可观看广告";
            case "PENDING_ATTEMPT":
              return "有未确认的广告奖励";
            default:
              return "暂不可观看广告";
          }
        }, t(e, [{
          key: "policy",
          get: function get() {
            return this.env.policy;
          }
        }]), e;
      }());
      s._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RewardLedger.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (e) {
  var t, n;
  return {
    setters: [function (e) {
      t = e["extends"];
    }, function (e) {
      n = e.cclegacy;
    }],
    execute: function execute() {
      n._RF.push({}, "bc8e8B7OXFBFawkFNqQ81kb", "RewardLedger", void 0), e("RewardLedger", function () {
        function e() {}
        return e.dayKey = function (e) {
          return new Date(e + 288e5).toISOString().slice(0, 10);
        }, e.normalize = function (e, n) {
          return e.dayKey === n ? e : t({}, e, {
            dayKey: n,
            dailyGranted: this.grantedForDay(e, n)
          });
        }, e.grantedForDay = function (e, t) {
          var n = e.receipts.filter(function (e) {
            return e.dayKey === t;
          }).length;
          return Math.max(e.dayKey === t ? e.dailyGranted : 0, n);
        }, e.dailyRemaining = function (e, t, n) {
          return Math.max(0, t.maxDailyRewardedShakes - this.grantedForDay(e, n));
        }, e.pendingForRun = function (e, t) {
          var n;
          return t && (null == (n = e.pendingAttempt) ? void 0 : n.runId) === t ? e.pendingAttempt : null;
        }, e.hasReceipt = function (e, t) {
          return e.receipts.some(function (e) {
            return e.attemptId === t;
          });
        }, e.checkOffer = function (e) {
          var t = e.policy,
            n = e.capability,
            r = e.profile,
            a = e.run,
            i = e.foregroundSeconds,
            d = e.tutorialComplete,
            l = e.nowMs;
          if (!t.enabled) return {
            allowed: !1,
            block: "POLICY_DISABLED"
          };
          if ("UNCONFIGURED" === n) return {
            allowed: !1,
            block: "AD_UNCONFIGURED"
          };
          if ("SUPPORTED" !== n) return {
            allowed: !1,
            block: "AD_UNSUPPORTED"
          };
          if (!a || "PLAYING" !== a.state && "PAUSED" !== a.state) return {
            allowed: !1,
            block: "NO_ACTIVE_RUN"
          };
          if (a.shake.baseUsed < 2) return {
            allowed: !1,
            block: "BASE_SHAKES_REMAINING"
          };
          if (a.shake.extraGranted >= t.maxExtraShakesPerRun) return {
            allowed: !1,
            block: "RUN_LIMIT"
          };
          var o = this.dayKey(l);
          return this.dailyRemaining(r.rewardedShake, t, o) < 1 ? {
            allowed: !1,
            block: "DAILY_LIMIT"
          } : t.requireTutorialComplete && !d ? {
            allowed: !1,
            block: "TUTORIAL_REQUIRED"
          } : r.firstNaturalRunCompleted || i >= t.minForegroundSecondsFirstSession ? t.requireFirstNaturalRunCompleted && !r.firstNaturalRunCompleted ? {
            allowed: !1,
            block: "FIRST_RUN_REQUIRED"
          } : this.pendingForRun(r.rewardedShake, a.runId) ? {
            allowed: !1,
            block: "PENDING_ATTEMPT"
          } : {
            allowed: !0,
            block: null
          } : {
            allowed: !1,
            block: "FOREGROUND_REQUIRED"
          };
        }, e.receiptFor = function (e, t) {
          return {
            attemptId: e.attemptId,
            runId: e.runId,
            rewardKind: "extra_shake",
            amount: 1,
            policyVersion: e.policyVersion,
            dayKey: e.dayKey,
            status: "COMMITTED",
            grantedAt: t
          };
        }, e.grant = function (e, t, n) {
          var r = e.receipts.find(function (e) {
            return e.attemptId === t.attemptId;
          });
          if (r) {
            if (r.runId !== t.runId || r.rewardKind !== t.rewardKind || r.amount !== t.amount || r.policyVersion !== t.policyVersion || r.dayKey !== t.dayKey) throw new Error("REWARD_RECEIPT_CONFLICT");
            return e;
          }
          var a = this.prune([].concat(e.receipts, [t]), t.dayKey, n),
            i = this.grantedForDay(e, t.dayKey),
            d = i > e.receipts.filter(function (e) {
              return e.dayKey === t.dayKey;
            }).length ? i + 1 : a.filter(function (e) {
              return e.dayKey === t.dayKey;
            }).length,
            l = !!e.dayKey && e.dayKey > t.dayKey;
          return {
            dayKey: l ? e.dayKey : t.dayKey,
            dailyGranted: l ? e.dailyGranted : d,
            pendingAttempt: null,
            receipts: a
          };
        }, e.clearPending = function (e) {
          return t({}, e, {
            pendingAttempt: null
          });
        }, e.prune = function (e, t, n) {
          var r = new Date(t + "T00:00:00Z").getTime() - 5184e5;
          return e.filter(function (e) {
            return e.runId === n || new Date(e.dayKey + "T00:00:00Z").getTime() >= r;
          }).slice(-64);
        }, e;
      }()).EMPTY = {
        dayKey: null,
        dailyGranted: 0,
        pendingAttempt: null,
        receipts: []
      }, n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RunEngine.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./CloneState.ts", "./RunRng.ts", "./SpawnRng.ts", "./EventIdentity.ts", "./Sha256.ts"], function (e) {
  var t, s, i, n, a, r, o, u, d;
  return {
    setters: [function (e) {
      t = e["extends"], s = e.createForOfIteratorHelperLoose, i = e.createClass;
    }, function (e) {
      n = e.cclegacy;
    }, function (e) {
      a = e.cloneState;
    }, function (e) {
      r = e.RunRng;
    }, function (e) {
      o = e.SpawnRng;
    }, function (e) {
      u = e.deterministicEventId;
    }, function (e) {
      d = e.sha256Utf8;
    }],
    execute: function execute() {
      n._RF.push({}, "376dcscl4dLYLW/kfsbUVek", "RunEngine", void 0);
      var c = Object.freeze({
          enabled: !1,
          clearanceDu: 0,
          autoDropDelayTicks: 0
        }),
        l = function l(e) {
          return {
            ok: !0,
            data: e
          };
        },
        h = function h(e, t, s) {
          return void 0 === s && (s = !1), {
            ok: !1,
            error: {
              code: e,
              message: t,
              retryable: s
            }
          };
        },
        p = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
      e("RunEngine", function () {
        function e(e, t, s, i, n, u) {
          var d, l, h, p;
          void 0 === u && (u = c), this.state = void 0, this.rng = void 0, this.spawnRng = void 0, this.pending = null, this.outcomes = new Map(), this.usedMergeEvents = new Set(), this.lastCommandOutcome = null, this.ended = !1, this.shakenAt = [], this._lastPhysicsMs = 0, this._lastLogicMs = 0, this._lastTickFault = null, this._recoveryCheckpoint = null, this.timingDiagnostics = !1, this.settleTicksRemaining = 0, this.adapter = e, this.rules = t, this.reviveOptions = u, this.rng = new r(i, null == n ? void 0 : n.rng.state, null != (d = null == n ? void 0 : n.rng.drawCount) ? d : 0), this.spawnRng = new o(i, null == n || null == (l = n.spawnRng) ? void 0 : l.state, null != (h = null == n || null == (p = n.spawnRng) ? void 0 : p.drawCount) ? h : 0);
          var v,
            g,
            f,
            I,
            y,
            m,
            D = null == n ? void 0 : n.currentLevel;
          (this.state = n ? a(n) : {
            saveSchemaVersion: 5,
            rulesVersion: t.design_rules_version,
            appVersion: "0.1.0",
            runId: s,
            epoch: 1,
            revision: 0,
            stageId: "classic",
            mode: "classic",
            boardType: "standard",
            state: "PLAYING",
            tick: 0,
            nextEntityId: 1,
            nextCommandSequence: 1,
            score: 0,
            maxLevel: 1,
            dropIndex: 0,
            currentLevel: this.rng.nextLevel(t.drop.spawn_levels),
            nextLevel: this.rng.nextLevel(t.drop.spawn_levels),
            lastDropTick: null,
            settleStartedTick: null,
            challenge: null,
            rng: this.rng.snapshot(),
            ingredients: [],
            shake: {
              baseUsed: 0,
              extraGranted: 0,
              extraUsed: 0,
              activeStartTick: null,
              cooldownUntilTick: 0
            },
            spawnRng: this.spawnRng.snapshot(),
            dangerTicks: 0,
            terminalReason: null,
            cupMotion: {
              offsetXDu: 0,
              velocityXDuPerSecond: 0,
              targetOffsetXDu: 0,
              control: "IDLE"
            },
            autoDrop: {
              nextDueTick: t.auto_drop.interval_ticks,
              pendingSpawn: {
                level: null != D ? D : 1,
                xDu: t.cup.center_x_du,
                vxDuPerSecond: 0,
                angularVelocity: 0
              }
            },
            revive: {
              used: 0,
              pendingFailure: null,
              committedReceiptId: null
            },
            checksum: ""
          }, n || (this.state.autoDrop.pendingSpawn = this.nextSpawn(this.state.currentLevel)), n) && (this.rng = new r(i, n.rng.state, n.rng.drawCount), this.adapter.createCup(n.stageId, null != (v = null == (g = n.cupMotion) ? void 0 : g.offsetXDu) ? v : 0), this.adapter.restoreBodies(n.ingredients), this.state.state = "PAUSED", this.state.cupMotion = {
            offsetXDu: null != (f = null == (I = n.cupMotion) ? void 0 : I.offsetXDu) ? f : 0,
            velocityXDuPerSecond: 0,
            targetOffsetXDu: null != (y = null == (m = n.cupMotion) ? void 0 : m.offsetXDu) ? y : 0,
            control: "IDLE"
          }, this.state.epoch++);
        }
        var n = e.prototype;
        return n.projectRevive = function (e) {
          var s = this.state.revive.pendingFailure;
          if (!s) return h("NO_SPILL_PENDING", "当前没有待处理的洒出复活");
          if (!p.test(e)) return h("INVALID_RECEIPT", "复活奖励凭证无效");
          if (0 !== this.state.revive.used) return h("REVIVE_ALREADY_USED", "本局复活次数已用完");
          var i = this.computeSpillCandidate(s.detectedTick, s.spilledEntityIds);
          if (i.candidateHash !== s.candidateHash) return h("REVIVE_CANDIDATE_MISMATCH", "复活候选与冻结现场不一致");
          if (0 === i.ingredients.length) return h("REVIVE_EMPTY", "清理后杯中没有可继续的小料");
          var n = a(this.state);
          return n.ingredients = i.ingredients, n.score = i.score, n.maxLevel = i.maxLevel, n.dropIndex = i.dropIndex, n.currentLevel = i.currentLevel, n.nextLevel = i.nextLevel, n.nextEntityId = i.nextEntityId, n.dangerTicks = i.dangerTicks, n.shake = t({}, i.shake), n.cupMotion = {
            offsetXDu: 0,
            velocityXDuPerSecond: 0,
            targetOffsetXDu: 0,
            control: "IDLE"
          }, n.autoDrop = {
            nextDueTick: n.tick + Math.max(0, this.reviveOptions.autoDropDelayTicks),
            pendingSpawn: t({}, i.autoDrop.pendingSpawn)
          }, n.revive = {
            used: 1,
            pendingFailure: null,
            committedReceiptId: e
          }, n.boardType = "assisted", n.state = "PAUSED", n.terminalReason = null, n.rng = this.rng.snapshot(), n.spawnRng = this.spawnRng.snapshot(), n.revision += 1, n.epoch += 1, n.checksum = "", l(n);
        }, n.spillCandidate = function () {
          var e = this.state.revive.pendingFailure;
          return e ? this.computeSpillCandidate(e.detectedTick, e.spilledEntityIds) : null;
        }, n.applyRevive = function (e) {
          var i = this.state.revive.pendingFailure;
          if (!i) return h("NO_SPILL_PENDING", "当前没有待处理的洒出复活");
          if ("PAUSED" !== this.state.state || this.ended) return h("INVALID_PHASE", "当前局不接受复活");
          if (0 !== this.state.revive.used) return h("REVIVE_ALREADY_USED", "本局复活次数已用完");
          if ("string" != typeof e || !p.test(e)) return h("INVALID_RECEIPT", "复活奖励凭证无效");
          var n = this.computeSpillCandidate(i.detectedTick, i.spilledEntityIds);
          if (n.candidateHash !== i.candidateHash) return h("REVIVE_CANDIDATE_MISMATCH", "复活候选与冻结现场不一致");
          if (0 === n.ingredients.length) return h("REVIVE_EMPTY", "清理后杯中没有可继续的小料");
          for (var a, r = s(n.removedEntityIds); !(a = r()).done;) {
            var o = a.value;
            try {
              this.adapter.getBody(o) && this.adapter.destroyBody(o);
            } catch (e) {}
          }
          return this.adapter.createCup(this.state.stageId, n.cupOffsetXDu), this.adapter.setCupVelocityX(0), this.adapter.restoreBodies(n.ingredients), this.state.ingredients = n.ingredients, this.state.score = n.score, this.state.maxLevel = n.maxLevel, this.state.dropIndex = n.dropIndex, this.state.currentLevel = n.currentLevel, this.state.nextLevel = n.nextLevel, this.state.nextEntityId = n.nextEntityId, this.state.dangerTicks = n.dangerTicks, this.state.shake = t({}, n.shake), this.state.cupMotion = {
            offsetXDu: n.cupOffsetXDu,
            velocityXDuPerSecond: 0,
            targetOffsetXDu: n.cupOffsetXDu,
            control: "IDLE"
          }, this.state.autoDrop = {
            nextDueTick: this.state.tick + Math.max(0, this.reviveOptions.autoDropDelayTicks),
            pendingSpawn: t({}, n.autoDrop.pendingSpawn)
          }, this.state.revive = {
            used: 1,
            pendingFailure: null,
            committedReceiptId: e
          }, this.state.boardType = "assisted", this.state.state = "PAUSED", this.state.terminalReason = null, this.state.epoch++, this.state.revision++, this.shakenAt = [], this._recoveryCheckpoint = null, l(void 0);
        }, n.declineRevive = function () {
          return this.state.revive.pendingFailure ? (this.state.revive.pendingFailure = null, this.end("SPILLED", this.state.tick)) : null;
        }, n.setTimingDiagnostics = function (e) {
          this.timingDiagnostics = e;
        }, n.setCupTarget = function (e) {
          if ("PLAYING" === this.state.state && Number.isFinite(e)) {
            var t = this.rules.cup_motion.max_offset_du;
            this.state.cupMotion.targetOffsetXDu = Math.max(-t, Math.min(t, e)), this.state.cupMotion.control = "DRAGGING";
          }
        }, n.releaseCup = function () {
          "DRAGGING" === this.state.cupMotion.control && (this.state.cupMotion.control = "SETTLING", this.settleTicksRemaining = this.rules.cup_motion.settle_max_ticks);
        }, n.extraShakesAvailable = function () {
          return Math.max(0, this.state.shake.extraGranted - this.state.shake.extraUsed);
        }, n.projectExtraGrant = function (e) {
          var s = this.snapshot();
          return s.shake = t({}, s.shake, {
            extraGranted: s.shake.extraGranted + e
          }), s.revision += 1, s;
        }, n.commitExtraGrant = function (e) {
          return !Number.isSafeInteger(e) || e <= 0 || e > 5 ? h("INVALID_GRANT", "奖励晃杯授予数量无效") : "PLAYING" !== this.state.state && "PAUSED" !== this.state.state ? h("INVALID_PHASE", "当前局不接受奖励晃杯") : (this.state.shake.extraGranted += e, this.state.revision++, l(void 0));
        }, n.cancelCupInput = function (e) {
          this.state.cupMotion.control = "IDLE", this.settleTicksRemaining = 0, this.state.cupMotion.velocityXDuPerSecond = 0, this.state.cupMotion.targetOffsetXDu = this.adapter.getCupOffsetX(), this.adapter.setCupVelocityX(0);
        }, n.renderStates = function () {
          return this.refreshPhysicalStates(), this.state.ingredients;
        }, n.dispatch = function (e) {
          var t, s;
          if (!e || "object" != _typeof(e) || !e.command || "object" != _typeof(e.command) || !Number.isSafeInteger(e.ownerEpoch) || Object.keys(e).some(function (e) {
            return "command" !== e && "ownerEpoch" !== e;
          })) return h("INVALID_COMMAND", "命令信封字段无效");
          var i = e.command;
          if (!i || "object" != _typeof(i)) return h("INVALID_COMMAND", "命令结构无效");
          if ("string" != typeof i.commandId || "string" != typeof i.runId || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(i.commandId) || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(i.runId)) return h("INVALID_UUID", "局ID和命令ID必须是合法UUID");
          if ("DROP" !== i.kind && "SHAKE" !== i.kind) return h("CONTROL_ROUTE_REQUIRED", "暂停、继续和放弃必须经会话控制边界");
          var n = "DROP" === i.kind ? ["kind", "runId", "commandId", "sequence", "tick", "xDu"] : ["kind", "runId", "commandId", "sequence", "tick", "source"];
          if (Object.keys(i).some(function (e) {
            return !n.includes(e);
          }) || n.some(function (e) {
            return !(e in i);
          })) return h("INVALID_COMMAND", "玩法命令字段不符合其类型");
          if ("DROP" === i.kind) return h("MANUAL_DROP_DISABLED", "新版规则只按固定步自动落料");
          if ("SHAKE" === i.kind && "base" !== i.source && "rewarded_ad" !== i.source) return h("INVALID_COMMAND", "当前玩法只接受基础晃杯或广告奖励晃杯命令");
          if ("PLAYING" !== this.state.state || this.ended) return h("INVALID_PHASE", "当前局不接受玩法命令");
          var a = this.outcomes.get(i.commandId);
          if (a) return "APPLIED" === a.status ? l({
            accepted: !0,
            sequence: a.sequence
          }) : h(null != (t = a.errorCode) ? t : "COMMAND_REPLAY", null != (s = a.message) ? s : "此命令已处理");
          if (i.runId !== this.state.runId || e.ownerEpoch !== this.state.epoch) return h("STALE_OWNER", "局或恢复代次已变化");
          if (!Number.isSafeInteger(i.sequence) || i.sequence !== this.state.nextCommandSequence) return h("SEQUENCE_CONFLICT", "命令序号冲突");
          var r = this.state.tick + 1;
          return Number.isSafeInteger(i.tick) && i.tick === r ? this.pending ? h("INPUT_BUSY", "上一条操作尚未确认", !0) : (this.pending = {
            envelope: e,
            dispatchedAt: this.state.tick
          }, l({
            accepted: !0,
            sequence: i.sequence
          })) : h("TARGET_TICK_CONFLICT", "玩法命令目标必须是下一逻辑步");
        }, n.advanceOneTick = function () {
          if ("PLAYING" !== this.state.state || this.ended) return [];
          var e = this.timingDiagnostics ? performance.now() : 0,
            i = this.snapshot(),
            n = this.pending ? a(this.pending) : null,
            d = new Map(this.outcomes),
            c = new Set(this.usedMergeEvents),
            l = this.lastCommandOutcome ? t({}, this.lastCommandOutcome) : null,
            h = [],
            p = this.state.tick + 1;
          if (!Number.isSafeInteger(p)) throw new Error("RUN_TICK_OVERFLOW");
          try {
            this.advanceCupMotion(), this.pending && this.consumePending(p, h), this.applyShake(p), this.tryAutomaticDrop(p, h);
            var v = this.timingDiagnostics ? performance.now() : 0;
            this.adapter.stepFixed();
            var g = this.adapter.lastStepTimings;
            this._lastPhysicsMs = this.timingDiagnostics ? g ? g.syncToPhysics + g.physicsStep + g.syncFromPhysics + g.velocityClamp : performance.now() - v : 0, this.refreshPhysicalStates();
            var f = this.rules.cup_motion.max_offset_du;
            this.state.cupMotion.offsetXDu = Math.max(-f, Math.min(f, this.adapter.getCupOffsetX()));
            for (var I, y = this.adapter.getContacts(), m = s(y); !(I = m()).done;) {
              var D = I.value;
              this.markEligible(D.firstId), null !== D.secondId && this.markEligible(D.secondId);
            }
            this.resolveMerges(p, y, h);
            var _ = this.updateDanger(p, h),
              x = this.updateSpill(p);
            return x.length ? this.beginSpillPending(p, x) ? h.push({
              kind: "SpillReviveOffered",
              eventId: u(this.state.runId, "SpillReviveOffered", p, x),
              runId: this.state.runId,
              tick: p,
              failureId: this.state.revive.pendingFailure.failureId,
              candidateHash: this.state.revive.pendingFailure.candidateHash
            }) : h.push(this.end("SPILLED", p)) : _ && h.push(this.end("CUP_FULL", p)), this.state.tick = p, this.state.rng = this.rng.snapshot(), this.state.revision++, this.assertInvariants(), this._lastLogicMs = this.timingDiagnostics ? Math.max(0, performance.now() - e - this._lastPhysicsMs) : 0, this._lastTickFault = null, h;
          } catch (t) {
            this._recoveryCheckpoint = a(i), this.spawnRng = new o(i.spawnRng.state, i.spawnRng.state, i.spawnRng.drawCount);
            var k = t instanceof Error ? t.name + ":" + t.message : String(t),
              E = null;
            try {
              this.adapter.createCup(i.stageId, i.cupMotion.offsetXDu), this.adapter.setCupVelocityX(i.cupMotion.velocityXDuPerSecond), this.adapter.restoreBodies(i.ingredients);
            } catch (e) {
              E = e instanceof Error ? e.name + ":" + e.message : String(e);
            }
            this.state = i, this.rng = new r(i.rng.state, i.rng.state, i.rng.drawCount), this.pending = n, this.outcomes.clear();
            for (var S, M = s(d); !(S = M()).done;) {
              var L = S.value,
                T = L[0],
                R = L[1];
              this.outcomes.set(T, R);
            }
            this.usedMergeEvents.clear();
            for (var A, C = s(c); !(A = C()).done;) {
              var P = A.value;
              this.usedMergeEvents.add(P);
            }
            return this.lastCommandOutcome = l, this._lastTickFault = E ? k + "|ROLLBACK:" + E : k, this.pending && (this.pending = null, this.state.nextCommandSequence++), this.state.state = "PAUSED", this.state.terminalReason = null, this._lastLogicMs = this.timingDiagnostics ? Math.max(0, performance.now() - e - this._lastPhysicsMs) : 0, [];
          }
        }, n.pause = function (e) {
          this.cancelPending("PAUSED_BEFORE_APPLY"), "PLAYING" === this.state.state && (this.state.state = "PAUSED"), "TECHNICAL_ERROR" === e && (this.state.state = "PAUSED", this.state.terminalReason = null);
        }, n.resume = function () {
          if ("PAUSED" !== this.state.state) return h("INVALID_PHASE", "当前不能继续");
          this.state.state = "PLAYING", this.state.epoch++, this.state.revision++, this.state.cupMotion.velocityXDuPerSecond = 0, this.state.cupMotion.targetOffsetXDu = this.state.cupMotion.offsetXDu, this.state.cupMotion.control = "IDLE", this.adapter.setCupVelocityX(0);
          var e = Math.max(this.rules.auto_drop.resume_delay_ticks, this.state.autoDrop.nextDueTick - this.state.tick);
          return this.state.autoDrop.nextDueTick = this.state.tick + e, l(void 0);
        }, n.abandon = function () {
          return this.ended || !["PLAYING", "PAUSED"].includes(this.state.state) ? null : (this.cancelPending("RUN_ABANDONED"), this.end("ABANDONED", this.state.tick));
        }, n.snapshot = function () {
          return this.refreshPhysicalStates(), this.state.rng = this.rng.snapshot(), this.state.spawnRng = this.spawnRng.snapshot(), a(t({}, this.state, {
            ingredients: this.state.ingredients.slice().sort(function (e, t) {
              return e.entityId - t.entityId;
            })
          }));
        }, n.restore = function (e) {
          var t = this.validateSnapshot(e);
          return t.ok ? (this.adapter.createCup(e.stageId, e.cupMotion.offsetXDu), this.adapter.setCupVelocityX(0), this.adapter.restoreBodies(e.ingredients), this.state = a(e), this.state.state = "PAUSED", this.state.cupMotion = {
            offsetXDu: e.cupMotion.offsetXDu,
            velocityXDuPerSecond: 0,
            targetOffsetXDu: e.cupMotion.offsetXDu,
            control: "IDLE"
          }, this.state.epoch++, this.rng = new r(e.rng.state, e.rng.state, e.rng.drawCount), this.spawnRng = new o(e.spawnRng.state, e.spawnRng.state, e.spawnRng.drawCount), this.ended = !!e.terminalReason, this.pending = null, l(void 0)) : t;
        }, n.dispose = function () {
          this.pending = null, this.adapter.dispose();
        }, n.consumePending = function (e, t) {
          var s = this,
            i = this.pending;
          this.pending = null;
          var n,
            a,
            r = i.envelope.command,
            o = "REJECTED";
          if (r.runId !== this.state.runId || i.envelope.ownerEpoch !== this.state.epoch) n = "STALE_OWNER", a = "旧局命令已取消", o = "CANCELLED";else if (r.sequence !== this.state.nextCommandSequence) n = "SEQUENCE_CONFLICT", a = "命令序号不匹配";else if ("DROP" === r.kind) {
            var d = Math.round(.45 * this.rules.physics.fixed_hz),
              c = null !== this.state.shake.activeStartTick && e < this.state.shake.activeStartTick + 48,
              l = this.clampSpawnX(this.state.currentLevel, r.xDu);
            if (null !== this.state.lastDropTick && e - this.state.lastDropTick < d) n = "COOLDOWN", a = "投放间隔未到";else if (c) n = "SHAKE_ACTIVE", a = "晃杯期间不能投放";else if (this.adapter.canSpawn(this.state.currentLevel, l)) {
              var h = this.state.nextEntityId,
                p = this.rules.ingredients.find(function (e) {
                  return e.level === s.state.currentLevel;
                });
              try {
                this.adapter.createBody({
                  entityId: h,
                  level: p.level,
                  radiusDu: p.radius_du,
                  positionDu: {
                    x: l,
                    y: this.rules.cup.spawn_y_du
                  },
                  velocityDuPerSecond: {
                    x: 0,
                    y: 0
                  }
                }), this.state.ingredients.push({
                  entityId: h,
                  level: p.level,
                  positionDu: {
                    x: l,
                    y: this.rules.cup.spawn_y_du
                  },
                  velocityDuPerSecond: {
                    x: 0,
                    y: 0
                  },
                  angleRadians: 0,
                  angularVelocity: 0,
                  bornTick: e,
                  dangerEligible: !1,
                  hasEnteredCup: !1,
                  spillTicks: 0,
                  sleeping: !1
                }), this.state.nextEntityId++, this.state.dropIndex++, this.state.lastDropTick = e, this.state.maxLevel = Math.max(this.state.maxLevel, p.level), this.state.currentLevel = this.state.nextLevel, this.state.nextLevel = this.rng.nextLevel(this.rules.drop.spawn_levels), this.state.autoDrop.pendingSpawn = this.nextSpawn(this.state.currentLevel), this.state.spawnRng = this.spawnRng.snapshot();
                var v = {
                  kind: "IngredientDropped",
                  eventId: u(this.state.runId, "IngredientDropped", e, [h]),
                  runId: this.state.runId,
                  tick: e,
                  entityId: h,
                  level: p.level,
                  dropIndex: this.state.dropIndex
                };
                t.push(v), o = "APPLIED";
              } catch (e) {
                try {
                  this.adapter.getBody(h) && this.adapter.destroyBody(h);
                } catch (e) {}
                n = "PHYSICS_CREATE_FAILED", a = String(e);
              }
            } else n = "SPAWN_BLOCKED", a = "杯口被挡住，可移动或晃杯";
          } else if ("SHAKE" === r.kind) {
            var g = Math.round(this.rules.shake.duration_seconds * this.rules.physics.fixed_hz),
              f = null !== this.state.shake.activeStartTick && e < this.state.shake.activeStartTick + g,
              I = this.state.shake.extraGranted - this.state.shake.extraUsed;
            0 === this.state.ingredients.length ? (n = "SHAKE_EMPTY", a = "杯中还没有小料") : "base" === r.source && this.state.shake.baseUsed >= 2 ? (n = "NO_BASE_SHAKES", a = "本局基础晃杯次数已用完") : "rewarded_ad" === r.source && I < 1 ? (n = "NO_EXTRA_SHAKES", a = "本局奖励晃杯次数已用完") : f || e < this.state.shake.cooldownUntilTick ? (n = "SHAKE_COOLDOWN", a = "晃杯正在进行或冷却中") : ("base" === r.source ? this.state.shake.baseUsed++ : (this.state.shake.extraUsed++, this.state.boardType = "assisted"), this.state.shake.activeStartTick = e, this.state.shake.cooldownUntilTick = e + Math.round((this.rules.shake.duration_seconds + this.rules.shake.cooldown_seconds) * this.rules.physics.fixed_hz), t.push({
              kind: "ShakeConsumed",
              eventId: u(this.state.runId, "ShakeConsumed", e, [r.sequence]),
              runId: this.state.runId,
              tick: e,
              source: r.source
            }), o = "APPLIED");
          } else n = "CONTROL_COMMAND_REQUIRES_SESSION", a = "控制命令必须由运行会话在控制边界处理";
          this.state.nextCommandSequence++, this.lastCommandOutcome = {
            commandId: r.commandId,
            sequence: r.sequence,
            status: o,
            appliedTick: e,
            errorCode: n,
            message: a
          }, this.outcomes.set(r.commandId, this.lastCommandOutcome), this.outcomes.size > 256 && this.outcomes["delete"](this.outcomes.keys().next().value);
        }, n.cancelPending = function (e) {
          var t = this.pending;
          if (t) {
            this.pending = null;
            var s = t.envelope.command,
              i = {
                commandId: s.commandId,
                sequence: s.sequence,
                status: "CANCELLED",
                appliedTick: this.state.tick,
                errorCode: e,
                message: "玩法命令在暂停/结束边界前取消"
              };
            s.sequence === this.state.nextCommandSequence && this.state.nextCommandSequence++, this.lastCommandOutcome = i, this.outcomes.set(s.commandId, i), this.outcomes.size > 256 && this.outcomes["delete"](this.outcomes.keys().next().value), this.state.revision++;
          }
        }, n.applyShake = function (e) {
          var t = this,
            i = this.state.shake.activeStartTick,
            n = Math.round(this.rules.shake.duration_seconds * this.rules.physics.fixed_hz);
          if (!(null === i || e < i || e >= i + n)) for (var a, r = this.rules.shake, o = (e - i) / this.rules.physics.fixed_hz, u = r.acceleration_amplitude * Math.pow(Math.sin(Math.PI * o / r.duration_seconds), 2) * Math.sin(2 * Math.PI * r.frequency_hz * o), d = this.rules.cup, c = d.center_x_du + this.state.cupMotion.offsetXDu, l = function l() {
              var e,
                s,
                i = a.value,
                n = null != (e = null == (s = t.rules.ingredients.find(function (e) {
                  return e.level === i.level;
                })) ? void 0 : s.radius_du) ? e : 0;
              i.hasEnteredCup && i.positionDu.y <= d.inner_top_y_du + n && i.positionDu.y >= d.inner_bottom_y_du - n && Math.abs(i.positionDu.x - c) <= d.top_width_du / 2 + n && t.adapter.applyHorizontalAcceleration(i.entityId, u);
            }, h = s(this.state.ingredients); !(a = h()).done;) l();
        }, n.advanceCupMotion = function () {
          var e = this.state.cupMotion,
            t = 1 / this.rules.physics.fixed_hz,
            s = this.rules.cup_motion,
            i = s.acceleration_du_per_second2,
            n = s.max_speed_du_per_second,
            a = this.adapter.getCupOffsetX(),
            r = e.targetOffsetXDu - a;
          if ("DRAGGING" === e.control || "SETTLING" === e.control) {
            var o = Math.max(-n, Math.min(n, r / Math.max(.001, s.response_seconds))),
              u = e.velocityXDuPerSecond + Math.max(-i * t, Math.min(i * t, o - e.velocityXDuPerSecond));
            u = Math.max(-n, Math.min(n, u)), Math.sign(u) === Math.sign(r) && Math.abs(u * t) > Math.abs(r) && (u = r / t), Math.abs(r) <= s.snap_epsilon_du && (u = r / t, e.control = "IDLE", this.settleTicksRemaining = 0), e.velocityXDuPerSecond = u, "SETTLING" === e.control && --this.settleTicksRemaining <= 0 && (e.targetOffsetXDu = a + u * t, e.control = "IDLE");
          } else e.velocityXDuPerSecond = 0;
          var d = this.rules.cup_motion.max_offset_du,
            c = a + e.velocityXDuPerSecond * t;
          c > d ? e.velocityXDuPerSecond = Math.max(0, (d - a) / t) : c < -d && (e.velocityXDuPerSecond = Math.min(0, (-d - a) / t)), this.adapter.setCupVelocityX(e.velocityXDuPerSecond);
        }, n.tryAutomaticDrop = function (e, t) {
          var s = this.state.autoDrop;
          if (!(e < s.nextDueTick)) {
            var i = null !== this.state.shake.activeStartTick && e < this.state.shake.activeStartTick + Math.round(this.rules.shake.duration_seconds * this.rules.physics.fixed_hz),
              n = s.pendingSpawn;
            if (!i && this.adapter.canSpawn(n.level, n.xDu)) {
              var a = n.level,
                r = this.rules.ingredients.find(function (e) {
                  return e.level === a;
                }),
                o = this.state.nextEntityId,
                d = n.xDu,
                c = this.rules.cup.spawn_y_du;
              this.adapter.createBody({
                entityId: o,
                level: a,
                radiusDu: r.radius_du,
                positionDu: {
                  x: d,
                  y: c
                },
                velocityDuPerSecond: {
                  x: n.vxDuPerSecond,
                  y: 0
                },
                angularVelocity: n.angularVelocity
              }), this.state.ingredients.push({
                entityId: o,
                level: a,
                positionDu: {
                  x: d,
                  y: c
                },
                velocityDuPerSecond: {
                  x: n.vxDuPerSecond,
                  y: 0
                },
                angleRadians: 0,
                angularVelocity: n.angularVelocity,
                bornTick: e,
                dangerEligible: !1,
                hasEnteredCup: !1,
                spillTicks: 0,
                sleeping: !1
              }), this.state.nextEntityId++, this.state.dropIndex++, this.state.lastDropTick = e, this.state.maxLevel = Math.max(this.state.maxLevel, r.level), this.state.currentLevel = this.state.nextLevel, this.state.nextLevel = this.rng.nextLevel(this.rules.drop.spawn_levels), s.nextDueTick = e + this.rules.auto_drop.interval_ticks, s.pendingSpawn = this.nextSpawn(this.state.currentLevel), this.state.spawnRng = this.spawnRng.snapshot(), t.push({
                kind: "IngredientDropped",
                eventId: u(this.state.runId, "IngredientDropped", e, [o]),
                runId: this.state.runId,
                tick: e,
                entityId: o,
                level: a,
                dropIndex: this.state.dropIndex
              });
            } else s.nextDueTick = e + this.rules.auto_drop.blocked_retry_ticks;
          }
        }, n.nextSpawn = function (e) {
          var t = this.rules.spawn_jitter.x_offsets_du,
            s = this.rules.spawn_jitter.vx_du_per_second;
          return {
            level: e,
            xDu: this.rules.cup.center_x_du + t[this.spawnRng.nextIndex(t.length)],
            vxDuPerSecond: s[this.spawnRng.nextIndex(s.length)],
            angularVelocity: 0
          };
        }, n.refreshPhysicalStates = function () {
          for (var e, t = s(this.state.ingredients); !(e = t()).done;) {
            var i = e.value,
              n = this.adapter.getBody(i.entityId);
            n && Object.assign(i, n);
          }
        }, n.markEligible = function (e) {
          var t = this.state.ingredients.find(function (t) {
            return t.entityId === e;
          });
          t && (t.dangerEligible = !0);
        }, n.resolveMerges = function (e, t, i) {
          for (var n, a = this, r = new Map(this.state.ingredients.map(function (e) {
              return [e.entityId, e];
            })), o = new Map(), d = s(t); !(n = d()).done;) {
            var c = n.value;
            if (null !== c.secondId && c.firstId !== c.secondId) {
              var l = Math.min(c.firstId, c.secondId),
                h = Math.max(c.firstId, c.secondId),
                p = r.get(l),
                v = r.get(h);
              if (p && v && p.level === v.level && !(p.level >= 9)) {
                var g = p.positionDu.x - v.positionDu.x,
                  f = p.positionDu.y - v.positionDu.y;
                o.set(l + "|" + h, {
                  a: l,
                  b: h,
                  level: p.level,
                  distanceSq: g * g + f * f
                });
              }
            }
          }
          for (var I, y = Array.from(o.values()).sort(function (e, t) {
              return e.level - t.level || e.distanceSq - t.distanceSq || e.a - t.a || e.b - t.b;
            }), m = new Set(), D = function D() {
              var t = I.value;
              if (m.has(t.a) || m.has(t.b)) return 0;
              var s = r.get(t.a),
                n = r.get(t.b);
              m.add(t.a), m.add(t.b);
              var o = a.rules.ingredients.find(function (e) {
                return e.level === s.level + 1;
              });
              if (!o) return 0;
              var d = a.state.nextEntityId,
                c = a.adapter.wallContactProjectionMarginDu,
                l = a.projectChild({
                  x: (s.positionDu.x + n.positionDu.x) / 2,
                  y: (s.positionDu.y + n.positionDu.y) / 2
                }, o.radius_du, Number.isFinite(c) ? Math.max(0, c) : 0);
              if (!l) throw a.pause("TECHNICAL_ERROR"), new Error("MERGE_PROJECTION_NO_LEGAL_POINT");
              var h = {
                  x: (s.velocityDuPerSecond.x + n.velocityDuPerSecond.x) / 2,
                  y: (s.velocityDuPerSecond.y + n.velocityDuPerSecond.y) / 2
                },
                p = Math.hypot(h.x, h.y),
                v = a.rules.physics.max_linear_speed * a.rules.viewport.du_per_spec_physics_unit;
              p > v && (h.x *= v / p, h.y *= v / p);
              var g = Math.sin(s.angleRadians) + Math.sin(n.angleRadians),
                f = Math.cos(s.angleRadians) + Math.cos(n.angleRadians),
                y = Math.hypot(g, f) < 1e-8 ? t.a < t.b ? s.angleRadians : n.angleRadians : Math.atan2(g, f),
                D = a.rules.physics.max_angular_speed,
                _ = Math.max(-D, Math.min(D, (s.angularVelocity + n.angularVelocity) / 2)),
                x = a.adapter.replaceParentsWithChild([t.a, t.b], {
                  entityId: d,
                  level: o.level,
                  radiusDu: o.radius_du,
                  positionDu: l,
                  velocityDuPerSecond: h,
                  angleRadians: y,
                  angularVelocity: _
                });
              if (!x.ok) throw a.pause("TECHNICAL_ERROR"), new Error("MERGE_REPLACE_FAILED:" + x.error.code + ":" + x.error.message);
              var k = 2 * a.rules.ingredients.find(function (e) {
                  return e.level === s.level;
                }).units,
                E = o.merge_score;
              a.state.ingredients = a.state.ingredients.filter(function (e) {
                return e.entityId !== t.a && e.entityId !== t.b;
              }), a.state.ingredients.push({
                entityId: d,
                level: o.level,
                positionDu: l,
                velocityDuPerSecond: h,
                angleRadians: y,
                angularVelocity: _,
                bornTick: Math.min(s.bornTick, n.bornTick),
                dangerEligible: s.dangerEligible || n.dangerEligible,
                hasEnteredCup: s.hasEnteredCup || n.hasEnteredCup,
                spillTicks: Math.max(s.spillTicks, n.spillTicks),
                sleeping: !1
              }), a.state.nextEntityId++, a.state.maxLevel = Math.max(a.state.maxLevel, o.level);
              var S = u(a.state.runId, "MergeCommitted", e, [t.a, t.b]);
              a.usedMergeEvents.has(S) || (a.usedMergeEvents.add(S), a.state.score += E, i.push({
                kind: "MergeCommitted",
                eventId: S,
                runId: a.state.runId,
                tick: e,
                parents: [t.a, t.b],
                childId: d,
                childLevel: o.level,
                scoreDelta: E,
                units: k,
                positionDu: l
              }));
            }, _ = s(y); !(I = _()).done;) D();
        }, n.updateDanger = function (e, t) {
          for (var i, n = this, a = s(this.state.ingredients); !(i = a()).done;) {
            var r = i.value;
            !r.dangerEligible && e - r.bornTick >= 45 && (r.dangerEligible = !0);
          }
          var o = this.state.dangerTicks,
            d = this.rules.cup.danger_line_y_du,
            c = this.state.ingredients.some(function (e) {
              return e.dangerEligible && e.positionDu.y + n.radius(e.level) > d;
            });
          return this.state.dangerTicks = c ? o + 1 : 0, this.state.dangerTicks !== o && t.push({
            kind: "DangerChanged",
            eventId: u(this.state.runId, "DangerChanged", e, [this.state.dangerTicks]),
            runId: this.state.runId,
            tick: e,
            dangerTicks: this.state.dangerTicks
          }), this.state.dangerTicks >= Math.round(3 * this.rules.physics.fixed_hz);
        }, n.updateSpill = function (e) {
          for (var t, i = this.rules.cup.inner_top_y_du, n = [], a = s(this.state.ingredients); !(t = a()).done;) {
            var r = t.value;
            r.positionDu.y + this.radius(r.level) <= i && (r.hasEnteredCup = !0), r.hasEnteredCup && r.positionDu.y - this.radius(r.level) > i ? r.spillTicks++ : r.spillTicks = 0, r.spillTicks >= Math.round(.5 * this.rules.physics.fixed_hz) && n.push(r.entityId);
          }
          return n;
        }, n.beginSpillPending = function (e, t) {
          if (!this.reviveOptions.enabled || 0 !== this.state.revive.used || "PLAYING" !== this.state.state || this.ended) return !1;
          var s = this.computeSpillCandidate(e, t);
          if (0 === s.ingredients.length) return !1;
          var i = u(this.state.runId, "SpillPendingFailure", e, t);
          return this.state.revive.pendingFailure = {
            version: 1,
            failureId: i,
            detectedTick: e,
            reason: "SPILLED",
            spilledEntityIds: t.slice().sort(function (e, t) {
              return e - t;
            }),
            clearanceDu: this.reviveOptions.clearanceDu,
            candidateHash: s.candidateHash,
            retainedEntityIds: s.retainedEntityIds.slice()
          }, this.state.state = "PAUSED", this.state.terminalReason = null, this.state.revision++, !0;
        }, n.computeSpillCandidate = function (e, i) {
          for (var n, a = this.rules.cup.inner_top_y_du, r = Math.max(0, this.reviveOptions.clearanceDu), o = new Set(i), c = [], l = [], h = s(this.state.ingredients.slice().sort(function (e, t) {
              return e.entityId - t.entityId;
            })); !(n = h()).done;) {
            var p = n.value,
              v = this.radius(p.level);
            if (o.has(p.entityId) || p.spillTicks > 0 || p.positionDu.y + v > this.rules.cup.danger_line_y_du - r || ![p.positionDu.x, p.positionDu.y, p.velocityDuPerSecond.x, p.velocityDuPerSecond.y, p.angleRadians, p.angularVelocity].every(Number.isFinite)) c.push(p.entityId);else {
              var g = p.positionDu.x,
                f = p.positionDu.y,
                I = this.rules.cup.inner_bottom_y_du,
                y = a - v - 1;
              f > y && (f = Math.max(I - v, y)), l.push(t({}, p, {
                positionDu: {
                  x: g,
                  y: f
                },
                velocityDuPerSecond: {
                  x: 0,
                  y: 0
                },
                angleRadians: p.angleRadians,
                angularVelocity: 0,
                dangerEligible: !1,
                spillTicks: 0,
                sleeping: !1
              }));
            }
          }
          var m = l.map(function (e) {
              return e.entityId;
            }),
            D = {
              candidateId: u(this.state.runId, "SpillReviveCandidate", e, i),
              failureId: u(this.state.runId, "SpillPendingFailure", e, i),
              detectedTick: e,
              spilledEntityIds: [].concat(i).sort(function (e, t) {
                return e - t;
              }),
              removedEntityIds: c,
              retainedEntityIds: m,
              score: this.state.score,
              maxLevel: this.state.maxLevel,
              dropIndex: this.state.dropIndex,
              currentLevel: this.state.currentLevel,
              nextLevel: this.state.nextLevel,
              nextEntityId: this.state.nextEntityId,
              tick: e,
              rng: this.rng.snapshot(),
              spawnRng: this.spawnRng.snapshot(),
              cupOffsetXDu: 0,
              shake: t({}, this.state.shake),
              dangerTicks: this.state.dangerTicks,
              autoDrop: {
                nextDueTick: e + Math.max(0, this.reviveOptions.autoDropDelayTicks),
                pendingSpawn: t({}, this.state.autoDrop.pendingSpawn)
              },
              ingredients: l,
              candidateHash: ""
            },
            _ = {
              failureId: D.failureId,
              detectedTick: e,
              spilledEntityIds: D.spilledEntityIds,
              removedEntityIds: c,
              retainedEntityIds: m,
              score: D.score,
              maxLevel: D.maxLevel,
              dropIndex: D.dropIndex,
              currentLevel: D.currentLevel,
              nextLevel: D.nextLevel,
              nextEntityId: D.nextEntityId,
              rng: D.rng,
              spawnRng: D.spawnRng,
              dangerTicks: D.dangerTicks,
              pendingSpawn: D.autoDrop.pendingSpawn,
              ingredients: l.map(function (e) {
                return {
                  entityId: e.entityId,
                  level: e.level,
                  positionDu: e.positionDu,
                  velocityDuPerSecond: e.velocityDuPerSecond,
                  angleRadians: e.angleRadians,
                  angularVelocity: e.angularVelocity,
                  hasEnteredCup: e.hasEnteredCup
                };
              })
            };
          return D.candidateHash = d(JSON.stringify(_)), D;
        }, n.end = function (e, t) {
          return this.ended = !0, this.state.state = "SETTLING", this.state.terminalReason = e, this.state.settleStartedTick = t, this.state.revive.pendingFailure = null, {
            kind: "RunEnded",
            eventId: u(this.state.runId, "RunEnded", t, [e]),
            runId: this.state.runId,
            tick: t,
            reason: e,
            score: this.state.score
          };
        }, n.radius = function (e) {
          var t, s;
          return null != (t = null == (s = this.rules.ingredients.find(function (t) {
            return t.level === e;
          })) ? void 0 : s.radius_du) ? t : 0;
        }, n.clampSpawnX = function (e, t) {
          var s = this.radius(e),
            i = this.rules.cup;
          return Math.min(i.center_x_du + i.top_width_du / 2 - s, Math.max(i.center_x_du - i.top_width_du / 2 + s, t));
        }, n.projectChild = function (e, t, s) {
          var i,
            n = this.rules.cup,
            a = n.inner_bottom_y_du,
            r = n.inner_top_y_du;
          if (e.y - t > r) return e;
          for (var o = (n.top_width_du - n.bottom_width_du) / (2 * (r - a)), u = n.center_x_du + this.state.cupMotion.offsetXDu - n.bottom_width_du / 2, d = n.center_x_du + this.state.cupMotion.offsetXDu + n.bottom_width_du / 2, c = {
              x: 1 / Math.hypot(1, o),
              y: -o / Math.hypot(1, o)
            }, l = {
              x: -1 / Math.hypot(1, o),
              y: -o / Math.hypot(1, o)
            }, h = t + s, p = [{
              n: {
                x: 0,
                y: 1
              },
              b: a + h
            }, {
              n: c,
              b: c.x * u + c.y * a + h
            }, {
              n: l,
              b: l.x * d + l.y * a + h
            }], v = [e], g = 0, f = p; g < f.length; g++) {
            var I = f[g],
              y = I.b - I.n.x * e.x - I.n.y * e.y;
            v.push({
              x: e.x + I.n.x * y,
              y: e.y + I.n.y * y
            });
          }
          for (var m = 0; m < p.length; m++) for (var D = m + 1; D < p.length; D++) {
            var _ = p[m],
              x = p[D],
              k = _.n.x * x.n.y - _.n.y * x.n.x;
            Math.abs(k) > 1e-9 && v.push({
              x: (_.b * x.n.y - _.n.y * x.b) / k,
              y: (_.n.x * x.b - _.b * x.n.x) / k
            });
          }
          return null != (i = v.filter(function (e) {
            return p.every(function (t) {
              return t.n.x * e.x + t.n.y * e.y >= t.b - 1e-8;
            }) && e.y - t <= r + 1e-8;
          }).sort(function (t, s) {
            return Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2) - (Math.pow(s.x - e.x, 2) + Math.pow(s.y - e.y, 2)) || t.x - s.x || t.y - s.y;
          })[0]) ? i : null;
        }, n.validateSnapshot = function (e) {
          var t;
          if (!e || 5 !== e.saveSchemaVersion || !Number.isSafeInteger(e.tick) || e.tick < 0 || !Number.isSafeInteger(e.score) || e.score < 0 || !Array.isArray(e.ingredients) || !e.cupMotion || !Number.isFinite(e.cupMotion.offsetXDu) || Math.abs(e.cupMotion.offsetXDu) > this.rules.cup_motion.max_offset_du || !Number.isFinite(e.cupMotion.velocityXDuPerSecond) || Math.abs(e.cupMotion.velocityXDuPerSecond) > this.rules.cup_motion.max_speed_du_per_second || !Number.isFinite(e.cupMotion.targetOffsetXDu) || Math.abs(e.cupMotion.targetOffsetXDu) > this.rules.cup_motion.max_offset_du || !["IDLE", "DRAGGING", "SETTLING"].includes(e.cupMotion.control) || !Number.isSafeInteger(null == (t = e.autoDrop) ? void 0 : t.nextDueTick) || e.autoDrop.nextDueTick < e.tick || !e.spawnRng || 0 === e.spawnRng.state || !e.autoDrop.pendingSpawn || e.autoDrop.pendingSpawn.level !== e.currentLevel) return h("SAVE_INVALID", "存档基础字段无效");
          var i = e.shake;
          if (!i || !Number.isSafeInteger(i.baseUsed) || i.baseUsed < 0 || i.baseUsed > 2 || !Number.isSafeInteger(i.extraGranted) || i.extraGranted < 0 || i.extraGranted > 5 || !Number.isSafeInteger(i.extraUsed) || i.extraUsed < 0 || i.extraUsed > i.extraGranted) return h("SAVE_INVALID", "存档晃杯账本无效");
          var n = e.revive;
          if (!n || !Number.isSafeInteger(n.used) || n.used < 0 || n.used > 1) return h("SAVE_INVALID", "存档复活账本无效");
          if (null !== n.pendingFailure) {
            var a = n.pendingFailure;
            if (1 !== a.version || "SPILLED" !== a.reason || "string" != typeof a.failureId || !p.test(a.failureId) || !Number.isSafeInteger(a.detectedTick) || a.detectedTick < 0 || a.detectedTick > e.tick || !Array.isArray(a.spilledEntityIds) || !Array.isArray(a.retainedEntityIds) || !Number.isSafeInteger(a.clearanceDu) || a.clearanceDu < 0 || "string" != typeof a.candidateHash || 64 !== a.candidateHash.length) return h("SAVE_INVALID", "存档复活待处理数据无效");
            if ("PAUSED" !== e.state || null !== e.terminalReason) return h("SAVE_INVALID", "待复活局必须处于暂停");
          } else if (null !== n.committedReceiptId && ("string" != typeof n.committedReceiptId || !p.test(n.committedReceiptId))) return h("SAVE_INVALID", "存档复活凭证无效");
          if ("standard" !== e.boardType && "assisted" !== e.boardType || "assisted" === e.boardType != (i.extraUsed > 0 || n.used > 0)) return h("SAVE_INVALID", "存档局类型与奖励不一致");
          for (var r, o = new Set(), u = s(e.ingredients); !(r = u()).done;) {
            var d = r.value;
            if (o.has(d.entityId) || !Number.isSafeInteger(d.entityId) || ![d.positionDu.x, d.positionDu.y, d.velocityDuPerSecond.x, d.velocityDuPerSecond.y, d.angleRadians, d.angularVelocity].every(Number.isFinite)) return h("SAVE_INVALID", "存档实体无效");
            o.add(d.entityId);
          }
          return e.nextEntityId <= Math.max.apply(Math, [0].concat(o)) || 0 === e.rng.state || e.rng.drawCount !== e.dropIndex + 2 ? h("SAVE_INVALID", "存档跨字段校验失败") : l(void 0);
        }, n.assertInvariants = function () {
          for (var e, t = new Set(), i = s(this.state.ingredients); !(e = i()).done;) {
            var n = e.value;
            if (t.has(n.entityId)) throw new Error("DUPLICATE_ENTITY_ID");
            if (t.add(n.entityId), ![n.positionDu.x, n.positionDu.y, n.velocityDuPerSecond.x, n.velocityDuPerSecond.y, n.angleRadians, n.angularVelocity].every(Number.isFinite)) throw new Error("NON_FINITE_BODY");
          }
          if (!Number.isSafeInteger(this.state.tick) || !Number.isSafeInteger(this.state.score) || this.state.score < 0) throw new Error("RUN_INVARIANT_BROKEN");
        }, i(e, [{
          key: "phase",
          get: function get() {
            return this.state.state;
          }
        }, {
          key: "tick",
          get: function get() {
            return this.state.tick;
          }
        }, {
          key: "presentationCupOffsetXDu",
          get: function get() {
            return this.adapter.getCupOffsetX();
          }
        }, {
          key: "presentationShakeStartTick",
          get: function get() {
            return this.state.shake.activeStartTick;
          }
        }, {
          key: "presentationTick",
          get: function get() {
            return this.state.tick;
          }
        }, {
          key: "entityCount",
          get: function get() {
            return this.state.ingredients.length;
          }
        }, {
          key: "hasPendingCommand",
          get: function get() {
            return null !== this.pending;
          }
        }, {
          key: "currentOutcome",
          get: function get() {
            return this.lastCommandOutcome ? t({}, this.lastCommandOutcome) : null;
          }
        }, {
          key: "lastPhysicsMs",
          get: function get() {
            return this._lastPhysicsMs;
          }
        }, {
          key: "lastLogicMs",
          get: function get() {
            return this._lastLogicMs;
          }
        }, {
          key: "lastTickFault",
          get: function get() {
            return this._lastTickFault;
          }
        }, {
          key: "recoveryCheckpoint",
          get: function get() {
            return this._recoveryCheckpoint ? a(this._recoveryCheckpoint) : null;
          }
        }, {
          key: "spillPending",
          get: function get() {
            return this.state.revive.pendingFailure ? a(this.state.revive.pendingFailure) : null;
          }
        }, {
          key: "reviveUsed",
          get: function get() {
            return this.state.revive.used;
          }
        }, {
          key: "reviveReceiptId",
          get: function get() {
            return this.state.revive.committedReceiptId;
          }
        }]), e;
      }());
      n._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/RunRng.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (t) {
  var e, r;
  return {
    setters: [function (t) {
      e = t.createForOfIteratorHelperLoose;
    }, function (t) {
      r = t.cclegacy;
    }],
    execute: function execute() {
      r._RF.push({}, "1a518kE+XJN07I6PksaAuEj", "RunRng", void 0);
      t("RunRng", function () {
        function t(t, e, r) {
          if (void 0 === r && (r = 0), this.state = void 0, this.draws = void 0, !Number.isSafeInteger(t) || t <= 0 || t > 4294967295) throw new Error("SEED_MUST_BE_NONZERO_UINT32");
          if (this.state = (null != e ? e : t) >>> 0, 0 === this.state) throw new Error("RNG_STATE_CANNOT_BE_ZERO");
          if (!Number.isSafeInteger(r) || r < 0) throw new Error("RNG_DRAW_COUNT_INVALID");
          this.draws = r;
        }
        var r = t.prototype;
        return r.nextU32 = function () {
          var t = this.state >>> 0;
          return t ^= t << 13, t ^= t >>> 17, t ^= t << 5, this.state = t >>> 0, this.draws++, this.state;
        }, r.nextLevel = function (t) {
          for (var r, n = this.nextU32() / 4294967296 * t.reduce(function (t, e) {
              return t + e.weight;
            }, 0), s = e(t); !(r = s()).done;) {
            var i = r.value;
            if ((n -= i.weight) < 0) return i.level;
          }
          return t[t.length - 1].level;
        }, r.snapshot = function () {
          return {
            algorithm: "xorshift32_v1_nonzero_seed",
            state: this.state,
            drawCount: this.draws
          };
        }, t;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SaveCodec.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./CloneState.ts", "./Sha256.ts"], function (e) {
  var r, n, o, t, i;
  return {
    setters: [function (e) {
      r = e.createForOfIteratorHelperLoose, n = e["extends"];
    }, function (e) {
      o = e.cclegacy;
    }, function (e) {
      t = e.cloneState;
    }, function (e) {
      i = e.sha256Utf8;
    }],
    execute: function execute() {
      function s(e, n) {
        if (void 0 === n && (n = new Set()), "number" == typeof e) {
          if (!Number.isFinite(e) || !Number.isSafeInteger(e) && Number.isInteger(e)) throw new Error("SAVE_NUMBER_INVALID");
          return Object.is(e, -0) ? 0 : e;
        }
        if (null === e || "string" == typeof e || "boolean" == typeof e) return e;
        if (Array.isArray(e)) {
          if (n.has(e)) throw new Error("SAVE_CYCLE");
          n.add(e);
          var o = e.map(function (e) {
            return s(e, n);
          });
          return n["delete"](e), o;
        }
        if ("object" != _typeof(e) || void 0 === e) throw new Error("SAVE_VALUE_UNSUPPORTED");
        if (n.has(e)) throw new Error("SAVE_CYCLE");
        n.add(e);
        for (var t, i = e, a = {}, c = r(Object.keys(i).sort()); !(t = c()).done;) {
          var u = t.value;
          if (void 0 === i[u]) throw new Error("SAVE_UNDEFINED:" + u);
          a[u] = s(i[u], n);
        }
        return n["delete"](e), a;
      }
      function a(e) {
        var r = s(e);
        return r && Array.isArray(r.ingredients) && r.ingredients.sort(function (e, r) {
          return e.entityId - r.entityId;
        }), JSON.stringify(r);
      }
      e("canonicalJson", a), o._RF.push({}, "13e00XMT2JAmoYjn4K6zRcx", "SaveCodec", void 0);
      e("SaveCodec", function () {
        function e() {}
        return e.canonicalJson = function (e) {
          return a(e);
        }, e.sealSnapshot = function (e) {
          var r = t(e);
          return r.ingredients.sort(function (e, r) {
            return e.entityId - r.entityId;
          }), r.checksum = "", r.checksum = i(a(r)), r;
        }, e.verifySnapshot = function (e) {
          if (!e || "string" != typeof e.checksum || !/^[0-9a-f]{64}$/.test(e.checksum)) return !1;
          var r = t(e),
            n = r.checksum;
          return r.checksum = "", i(a(r)) === n;
        }, e.createEnvelope = function (e, r) {
          var o = {
            schemaVersion: 1,
            revision: e,
            payload: n({}, t(r), {
              run: r.run ? this.sealSnapshot(r.run) : null
            }),
            checksum: ""
          };
          return o.checksum = i(a({
            schemaVersion: o.schemaVersion,
            revision: o.revision,
            payload: o.payload
          })), o;
        }, e.verifyEnvelope = function (e) {
          return !(!e || 1 !== e.schemaVersion || !Number.isSafeInteger(e.revision) || e.revision < 0 || !/^[0-9a-f]{64}$/.test(e.checksum)) && !(e.payload.run && !this.verifySnapshot(e.payload.run)) && i(a({
            schemaVersion: e.schemaVersion,
            revision: e.revision,
            payload: e.payload
          })) === e.checksum;
        }, e.createEnvelopeV2 = function (e, r) {
          var o = {
            schemaVersion: 2,
            revision: e,
            payload: n({}, t(r), {
              run: r.run ? this.sealSnapshot(r.run) : null
            }),
            checksum: ""
          };
          return o.checksum = i(a({
            schemaVersion: o.schemaVersion,
            revision: o.revision,
            payload: o.payload
          })), o;
        }, e.verifyEnvelopeV2 = function (e) {
          return !(!e || 2 !== e.schemaVersion || !Number.isSafeInteger(e.revision) || e.revision < 0 || !/^[0-9a-f]{64}$/.test(e.checksum)) && !(e.payload.run && !this.verifySnapshot(e.payload.run)) && i(a({
            schemaVersion: e.schemaVersion,
            revision: e.revision,
            payload: e.payload
          })) === e.checksum;
        }, e;
      }());
      o._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SaveMigration.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./SaveCodec.ts"], function (e) {
  var n, t, r;
  return {
    setters: [function (e) {
      n = e["extends"];
    }, function (e) {
      t = e.cclegacy;
    }, function (e) {
      r = e.SaveCodec;
    }],
    execute: function execute() {
      t._RF.push({}, "a2d35r/jqZMQ7LESRV8/PlZ", "SaveMigration", void 0);
      e("SaveMigration", function () {
        function e() {}
        return e.runV3 = function (e) {
          var t = e,
            u = n({}, t, {
              saveSchemaVersion: 5,
              spawnRng: {
                algorithm: "spawn-xorshift32-v1",
                state: 1831565813,
                drawCount: 0
              },
              autoDrop: {
                nextDueTick: t.autoDrop.nextDueTick,
                pendingSpawn: {
                  level: t.currentLevel,
                  xDu: 375,
                  vxDuPerSecond: 0,
                  angularVelocity: 0
                }
              },
              revive: {
                used: 0,
                pendingFailure: null,
                committedReceiptId: null
              },
              checksum: ""
            });
          return r.sealSnapshot(u);
        }, e.runV4 = function (e) {
          var t = n({}, e, {
            saveSchemaVersion: 5,
            revive: {
              used: 0,
              pendingFailure: null,
              committedReceiptId: null
            },
            checksum: ""
          });
          return r.sealSnapshot(t);
        }, e.bundle = function (e) {
          return {
            profile: this.profile(e.profile, e.lastResult),
            run: e.run ? this.run(e.run) : null,
            lastResult: e.lastResult ? this.lastResult(e.lastResult) : null
          };
        }, e.profile = function (e, t) {
          return n({}, e, {
            schemaVersion: 3,
            firstNaturalRunCompleted: !!t && ("CUP_FULL" === t.reason || "SPILLED" === t.reason),
            rewardedShake: {
              dayKey: null,
              dailyGranted: 0,
              pendingAttempt: null,
              receipts: []
            },
            rewardedRevive: {
              dayKey: null,
              dailyGranted: 0,
              pendingAttempt: null,
              receipts: []
            }
          });
        }, e.profileV2 = function (e) {
          return n({}, e, {
            schemaVersion: 3,
            rewardedRevive: {
              dayKey: null,
              dailyGranted: 0,
              pendingAttempt: null,
              receipts: []
            }
          });
        }, e.run = function (e) {
          var t = e,
            u = Number(t.tick),
            a = n({}, t, {
              saveSchemaVersion: 5,
              shake: n({}, t.shake, {
                extraGranted: 0
              }),
              cupMotion: t.cupMotion ? t.cupMotion : {
                offsetXDu: 0,
                velocityXDuPerSecond: 0,
                targetOffsetXDu: 0,
                control: "IDLE"
              },
              spawnRng: {
                algorithm: "spawn-xorshift32-v1",
                state: 1831565813,
                drawCount: 0
              },
              autoDrop: {
                nextDueTick: t.autoDrop ? Number(t.autoDrop.nextDueTick) : (Number.isSafeInteger(u) ? u : 0) + 1,
                pendingSpawn: {
                  level: Number(t.currentLevel),
                  xDu: 375,
                  vxDuPerSecond: 0,
                  angularVelocity: 0
                }
              },
              revive: {
                used: 0,
                pendingFailure: null,
                committedReceiptId: null
              },
              checksum: ""
            });
          return r.sealSnapshot(a);
        }, e.lastResult = function (e) {
          return {
            runId: e.runId,
            reason: e.reason,
            score: e.score,
            maxLevel: e.maxLevel,
            dropIndex: e.dropIndex,
            baseUsed: e.baseUsed,
            extraUsed: 0,
            boardType: "standard",
            rulesVersion: e.rulesVersion
          };
        }, e;
      }());
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SaveValidator.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./SaveCodec.ts"], function (e) {
  var t, r, n;
  return {
    setters: [function (e) {
      t = e.createForOfIteratorHelperLoose;
    }, function (e) {
      r = e.cclegacy;
    }, function (e) {
      n = e.SaveCodec;
    }],
    execute: function execute() {
      r._RF.push({}, "697b8pNitdJNLIN9ExDCljD", "SaveValidator", void 0);
      var a = function a(e, t) {
          return {
            valid: !1,
            code: e,
            message: t
          };
        },
        i = function i(e) {
          return !!e && "object" == _typeof(e) && !Array.isArray(e) && Object.getPrototypeOf(e) === Object.prototype;
        },
        s = function s(e, t) {
          return Object.keys(e).every(function (e) {
            return t.includes(e);
          });
        },
        o = function o(e, t, r) {
          return void 0 === r && (r = Number.MAX_SAFE_INTEGER), Number.isSafeInteger(e) && Number(e) >= t && Number(e) <= r;
        },
        u = function u(e) {
          return "number" == typeof e && Number.isFinite(e);
        },
        l = function l(e) {
          return "string" == typeof e && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(e);
        },
        d = function d(e) {
          return "string" == typeof e && /^\d{4}-\d{2}-\d{2}$/.test(e);
        },
        c = ["classic", "coconut_green", "taro_boba", "brown_sugar", "mochi_special"],
        p = ["CUP_FULL", "SPILLED", "BUDGET_EXHAUSTED", "ABANDONED", "TECHNICAL_ERROR"],
        I = ["design-v0.1", "design-v0.2-short-cup-01", "design-v0.3-cup-auto-01", "design-v0.4-mobile-feel-ads-01", "design-v0.5-natural-spawn-01"],
        E = function E(e) {
          return o(e, 1, 9);
        },
        A = function A(e) {
          return "standard" === e || "assisted" === e;
        },
        f = ["saveSchemaVersion", "rulesVersion", "appVersion", "runId", "epoch", "revision", "stageId", "mode", "boardType", "state", "tick", "nextEntityId", "nextCommandSequence", "score", "maxLevel", "dropIndex", "currentLevel", "nextLevel", "lastDropTick", "settleStartedTick", "challenge", "rng", "ingredients", "shake", "dangerTicks", "terminalReason", "checksum"];
      e("SaveValidator", function () {
        function e() {}
        return e.envelope = function (e) {
          try {
            return !!(i(e) && s(e, ["schemaVersion", "revision", "payload", "checksum"]) && 2 === e.schemaVersion && o(e.revision, 0) && "string" == typeof e.checksum && /^[0-9a-f]{64}$/.test(e.checksum)) && !!this.bundle(e.payload).valid && n.verifyEnvelopeV2(e);
          } catch (e) {
            return !1;
          }
        }, e.legacyEnvelope = function (e) {
          try {
            return !!(i(e) && s(e, ["schemaVersion", "revision", "payload", "checksum"]) && 1 === e.schemaVersion && o(e.revision, 0) && "string" == typeof e.checksum && /^[0-9a-f]{64}$/.test(e.checksum)) && !!this.legacyBundle(e.payload).valid && n.verifyEnvelope(e);
          } catch (e) {
            return !1;
          }
        }, e.bundle = function (e) {
          try {
            var t;
            if (!i(e) || !s(e, ["profile", "run", "lastResult"])) return a("SAVE_BUNDLE_INVALID", "档案结构无效");
            var r = this.profile(e.profile);
            if (!r.valid) return r;
            if (null !== e.run) {
              var n = this.snapshot(e.run);
              if (!n.valid) return n;
            }
            var u = e.run;
            if ((null != (t = null == u ? void 0 : u.runId) ? t : null) !== e.profile.activeRunId) return a("SAVE_OWNER_MISMATCH", "活动局与玩家档案owner不一致");
            if (null !== e.lastResult) {
              var d = e.lastResult;
              if (!(i(d) && s(d, ["runId", "reason", "score", "maxLevel", "dropIndex", "baseUsed", "extraUsed", "boardType", "rulesVersion"]) && l(d.runId) && p.includes(d.reason) && o(d.score, 0) && E(d.maxLevel) && o(d.dropIndex, 0) && o(d.baseUsed, 0, 2) && o(d.extraUsed, 0, 5) && A(d.boardType) && !(d.extraUsed > 0 && "assisted" !== d.boardType) && (void 0 === d.rulesVersion || "string" == typeof d.rulesVersion))) return a("SAVE_RESULT_INVALID", "结算摘要无效");
            }
            return {
              valid: !0,
              code: null,
              message: null
            };
          } catch (e) {
            return a("SAVE_BUNDLE_INVALID", "档案结构无效");
          }
        }, e.legacyBundle = function (e) {
          try {
            var t;
            if (!i(e) || !s(e, ["profile", "run", "lastResult"])) return a("SAVE_BUNDLE_INVALID", "档案结构无效");
            var r = this.legacyProfile(e.profile);
            if (!r.valid) return r;
            if (null !== e.run) {
              var n = e.run.saveSchemaVersion;
              if (1 !== n && 2 !== n && 3 !== n) return a("SAVE_RUN_HEADER", "旧版运行快照版本不支持");
              var u = this.legacySnapshot(e.run, n);
              if (!u.valid) return u;
            }
            var d = e.run;
            if ((null != (t = null == d ? void 0 : d.runId) ? t : null) !== e.profile.activeRunId) return a("SAVE_OWNER_MISMATCH", "活动局与玩家档案owner不一致");
            if (null !== e.lastResult) {
              var c = e.lastResult;
              if (!(i(c) && s(c, ["runId", "reason", "score", "maxLevel", "dropIndex", "baseUsed", "extraUsed", "rulesVersion"]) && l(c.runId) && p.includes(c.reason) && o(c.score, 0) && E(c.maxLevel) && o(c.dropIndex, 0) && o(c.baseUsed, 0, 2) && 0 === c.extraUsed && (void 0 === c.rulesVersion || "string" == typeof c.rulesVersion))) return a("SAVE_RESULT_INVALID", "结算摘要无效");
            }
            return {
              valid: !0,
              code: null,
              message: null
            };
          } catch (e) {
            return a("SAVE_BUNDLE_INVALID", "档案结构无效");
          }
        }, e.profileShape = function (e, r) {
          try {
            var n = 1 === r ? [] : 2 === r ? ["firstNaturalRunCompleted", "rewardedShake"] : ["firstNaturalRunCompleted", "rewardedShake", "rewardedRevive"];
            if (!i(e) || !s(e, ["schemaVersion", "settings", "discoveredLevels", "unlockedStageIds", "bestScores", "activeRunId", "revision", "bestScoresByRules", "tutorialRulesVersion"].concat(n)) || e.schemaVersion !== r || !o(e.revision, 0)) return a("SAVE_PROFILE_INVALID", "玩家档案字段无效");
            var p = e.settings;
            if (!i(p) || !s(p, ["musicGain", "sfxGain", "reducedMotion", "dropMode", "tutorialCompleted"]) || !u(p.musicGain) || p.musicGain < 0 || p.musicGain > 1 || !u(p.sfxGain) || p.sfxGain < 0 || p.sfxGain > 1 || "boolean" != typeof p.reducedMotion || !["drag_release", "tap_confirm"].includes(String(p.dropMode)) || "boolean" != typeof p.tutorialCompleted) return a("SAVE_SETTINGS_INVALID", "设置字段无效");
            if (!Array.isArray(e.discoveredLevels) || e.discoveredLevels.some(function (e) {
              return !E(e);
            }) || new Set(e.discoveredLevels).size !== e.discoveredLevels.length) return a("SAVE_DISCOVERY_INVALID", "已发现等级无效");
            if (!Array.isArray(e.unlockedStageIds) || 0 === e.unlockedStageIds.length || e.unlockedStageIds.some(function (e) {
              return !c.includes(e);
            }) || new Set(e.unlockedStageIds).size !== e.unlockedStageIds.length) return a("SAVE_STAGE_INVALID", "解锁阶段无效");
            if (null !== e.activeRunId && !l(e.activeRunId)) return a("SAVE_ACTIVE_RUN_INVALID", "活动局标识无效");
            if (!i(e.bestScores) || !s(e.bestScores, c)) return a("SAVE_BEST_SCORES_INVALID", "最佳成绩结构无效");
            for (var I = 0, A = Object.keys(e.bestScores); I < A.length; I++) {
              var f = A[I],
                S = e.bestScores[f];
              if (!i(S) || !s(S, ["standard", "assisted"]) || Object.values(S).some(function (e) {
                return !o(e, 0);
              })) return a("SAVE_BEST_SCORES_INVALID", "最佳成绩结构无效");
            }
            if (void 0 !== e.tutorialRulesVersion && null !== e.tutorialRulesVersion && "string" != typeof e.tutorialRulesVersion) return a("SAVE_PROFILE_INVALID", "教程规则标识无效");
            if (r >= 2) {
              if ("boolean" != typeof e.firstNaturalRunCompleted) return a("SAVE_PROFILE_INVALID", "自然首局完成标记无效");
              var v = e.rewardedShake;
              if (!i(v) || !s(v, ["dayKey", "dailyGranted", "pendingAttempt", "receipts"]) || null !== v.dayKey && !d(v.dayKey) || !o(v.dailyGranted, 0, 365)) return a("SAVE_REWARD_LEDGER_INVALID", "奖励账本字段无效");
              var _ = v.pendingAttempt;
              if (!(null === _ || i(_) && s(_, ["attemptId", "runId", "policyVersion", "amount", "dayKey", "startedAt"]) && l(_.attemptId) && l(_.runId) && "string" == typeof _.policyVersion && 0 !== _.policyVersion.length && 1 === _.amount && d(_.dayKey) && o(_.startedAt, 0))) return a("SAVE_REWARD_LEDGER_INVALID", "待确认奖励记录无效");
              if (!Array.isArray(v.receipts) || v.receipts.length > 64) return a("SAVE_REWARD_LEDGER_INVALID", "奖励凭证列表无效");
              for (var V, y = new Set(), D = t(v.receipts); !(V = D()).done;) {
                var R = V.value;
                if (!i(R) || !s(R, ["attemptId", "runId", "rewardKind", "amount", "policyVersion", "dayKey", "status", "grantedAt"]) || !l(R.attemptId) || y.has(R.attemptId) || !l(R.runId) || "extra_shake" !== R.rewardKind || 1 !== R.amount || "string" != typeof R.policyVersion || 0 === R.policyVersion.length || !d(R.dayKey) || "COMMITTED" !== R.status || !o(R.grantedAt, 0)) return a("SAVE_REWARD_LEDGER_INVALID", "奖励凭证无效");
                y.add(R.attemptId);
              }
              if (3 === r) {
                var g = e.rewardedRevive;
                if (!i(g) || !s(g, ["dayKey", "dailyGranted", "pendingAttempt", "receipts"]) || null !== g.dayKey && !d(g.dayKey) || !o(g.dailyGranted, 0, 365)) return a("SAVE_REWARD_LEDGER_INVALID", "复活奖励账本字段无效");
                var m = g.pendingAttempt;
                if (!(null === m || i(m) && s(m, ["attemptId", "runId", "failureId", "policyVersion", "amount", "dayKey", "startedAt"]) && l(m.attemptId) && l(m.runId) && l(m.failureId) && "string" == typeof m.policyVersion && 0 !== m.policyVersion.length && 1 === m.amount && d(m.dayKey) && o(m.startedAt, 0))) return a("SAVE_REWARD_LEDGER_INVALID", "待确认复活记录无效");
                if (!Array.isArray(g.receipts) || g.receipts.length > 64) return a("SAVE_REWARD_LEDGER_INVALID", "复活凭证列表无效");
                for (var L, T = new Set(), h = t(g.receipts); !(L = h()).done;) {
                  var N = L.value;
                  if (!i(N) || !s(N, ["attemptId", "runId", "failureId", "rewardKind", "amount", "policyVersion", "dayKey", "status", "grantedAt"]) || !l(N.attemptId) || T.has(N.attemptId) || !l(N.runId) || !l(N.failureId) || "spill_revive" !== N.rewardKind || 1 !== N.amount || "string" != typeof N.policyVersion || 0 === N.policyVersion.length || !d(N.dayKey) || "COMMITTED" !== N.status || !o(N.grantedAt, 0)) return a("SAVE_REWARD_LEDGER_INVALID", "复活凭证无效");
                  T.add(N.attemptId);
                }
              }
            }
            return {
              valid: !0,
              code: null,
              message: null
            };
          } catch (e) {
            return a("SAVE_PROFILE_INVALID", "玩家档案结构无效");
          }
        }, e.profile = function (e) {
          return this.profileShape(e, 3);
        }, e.profileV2 = function (e) {
          return this.profileShape(e, 2);
        }, e.legacyProfile = function (e) {
          return this.profileShape(e, 1);
        }, e.runCommon = function (e) {
          try {
            var r = e;
            if (!l(r.runId) || !o(r.epoch, 0) || !o(r.revision, 0)) return a("SAVE_RUN_HEADER", "运行快照头无效或版本不兼容");
            if (!c.includes(r.stageId) || "classic" !== r.mode || !A(r.boardType) || !["PLAYING", "PAUSED", "SETTLING", "RESULTS"].includes(r.state)) return a("SAVE_RULES_UNSUPPORTED", "本地经典档规则不兼容");
            if (!(o(r.tick, 0) && o(r.nextEntityId, 1) && o(r.nextCommandSequence, 1) && o(r.score, 0) && E(r.maxLevel) && o(r.dropIndex, 0) && E(r.currentLevel) && E(r.nextLevel))) return a("SAVE_RUN_COUNTER", "运行计数无效");
            if (null !== r.lastDropTick && (!o(r.lastDropTick, 0) || r.lastDropTick > r.tick) || null !== r.settleStartedTick && (!o(r.settleStartedTick, 0) || r.settleStartedTick > r.tick)) return a("SAVE_ID_OR_DROP_TICK", "实体ID或逻辑步无效");
            if (null !== r.terminalReason && !p.includes(r.terminalReason)) return a("SAVE_TERMINAL_INVALID", "终局原因无效");
            if (("SETTLING" === r.state || "RESULTS" === r.state) && null === r.terminalReason || ["PLAYING", "PAUSED"].includes(r.state) && null !== r.terminalReason) return a("SAVE_TERMINAL_INVALID", "终局状态与原因不一致");
            if (null !== r.challenge) return a("SAVE_RULES_UNSUPPORTED", "本地经典档不接受挑战状态");
            if (!(i(r.rng) && s(r.rng, ["algorithm", "state", "drawCount"]) && "xorshift32_v1_nonzero_seed" === r.rng.algorithm && o(r.rng.state, 1, 4294967295) && o(r.rng.drawCount, 0) && r.rng.drawCount === r.dropIndex + 2)) return a("SAVE_RNG_INVALID", "随机流状态无效");
            if (!o(r.dangerTicks, 0, 180) || !Array.isArray(r.ingredients)) return a("SAVE_RULE_STATE_INVALID", "危险或实体列表无效");
            for (var d, I = new Set(), f = 0, S = t(r.ingredients); !(d = S()).done;) {
              var v = d.value;
              if (!i(v) || !s(v, ["entityId", "level", "positionDu", "velocityDuPerSecond", "angleRadians", "angularVelocity", "bornTick", "dangerEligible", "hasEnteredCup", "spillTicks", "sleeping"]) || !o(v.entityId, 1) || I.has(v.entityId) || !E(v.level)) return a("SAVE_ENTITY_ID", "实体ID或等级无效");
              I.add(v.entityId), f = Math.max(f, v.entityId);
              for (var _ = 0, V = [v.positionDu, v.velocityDuPerSecond]; _ < V.length; _++) {
                var y = V[_];
                if (!(i(y) && s(y, ["x", "y"]) && u(y.x) && u(y.y))) return a("SAVE_ENTITY_NONFINITE", "实体向量字段无效");
              }
              if (!(u(v.angleRadians) && u(v.angularVelocity) && o(v.bornTick, 0, r.tick) && "boolean" == typeof v.dangerEligible && "boolean" == typeof v.hasEnteredCup && o(v.spillTicks, 0, 30) && "boolean" == typeof v.sleeping)) return a("SAVE_ENTITY_LOGIC", "实体逻辑字段无效");
            }
            return r.nextEntityId <= f || r.maxLevel < Math.max.apply(Math, [1].concat(r.ingredients.map(function (e) {
              return e.level;
            }))) || 0 === r.dropIndex != (null === r.lastDropTick) ? a("SAVE_ID_OR_DROP_TICK", "ID、最高等级或投放步跨字段不一致") : "string" == typeof r.checksum && /^[0-9a-f]{64}$/.test(r.checksum) && n.verifySnapshot(r) ? {
              valid: !0,
              code: null,
              message: null
            } : a("SAVE_RUN_CHECKSUM", "运行快照checksum缺失或不匹配");
          } catch (e) {
            return a("SAVE_RUN_INVALID", "运行快照结构无效");
          }
        }, e.motionAndAuto = function (e, t) {
          var r = e.cupMotion,
            n = e.autoDrop;
          return !i(r) || !s(r, ["offsetXDu", "velocityXDuPerSecond", "targetOffsetXDu", "control"]) || !u(r.offsetXDu) || Math.abs(r.offsetXDu) > 110 || !u(r.velocityXDuPerSecond) || Math.abs(r.velocityXDuPerSecond) > 1200 || !u(r.targetOffsetXDu) || Math.abs(r.targetOffsetXDu) > 110 || !["IDLE", "DRAGGING", "SETTLING"].includes(String(r.control)) || !i(n) || !s(n, ["nextDueTick"]) && !s(n, ["nextDueTick", "pendingSpawn"]) || !o(n.nextDueTick, 0) ? a("SAVE_CUP_AUTO_INVALID", "移杯或自动落料状态无效") : {
            valid: !0,
            code: null,
            message: null
          };
        }, e.snapshot = function (e) {
          try {
            if (!i(e)) return a("SAVE_RUN_HEADER", "运行快照结构无效");
            if (!s(e, [].concat(f, ["cupMotion", "autoDrop", "spawnRng", "revive"])) || 5 !== e.saveSchemaVersion || !I.includes(String(e.rulesVersion)) || "0.1.0" !== e.appVersion) return a("SAVE_RUN_HEADER", "运行快照头无效或版本不兼容");
            var t = e,
              r = t.shake;
            if (!i(r) || !s(r, ["baseUsed", "extraGranted", "extraUsed", "activeStartTick", "cooldownUntilTick"]) || !o(r.baseUsed, 0, 2) || !o(r.extraGranted, 0, 5) || !o(r.extraUsed, 0, 5) || r.extraUsed > r.extraGranted || null !== r.activeStartTick && !o(r.activeStartTick, 0, t.tick) || !o(r.cooldownUntilTick, 0)) return a("SAVE_RULE_STATE_INVALID", "危险或晃杯状态越界");
            var n = t.revive,
              d = r.extraUsed > 0 || 1 === (null == n ? void 0 : n.used);
            if (!i(n) || !s(n, ["used", "pendingFailure", "committedReceiptId"]) || !1 === o(n.used, 0, 1)) return a("SAVE_RULE_STATE_INVALID", "复活账本无效");
            if (null !== n.pendingFailure) {
              var c = n.pendingFailure;
              if (!i(c) || !s(c, ["version", "failureId", "detectedTick", "reason", "spilledEntityIds", "clearanceDu", "candidateHash", "retainedEntityIds"]) || 1 !== c.version || "SPILLED" !== c.reason || !l(c.failureId) || !o(c.detectedTick, 0, t.tick) || !Array.isArray(c.spilledEntityIds) || !Array.isArray(c.retainedEntityIds) || c.retainedEntityIds.some(function (e) {
                return !o(e, 1);
              }) || !o(c.clearanceDu, 0, 200) || "string" != typeof c.candidateHash || !/^[0-9a-f]{64}$/.test(c.candidateHash) || "PAUSED" !== t.state || null !== t.terminalReason) return a("SAVE_RULE_STATE_INVALID", "待复活数据无效");
            } else if (null !== n.committedReceiptId && !l(n.committedReceiptId)) return a("SAVE_RULE_STATE_INVALID", "复活凭证无效");
            if (d && "assisted" !== t.boardType || !d && "assisted" === t.boardType) return a("SAVE_RULE_STATE_INVALID", "辅助局与奖励计数不一致");
            var p = this.runCommon(e);
            if (!p.valid) return p;
            if (!(i(e.spawnRng) && s(e.spawnRng, ["algorithm", "state", "drawCount"]) && "spawn-xorshift32-v1" === e.spawnRng.algorithm && o(e.spawnRng.state, 1, 4294967295) && o(e.spawnRng.drawCount, 0, Number.MAX_SAFE_INTEGER) && i(e.autoDrop) && s(e.autoDrop, ["nextDueTick", "pendingSpawn"]))) return a("SAVE_SPAWN_INVALID", "自然落料随机流状态无效");
            var A = this.motionAndAuto(e, t);
            if (!A.valid) return A;
            var S = e.autoDrop.pendingSpawn;
            return !i(S) || !s(S, ["level", "xDu", "vxDuPerSecond", "angularVelocity"]) || !E(S.level) || S.level !== t.currentLevel || !u(S.xDu) || Math.abs(S.xDu - 375) > 20 || !u(S.vxDuPerSecond) || Math.abs(S.vxDuPerSecond) > 12 || 0 !== S.angularVelocity ? a("SAVE_SPAWN_INVALID", "待落料描述符无效") : {
              valid: !0,
              code: null,
              message: null
            };
          } catch (e) {
            return a("SAVE_RUN_INVALID", "运行快照结构无效");
          }
        }, e.legacySnapshotV4 = function (e) {
          try {
            if (!i(e)) return a("SAVE_RUN_HEADER", "运行快照结构无效");
            if (!s(e, [].concat(f, ["cupMotion", "autoDrop", "spawnRng"])) || 4 !== e.saveSchemaVersion || !I.includes(String(e.rulesVersion)) || "0.1.0" !== e.appVersion) return a("SAVE_RUN_HEADER", "运行快照头无效或版本不兼容");
            var t = e,
              r = t.shake;
            if (!i(r) || !s(r, ["baseUsed", "extraGranted", "extraUsed", "activeStartTick", "cooldownUntilTick"]) || !o(r.baseUsed, 0, 2) || !o(r.extraGranted, 0, 5) || !o(r.extraUsed, 0, 5) || r.extraUsed > r.extraGranted || null !== r.activeStartTick && !o(r.activeStartTick, 0, t.tick) || !o(r.cooldownUntilTick, 0)) return a("SAVE_RULE_STATE_INVALID", "危险或晃杯状态越界");
            if (r.extraUsed > 0 && "assisted" !== t.boardType || 0 === r.extraUsed && "assisted" === t.boardType) return a("SAVE_RULE_STATE_INVALID", "辅助局与额外晃杯计数不一致");
            var n = this.runCommon(e);
            if (!n.valid) return n;
            if (!(i(e.spawnRng) && s(e.spawnRng, ["algorithm", "state", "drawCount"]) && "spawn-xorshift32-v1" === e.spawnRng.algorithm && o(e.spawnRng.state, 1, 4294967295) && o(e.spawnRng.drawCount, 0, Number.MAX_SAFE_INTEGER) && i(e.autoDrop) && s(e.autoDrop, ["nextDueTick", "pendingSpawn"]))) return a("SAVE_SPAWN_INVALID", "自然落料随机流状态无效");
            var u = this.motionAndAuto(e, t);
            return u.valid ? {
              valid: !0,
              code: null,
              message: null
            } : u;
          } catch (e) {
            return a("SAVE_RUN_INVALID", "运行快照结构无效");
          }
        }, e.legacySnapshot = function (e, t) {
          try {
            if (!i(e)) return a("SAVE_RUN_HEADER", "运行快照结构无效");
            var r = 1 === t ? f : [].concat(f, ["cupMotion", "autoDrop"]);
            if (!s(e, r) || e.saveSchemaVersion !== t || !I.includes(String(e.rulesVersion)) || "0.1.0" !== e.appVersion) return a("SAVE_RUN_HEADER", "运行快照头无效或版本不兼容");
            var n = e,
              u = n.shake;
            if (!i(u) || !s(u, ["baseUsed", "extraUsed", "activeStartTick", "cooldownUntilTick"]) || !o(u.baseUsed, 0, 2) || 0 !== u.extraUsed || "standard" !== n.boardType || null !== u.activeStartTick && !o(u.activeStartTick, 0, n.tick) || !o(u.cooldownUntilTick, 0)) return a("SAVE_RULE_STATE_INVALID", "危险或晃杯状态越界");
            var l = this.runCommon(e);
            if (!l.valid) return l;
            if (t >= 2) {
              var d = this.motionAndAuto(e, n);
              if (!d.valid) return d;
            }
            return {
              valid: !0,
              code: null,
              message: null
            };
          } catch (e) {
            return a("SAVE_RUN_INVALID", "运行快照结构无效");
          }
        }, e;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/Sha256.ts", ["cc"], function (r) {
  var t;
  return {
    setters: [function (r) {
      t = r.cclegacy;
    }],
    execute: function execute() {
      r({
        sha256Bytes: a,
        sha256Utf8: function sha256Utf8(r) {
          return a(new TextEncoder().encode(r));
        }
      }), t._RF.push({}, "a9a80Siu9RA2pagiN8Sc3UQ", "Sha256", void 0);
      var n = new Uint32Array([1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]),
        e = function e(r, t) {
          return r >>> t | r << 32 - t;
        };
      function a(r) {
        var t = 8 * r.length,
          a = 64 * Math.ceil((r.length + 9) / 64),
          i = new Uint8Array(a);
        i.set(r), i[r.length] = 128;
        var o = new DataView(i.buffer);
        o.setUint32(a - 8, Math.floor(t / 4294967296), !1), o.setUint32(a - 4, t >>> 0, !1);
        for (var c = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]), u = new Uint32Array(64), f = 0; f < a; f += 64) {
          for (var s = 0; s < 16; s++) u[s] = o.getUint32(f + 4 * s, !1);
          for (var v = 16; v < 64; v++) {
            var h = u[v - 15],
              y = u[v - 2],
              U = e(h, 7) ^ e(h, 18) ^ h >>> 3,
              g = e(y, 17) ^ e(y, 19) ^ y >>> 10;
            u[v] = u[v - 16] + U + u[v - 7] + g >>> 0;
          }
          for (var l = Array.from(c), w = l[0], A = l[1], S = l[2], p = l[3], d = l[4], m = l[5], R = l[6], _ = l[7], x = 0; x < 64; x++) {
            var F = _ + (e(d, 6) ^ e(d, 11) ^ e(d, 25)) + (d & m ^ ~d & R) + n[x] + u[x] >>> 0,
              M = w & A ^ w & S ^ A & S;
            _ = R, R = m, m = d, d = p + F >>> 0, p = S, S = A, A = w, w = F + ((e(w, 2) ^ e(w, 13) ^ e(w, 22)) + M >>> 0) >>> 0;
          }
          c[0] = c[0] + w >>> 0, c[1] = c[1] + A >>> 0, c[2] = c[2] + S >>> 0, c[3] = c[3] + p >>> 0, c[4] = c[4] + d >>> 0, c[5] = c[5] + m >>> 0, c[6] = c[6] + R >>> 0, c[7] = c[7] + _ >>> 0;
        }
        return Array.from(c, function (r) {
          return r.toString(16).padStart(8, "0");
        }).join("");
      }
      t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SpawnRng.ts", ["cc"], function (t) {
  var s;
  return {
    setters: [function (t) {
      s = t.cclegacy;
    }],
    execute: function execute() {
      s._RF.push({}, "004154WL5lGVpJimG2GSWTi", "SpawnRng", void 0);
      t("SpawnRng", function () {
        function t(s, n, i) {
          if (void 0 === i && (i = 0), this.state = void 0, this.draws = void 0, this.state = (null != n ? n : t.seed(s)) >>> 0, !this.state) throw new Error("SPAWN_RNG_ZERO");
          this.draws = i;
        }
        t.seed = function (t) {
          var s = (2654435769 ^ t) >>> 0;
          return s = (s ^ s >>> 16) >>> 0, s = ((s = Math.imul(s, 2146121005) >>> 0) ^ s >>> 15) >>> 0, (s = ((s = Math.imul(s, 2221713035) >>> 0) ^ s >>> 16) >>> 0) || 1831565813;
        };
        var s = t.prototype;
        return s.nextIndex = function (t) {
          var s = this.state;
          return s ^= s << 13, s ^= s >>> 17, s ^= s << 5, this.state = s >>> 0, this.draws++, Math.floor(this.state / 4294967296 * t);
        }, s.snapshot = function () {
          return {
            algorithm: "spawn-xorshift32-v1",
            state: this.state,
            drawCount: this.draws
          };
        }, t;
      }());
      s._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SpillRevivePolicyLoader.ts", ["cc"], function (e) {
  var r;
  return {
    setters: [function (e) {
      r = e.cclegacy;
    }],
    execute: function execute() {
      r._RF.push({}, "bc171rOcylDbb5GcixkWOjf", "SpillRevivePolicyLoader", void 0);
      e("SpillRevivePolicyLoader", function () {
        function e() {}
        return e.validate = function (e) {
          try {
            if (!e || "object" != _typeof(e) || Array.isArray(e)) throw new Error("洒出复活策略必须是对象");
            var r = e;
            if ("string" != typeof r.policyVersion || !r.policyVersion.trim()) throw new Error("policyVersion 缺失");
            if ("boolean" != typeof r.enabled) throw new Error("enabled 必须是 boolean");
            if (null !== r.adUnitId && ("string" != typeof r.adUnitId || !r.adUnitId.trim())) throw new Error("adUnitId 必须是 null 或非空字符串");
            if ("spill-revive" !== r.placement) throw new Error("placement 必须为 spill-revive");
            var o = function o(e, _o2, i) {
              var n = r[e];
              if (!Number.isSafeInteger(n) || Number(n) < _o2 || Number(n) > i) throw new Error(e + " 必须是 " + _o2 + ".." + i + " 的整数");
              return Number(n);
            };
            if (1 !== r.maxRevivesPerRun) throw new Error("maxRevivesPerRun 必须为 1");
            var i = o("clearanceDu", 8, 120),
              n = o("autoDropDelayTicks", 0, 240),
              t = o("minForegroundSecondsFirstSession", 0, 600);
            if ("boolean" != typeof r.requireTutorialComplete || "boolean" != typeof r.requireFirstNaturalRunCompleted) throw new Error("资格开关必须是 boolean");
            var a = {
              enabled: r.enabled,
              policyVersion: r.policyVersion,
              adUnitId: r.adUnitId,
              placement: "spill-revive",
              maxRevivesPerRun: 1,
              clearanceDu: i,
              autoDropDelayTicks: n,
              minForegroundSecondsFirstSession: t,
              requireTutorialComplete: r.requireTutorialComplete,
              requireFirstNaturalRunCompleted: r.requireFirstNaturalRunCompleted
            };
            return {
              ok: !0,
              data: Object.freeze(a)
            };
          } catch (e) {
            return {
              ok: !1,
              error: {
                code: "REVIVE_POLICY_INVALID",
                message: e instanceof Error ? e.message : String(e),
                retryable: !1
              }
            };
          }
        }, e;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/SpillReviveService.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./ReviveLedger.ts", "./RewardedAdCoordinator.ts"], function (e) {
  var t, i, n, s, r, h;
  return {
    setters: [function (e) {
      t = e.createClass, i = e.asyncToGenerator, n = e["extends"];
    }, function (e) {
      s = e.cclegacy;
    }, function (e) {
      r = e.ReviveLedger;
    }, function (e) {
      h = e.RewardedAdCoordinator;
    }],
    execute: function execute() {
      s._RF.push({}, "4d2f8sXbJVKA7jnGpD108Ju", "SpillReviveService", void 0);
      var l = function l(e) {
        return JSON.parse(JSON.stringify(e));
      };
      e("SpillReviveService", function () {
        function e(e, t, i) {
          this.phase = "IDLE", this.message = null, this.retrySettle = !1, this.busy = !1, this.stalePending = !1, this.pendingAttempt = null, this.trustedCompletionAttempt = null, this.foregroundSeconds = 0, this.host = null, this.boundRunId = null, this.hostGeneration = 0, this.attemptIdentity = null, this.clearingAttemptId = null, this.env = e, this.repo = t, this.now = i;
        }
        e.create = function (t, i, n) {
          void 0 === n && (n = function n() {
            return Date.now();
          });
          var s = new e(t, i, n),
            r = globalThis;
          return r.__milkteaSpillRevive ? (s.env.provider.dispose(), r.__milkteaSpillRevive) : (r.__milkteaSpillRevive = s, s);
        };
        var s = e.prototype;
        return s.bind = function (e) {
          var t,
            i,
            n,
            s = null != (t = null == (i = e.getActiveRunSnapshot()) ? void 0 : i.runId) ? t : null;
          (this.host !== e || this.boundRunId !== s) && (this.hostGeneration++, this.boundRunId = s, this.busy = !1, this.pendingAttempt = null, this.trustedCompletionAttempt = null, this.attemptIdentity = null, "PREPARING" !== this.phase && "SHOWING" !== this.phase && "SETTLING" !== this.phase || (this.phase = "IDLE", this.message = null, this.retrySettle = !1)), this.host = e;
          var r = e.getBundle(),
            h = null == r ? void 0 : r.profile.rewardedRevive,
            l = e.getActiveRunSnapshot();
          this.stalePending = !(null == h || !h.pendingAttempt || !l || h.pendingAttempt.runId !== l.runId);
          var a,
            o,
            d = l ? null == h || null == (n = h.receipts) ? void 0 : n.find(function (e) {
              return e.runId === l.runId && "spill_revive" === e.rewardKind && 1 === e.amount;
            }) : void 0;
          this.stalePending && l && !d && (this.stalePending = !1, this.clearStalePending(e, {
            attemptId: null != (a = null == h || null == (o = h.pendingAttempt) ? void 0 : o.attemptId) ? a : null,
            runId: l.runId,
            revision: e.getSaveRevision(),
            generation: this.hostGeneration
          }));
          if (l && d) {
            var u = !!(1 === l.revive.used && l.revive.committedReceiptId === d.attemptId) || e.applyCommittedRevive(d.attemptId);
            return this.busy = !1, this.pendingAttempt = null, this.retrySettle = !1, void (u ? (this.trustedCompletionAttempt = null, this.attemptIdentity = null, this.phase = "GRANTED", this.message = "本局复活已生效。") : (this.attemptIdentity = {
              owner: e,
              generation: this.hostGeneration,
              runId: l.runId,
              failureId: d.failureId,
              attemptId: d.attemptId
            }, this.trustedCompletionAttempt = d.attemptId, this.phase = "ERROR", this.retrySettle = !0, this.message = "复活权益已保存，但本次恢复未完成；可重试领取，无需再次观看广告。"));
          }
          this.busy || (this.phase = "IDLE", this.message = this.stalePending ? "上次复活广告未得到可信完成确认，未发放。" : null, this.retrySettle = !1);
        }, s.unbind = function (e) {
          this.host === e && (this.host = null);
        }, s.setForegroundSeconds = function (e) {
          this.foregroundSeconds = Math.max(0, e);
        }, s.dispose = function () {
          this.env.provider.dispose();
        }, s.getView = function () {
          var e,
            t,
            i,
            n,
            s,
            h,
            l,
            a,
            o,
            d = null != (e = null == (t = this.host) ? void 0 : t.getBundle()) ? e : null,
            u = null != (i = null == (n = this.host) ? void 0 : n.getActiveRunSnapshot()) ? i : null,
            p = d ? r.checkOffer({
              policy: this.env.policy,
              capability: this.env.provider.capability(),
              profile: d.profile,
              run: u,
              foregroundSeconds: this.foregroundSeconds,
              tutorialComplete: null != (s = null == (h = this.host) ? void 0 : h.isTutorialComplete()) && s,
              nowMs: this.now()
            }) : {
              allowed: !1,
              block: "NO_ACTIVE_RUN"
            },
            v = null != (l = null == d ? void 0 : d.profile.rewardedRevive) ? l : r.EMPTY;
          return {
            phase: this.phase,
            block: this.stalePending ? "PENDING_ATTEMPT" : p.block,
            message: this.message,
            retrySettle: this.retrySettle,
            capability: this.env.provider.capability(),
            providerName: this.env.provider.providerName,
            usedThisRun: null != (a = null == u ? void 0 : u.revive.used) ? a : 0,
            pendingAttempt: this.stalePending || !(!v.pendingAttempt || !u || v.pendingAttempt.runId !== u.runId),
            simulated: "tap" !== this.env.provider.providerName,
            blockingRunId: this.stalePending && null != (o = null == u ? void 0 : u.runId) ? o : null
          };
        }, s.canOffer = function () {
          var e = this.getView();
          return "IDLE" === e.phase && null === e.block;
        }, s.stillOwns = function (e) {
          var t;
          return this.host === e.owner && this.hostGeneration === e.generation && (null == (t = this.host.getActiveRunSnapshot()) ? void 0 : t.runId) === e.runId;
        }, s.releaseBusy = function (e, t) {
          this.host === e && this.hostGeneration === t && (this.busy = !1);
        }, s.retryWatch = function () {
          if (!(!this.host || this.busy || "ERROR" !== this.phase || this.retrySettle || this.stalePending || this.pendingAttempt)) {
            var e = this.check();
            if (!e.allowed) return this.message = this.blockMessage(e.block), void this.changed();
            this.phase = "OFFER", this.message = null, this.retrySettle = !1, this.host.pauseForRewardedAd(), this.changed();
          }
        }, s.openOffer = function () {
          if (this.host && !this.busy) {
            var e = this.check();
            if (!e.allowed) return this.message = this.blockMessage(e.block), void this.changed();
            this.phase = "OFFER", this.message = null, this.retrySettle = !1, this.host.pauseForRewardedAd(), this.changed();
          }
        }, s.closeOffer = function () {
          !this.host || "OFFER" !== this.phase && "ERROR" !== this.phase || (this.phase = "IDLE", this.message = null, this.retrySettle = !1, this.host.declineSpillRevive(), this.changed());
        }, s.watch = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee40() {
            var e, t, i, s, a, o, d, u, p, v, c, R, m, g, f, I, y, E;
            return _regeneratorRuntime().wrap(function _callee40$(_context41) {
              while (1) switch (_context41.prev = _context41.next) {
                case 0:
                  if (!(this.host && "OFFER" === this.phase && !this.busy)) {
                    _context41.next = 74;
                    break;
                  }
                  e = this.check();
                  if (e.allowed) {
                    _context41.next = 4;
                    break;
                  }
                  return _context41.abrupt("return", (this.message = this.blockMessage(e.block), void this.changed()));
                case 4:
                  if (h.claim("spill-revive")) {
                    _context41.next = 6;
                    break;
                  }
                  return _context41.abrupt("return", (this.message = "另有广告正在进行，请稍后再试。", this.phase = "ERROR", void this.changed()));
                case 6:
                  t = this.host, i = this.hostGeneration;
                  this.busy = !0, this.phase = "PREPARING", this.message = null, this.changed();
                  _context41.prev = 8;
                  _context41.next = 11;
                  return this.host.waitForSaveIdle();
                case 11:
                  if (!(this.host !== t || i !== this.hostGeneration)) {
                    _context41.next = 13;
                    break;
                  }
                  throw new Error("REVIVE_ATTEMPT_OWNER_CHANGED");
                case 13:
                  d = t.getActiveRunSnapshot();
                  if (d) {
                    _context41.next = 16;
                    break;
                  }
                  throw new Error("REVIVE_ATTEMPT_RUN_MISSING");
                case 16:
                  _context41.next = 18;
                  return this.repo.readBundle();
                case 18:
                  u = _context41.sent;
                  if (!(this.host !== t || i !== this.hostGeneration)) {
                    _context41.next = 21;
                    break;
                  }
                  throw new Error("REVIVE_ATTEMPT_OWNER_CHANGED");
                case 21:
                  if (u.ok && u.data.envelope) {
                    v = u.data.envelope.payload;
                    v.profile.activeRunId === d.runId && (null == (p = v.run) ? void 0 : p.runId) === d.runId && u.data.envelope.revision !== t.getSaveRevision() && t.onSpillReviveCommitted(v, u.data.envelope.revision);
                  }
                  c = t.getBundle();
                  if (!(d = t.getActiveRunSnapshot(), !c || null == (s = d) || !s.revive.pendingFailure)) {
                    _context41.next = 25;
                    break;
                  }
                  throw new Error("REVIVE_ATTEMPT_RUN_MISSING");
                case 25:
                  if (!("SUPPORTED" !== this.env.provider.capability())) {
                    _context41.next = 27;
                    break;
                  }
                  throw new Error("REVIVE_AD_UNSUPPORTED");
                case 27:
                  R = function () {
                    var e = globalThis.crypto;
                    if (null != e && e.randomUUID) return e.randomUUID();
                    var t = new Uint8Array(16);
                    if (null != e && e.getRandomValues) e.getRandomValues(t);else for (var i = 0; i < t.length; i++) t[i] = Math.floor(256 * Math.random());
                    t[6] = 15 & t[6] | 64, t[8] = 63 & t[8] | 128;
                    var n = Array.from(t, function (e) {
                      return e.toString(16).padStart(2, "0");
                    }).join("");
                    return n.slice(0, 8) + "-" + n.slice(8, 12) + "-" + n.slice(12, 16) + "-" + n.slice(16, 20) + "-" + n.slice(20);
                  }(), m = r.dayKey(this.now()), g = {
                    attemptId: R,
                    runId: d.runId,
                    failureId: d.revive.pendingFailure.failureId,
                    policyVersion: this.env.policy.policyVersion,
                    amount: 1,
                    dayKey: m,
                    startedAt: this.now()
                  }, f = l(c);
                  f.run = l(d), f.profile.rewardedRevive = n({}, r.normalize(f.profile.rewardedRevive, m), {
                    pendingAttempt: g
                  });
                  _context41.next = 31;
                  return this.repo.commitBundle(t.getSaveRevision(), null != (a = null == (o = t.getBundle()) ? void 0 : o.profile.activeRunId) ? a : d.runId, f);
                case 31:
                  I = _context41.sent;
                  if (!(this.host !== t || i !== this.hostGeneration)) {
                    _context41.next = 34;
                    break;
                  }
                  throw new Error("REVIVE_ATTEMPT_OWNER_CHANGED");
                case 34:
                  if (I.ok) {
                    _context41.next = 36;
                    break;
                  }
                  return _context41.abrupt("return", (this.busy = !1, this.phase = "ERROR", this.message = "无法写入待确认的复活记录，广告未展示。", void this.changed()));
                case 36:
                  t.onSpillReviveCommitted(f, I.data.revision), this.pendingAttempt = R, this.trustedCompletionAttempt = null, this.attemptIdentity = {
                    owner: t,
                    generation: i,
                    runId: d.runId,
                    failureId: d.revive.pendingFailure.failureId,
                    attemptId: R
                  };
                  _context41.next = 39;
                  return this.env.provider.prepare();
                case 39:
                  y = _context41.sent;
                  if (!(this.host !== t || i !== this.hostGeneration)) {
                    _context41.next = 42;
                    break;
                  }
                  throw new Error("REVIVE_ATTEMPT_OWNER_CHANGED");
                case 42:
                  if (y.ok) {
                    _context41.next = 48;
                    break;
                  }
                  _context41.next = 45;
                  return this.clearPending("复活广告暂时无法加载，未发放奖励。");
                case 45:
                  if (_context41.sent) {
                    _context41.next = 47;
                    break;
                  }
                  throw new Error("REVIVE_PENDING_CLEAR_FAILED");
                case 47:
                  return _context41.abrupt("return", void this.releaseBusy(t, i));
                case 48:
                  this.phase = "SHOWING", this.changed();
                  _context41.next = 51;
                  return this.env.provider.show(R);
                case 51:
                  E = _context41.sent;
                  if (!(this.host !== t || i !== this.hostGeneration)) {
                    _context41.next = 54;
                    break;
                  }
                  return _context41.abrupt("return");
                case 54:
                  if (!("COMPLETED" !== E.kind)) {
                    _context41.next = 60;
                    break;
                  }
                  _context41.next = 57;
                  return this.clearPending("CANCELLED" === E.kind ? "观看未完成，未发放复活。" : "广告播放失败，未发放复活。");
                case 57:
                  if (_context41.sent) {
                    _context41.next = 59;
                    break;
                  }
                  throw new Error("REVIVE_PENDING_CLEAR_FAILED");
                case 59:
                  return _context41.abrupt("return", void this.releaseBusy(t, i));
                case 60:
                  this.trustedCompletionAttempt = R;
                  this.phase = "SETTLING";
                  this.changed();
                  _context41.next = 65;
                  return this.settle(R);
                case 65:
                  this.releaseBusy(t, i);
                  _context41.next = 71;
                  break;
                case 68:
                  _context41.prev = 68;
                  _context41.t0 = _context41["catch"](8);
                  this.host === t && i === this.hostGeneration && (this.phase = "ERROR", this.retrySettle = !!this.pendingAttempt && this.trustedCompletionAttempt === this.pendingAttempt, this.message = "复活广告流程暂时未完成；存档保持待确认状态，可重试或放弃。", this.changed());
                case 71:
                  _context41.prev = 71;
                  this.host === t && i === this.hostGeneration && "SHOWING" !== this.phase && (this.busy = !1), h.release("spill-revive");
                  return _context41.finish(71);
                case 74:
                case "end":
                  return _context41.stop();
              }
            }, _callee40, this, [[8, 68, 71, 74]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), s.retrySettlement = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee41() {
            var e, t, i, n, s, h, l, a, o, d, u, p, v, c;
            return _regeneratorRuntime().wrap(function _callee41$(_context42) {
              while (1) switch (_context42.prev = _context42.next) {
                case 0:
                  e = this.attemptIdentity;
                  if (!(this.host && !this.busy && e && this.trustedCompletionAttempt === e.attemptId)) {
                    _context42.next = 35;
                    break;
                  }
                  t = this.host, i = this.hostGeneration;
                  this.busy = !0, this.phase = "SETTLING", this.message = null, this.changed();
                  _context42.prev = 4;
                  _context42.next = 7;
                  return this.repo.readBundle();
                case 7:
                  s = _context42.sent;
                  if (this.stillOwns(e)) {
                    _context42.next = 10;
                    break;
                  }
                  return _context42.abrupt("return");
                case 10:
                  if (!(!s.ok || !s.data.envelope)) {
                    _context42.next = 12;
                    break;
                  }
                  return _context42.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "无法读取最新存档，可稍后重试领取。", void this.changed()));
                case 12:
                  h = s.data.envelope, l = h.payload, a = l.profile.rewardedRevive, o = l.run;
                  if (!r.hasReceipt(a, e.attemptId)) {
                    _context42.next = 20;
                    break;
                  }
                  d = a.receipts.find(function (t) {
                    return t.attemptId === e.attemptId;
                  }), u = !!d && d.runId === e.runId && d.failureId === e.failureId && "spill_revive" === d.rewardKind && 1 === d.amount, p = !!o && o.runId === e.runId && 1 === o.revive.used && o.revive.committedReceiptId === e.attemptId;
                  if (!(!u || !p)) {
                    _context42.next = 17;
                    break;
                  }
                  return _context42.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "复活凭证与当前局不匹配，未应用。", void this.changed()));
                case 17:
                  if (!(e.owner.onSpillReviveCommitted(l, h.revision), !this.stillOwns(e))) {
                    _context42.next = 19;
                    break;
                  }
                  return _context42.abrupt("return");
                case 19:
                  return _context42.abrupt("return", e.owner.applyCommittedRevive(e.attemptId) ? (this.pendingAttempt = null, this.stalePending = !1, this.attemptIdentity = null, this.phase = "GRANTED", this.message = null, this.retrySettle = !1, void this.changed()) : (this.phase = "ERROR", this.retrySettle = !0, this.message = "复活凭证已保存但应用失败，可稍后重试领取。", void this.changed()));
                case 20:
                  v = a.pendingAttempt, c = this.host.getActiveRunSnapshot();
                  if (!(!v || v.attemptId !== e.attemptId || v.runId !== e.runId || v.failureId !== e.failureId || !c || c.runId !== e.runId || 0 !== c.revive.used || (null == (n = c.revive.pendingFailure) ? void 0 : n.failureId) !== e.failureId)) {
                    _context42.next = 23;
                    break;
                  }
                  return _context42.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "找不到本局待确认的复活记录，未发放。", void this.changed()));
                case 23:
                  if (!(e.owner.onSpillReviveCommitted(l, h.revision), !this.stillOwns(e))) {
                    _context42.next = 25;
                    break;
                  }
                  return _context42.abrupt("return");
                case 25:
                  _context42.next = 27;
                  return this.settle(e.attemptId);
                case 27:
                  _context42.next = 32;
                  break;
                case 29:
                  _context42.prev = 29;
                  _context42.t0 = _context42["catch"](4);
                  this.stillOwns(e) && (this.phase = "ERROR", this.retrySettle = !0, this.message = "复活保存仍未完成，可稍后重试。", this.changed());
                case 32:
                  _context42.prev = 32;
                  this.releaseBusy(t, i);
                  return _context42.finish(32);
                case 35:
                case "end":
                  return _context42.stop();
              }
            }, _callee41, this, [[4, 29, 32, 35]]);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), s.abandonPending = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee42() {
            var e, t, i;
            return _regeneratorRuntime().wrap(function _callee42$(_context43) {
              while (1) switch (_context43.prev = _context43.next) {
                case 0:
                  if (!(this.host && !this.busy)) {
                    _context43.next = 10;
                    break;
                  }
                  e = this.host, t = this.hostGeneration;
                  this.busy = !0;
                  _context43.next = 5;
                  return this.clearPending("已放弃未确认的复活奖励。", !1);
                case 5:
                  i = _context43.sent;
                  if (!(this.host === e && t === this.hostGeneration)) {
                    _context43.next = 10;
                    break;
                  }
                  if (i) {
                    _context43.next = 9;
                    break;
                  }
                  return _context43.abrupt("return", (this.releaseBusy(e, t), this.phase = "ERROR", this.message = "放弃操作未能保存，请重试。", void this.changed()));
                case 9:
                  this.stalePending = !1, this.pendingAttempt = null, this.trustedCompletionAttempt = null, this.attemptIdentity = null, this.retrySettle = !1, this.releaseBusy(e, t), this.host.declineSpillRevive(), this.changed();
                case 10:
                case "end":
                  return _context43.stop();
              }
            }, _callee42, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), s.acknowledgeGrant = function () {
          this.host && "GRANTED" === this.phase && (this.phase = "IDLE", this.message = null, this.changed(), this.host.resumeFromRewardedAd("本局已复活，点击继续。"));
        }, s.check = function () {
          var e,
            t,
            i,
            n,
            s,
            h,
            l = null != (e = null == (t = this.host) ? void 0 : t.getBundle()) ? e : null,
            a = null != (i = null == (n = this.host) ? void 0 : n.getActiveRunSnapshot()) ? i : null;
          return l && a ? r.checkOffer({
            policy: this.env.policy,
            capability: this.env.provider.capability(),
            profile: l.profile,
            run: a,
            foregroundSeconds: this.foregroundSeconds,
            tutorialComplete: null != (s = null == (h = this.host) ? void 0 : h.isTutorialComplete()) && s,
            nowMs: this.now()
          }) : {
            allowed: !1,
            block: "NO_ACTIVE_RUN"
          };
        }, s.clearStalePending = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee43(e, t) {
            var i, n, s, h, a, o, d;
            return _regeneratorRuntime().wrap(function _callee43$(_context44) {
              while (1) switch (_context44.prev = _context44.next) {
                case 0:
                  if (!(t.attemptId && this.clearingAttemptId !== t.attemptId)) {
                    _context44.next = 26;
                    break;
                  }
                  this.clearingAttemptId = t.attemptId;
                  _context44.prev = 2;
                  _context44.next = 5;
                  return this.repo.readBundle();
                case 5:
                  s = _context44.sent;
                  if (!(!s.ok || !s.data.envelope)) {
                    _context44.next = 8;
                    break;
                  }
                  return _context44.abrupt("return");
                case 8:
                  h = s.data.envelope.payload, a = null == (i = h.profile.rewardedRevive) ? void 0 : i.pendingAttempt;
                  if (!(!a || a.attemptId !== t.attemptId || a.runId !== t.runId)) {
                    _context44.next = 11;
                    break;
                  }
                  return _context44.abrupt("return");
                case 11:
                  o = l(h);
                  o.profile.rewardedRevive = r.clearPending(o.profile.rewardedRevive);
                  _context44.next = 15;
                  return this.repo.commitBundle(s.data.envelope.revision, h.profile.activeRunId, o);
                case 15:
                  d = _context44.sent;
                  if (d.ok) {
                    _context44.next = 18;
                    break;
                  }
                  return _context44.abrupt("return");
                case 18:
                  this.host === e && this.hostGeneration === t.generation && (null == (n = e.getActiveRunSnapshot()) ? void 0 : n.runId) === t.runId && e.onSpillReviveCommitted(o, d.data.revision);
                  _context44.next = 23;
                  break;
                case 21:
                  _context44.prev = 21;
                  _context44.t0 = _context44["catch"](2);
                case 23:
                  _context44.prev = 23;
                  this.clearingAttemptId === t.attemptId && (this.clearingAttemptId = null);
                  return _context44.finish(23);
                case 26:
                case "end":
                  return _context44.stop();
              }
            }, _callee43, this, [[2, 21, 23, 26]]);
          }));
          return function (t, i) {
            return e.apply(this, arguments);
          };
        }(), s.clearPending = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee44(e, t) {
            var i, n, s, h, a, o, d, u, p;
            return _regeneratorRuntime().wrap(function _callee44$(_context45) {
              while (1) switch (_context45.prev = _context45.next) {
                case 0:
                  void 0 === t && (t = !1);
                  s = this.host, h = this.hostGeneration;
                  if (s) {
                    _context45.next = 4;
                    break;
                  }
                  return _context45.abrupt("return", !1);
                case 4:
                  a = null != (i = null == (n = s.getActiveRunSnapshot()) ? void 0 : n.runId) ? i : null, o = s.getBundle();
                  if (!o) {
                    _context45.next = 22;
                    break;
                  }
                  p = l(o);
                  p.profile.rewardedRevive = r.clearPending(p.profile.rewardedRevive);
                  _context45.prev = 8;
                  _context45.next = 11;
                  return this.repo.commitBundle(s.getSaveRevision(), o.profile.activeRunId, p);
                case 11:
                  u = _context45.sent;
                  _context45.next = 17;
                  break;
                case 14:
                  _context45.prev = 14;
                  _context45.t0 = _context45["catch"](8);
                  return _context45.abrupt("return", !1);
                case 17:
                  if (!(this.host !== s || h !== this.hostGeneration || !u.ok)) {
                    _context45.next = 19;
                    break;
                  }
                  return _context45.abrupt("return", !1);
                case 19:
                  if (!(null !== a && (null == (d = s.getActiveRunSnapshot()) ? void 0 : d.runId) !== a)) {
                    _context45.next = 21;
                    break;
                  }
                  return _context45.abrupt("return", !1);
                case 21:
                  s.onSpillReviveCommitted(p, u.data.revision);
                case 22:
                  return _context45.abrupt("return", (this.pendingAttempt = null, this.phase = "ERROR", this.retrySettle = !1, this.message = e, this.changed(), this.trustedCompletionAttempt = null, this.attemptIdentity = null, t && s.declineSpillRevive(), !0));
                case 23:
                case "end":
                  return _context45.stop();
              }
            }, _callee44, this, [[8, 14]]);
          }));
          return function (t, i) {
            return e.apply(this, arguments);
          };
        }(), s.settle = function () {
          var e = i( /*#__PURE__*/_regeneratorRuntime().mark(function _callee45(e) {
            var t, i, n, s, h, a, o, d, u, p, v, c, R, m, g, f, I, y, E;
            return _regeneratorRuntime().wrap(function _callee45$(_context46) {
              while (1) switch (_context46.prev = _context46.next) {
                case 0:
                  h = this.host, a = this.hostGeneration;
                  if (!h) {
                    _context46.next = 45;
                    break;
                  }
                  o = h.getBundle(), d = h.getActiveRunSnapshot();
                  _context46.t0 = o && d;
                  if (!_context46.t0) {
                    _context46.next = 8;
                    break;
                  }
                  _context46.next = 7;
                  return h.waitForSaveIdle();
                case 7:
                  _context46.t0 = this.host === h && a === this.hostGeneration && (null == (t = h.getActiveRunSnapshot()) ? void 0 : t.runId) === d.runId && (o = h.getBundle());
                case 8:
                  if (!_context46.t0) {
                    _context46.next = 45;
                    break;
                  }
                  u = o.profile.rewardedRevive;
                  if (!r.hasReceipt(u, e)) {
                    _context46.next = 17;
                    break;
                  }
                  v = u.receipts.find(function (t) {
                    return t.attemptId === e;
                  }), c = o.run;
                  if (!(!v || v.runId !== d.runId || v.failureId !== (null == (p = d.revive.pendingFailure) ? void 0 : p.failureId) || "spill_revive" !== v.rewardKind || 1 !== v.amount || !c || c.runId !== d.runId || 1 !== c.revive.used || c.revive.committedReceiptId !== e)) {
                    _context46.next = 14;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "复活凭证与当前局不匹配，未应用。", void this.changed()));
                case 14:
                  if (!(h.onSpillReviveCommitted(o, h.getSaveRevision()), this.host !== h || a !== this.hostGeneration)) {
                    _context46.next = 16;
                    break;
                  }
                  return _context46.abrupt("return");
                case 16:
                  return _context46.abrupt("return", h.applyCommittedRevive(e) ? (this.phase = "GRANTED", this.message = null, this.retrySettle = !1, this.pendingAttempt = null, this.attemptIdentity = null, void this.changed()) : (this.phase = "ERROR", this.retrySettle = !0, this.message = "复活权益已保存，但本次恢复未完成；可重试领取，无需再次观看广告。", void this.changed()));
                case 17:
                  if (!((null == (i = u.pendingAttempt) ? void 0 : i.attemptId) !== e || u.pendingAttempt.runId !== d.runId)) {
                    _context46.next = 19;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "找不到本局待确认的复活记录，未发放。", void this.changed()));
                case 19:
                  if (!(0 !== d.revive.used || !d.revive.pendingFailure)) {
                    _context46.next = 21;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = "本局已不满足复活条件，未发放。", void this.changed()));
                case 21:
                  R = u.pendingAttempt, m = h.projectRevive(e);
                  if (m.ok) {
                    _context46.next = 24;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !1, this.message = m.error.message, void this.changed()));
                case 24:
                  g = r.grant(u, r.receiptFor(R, this.now()), d.runId), f = l(o);
                  f.profile.rewardedRevive = g, f.run = m.data;
                  _context46.next = 28;
                  return this.repo.commitBundle(h.getSaveRevision(), d.runId, f);
                case 28:
                  I = _context46.sent;
                  if (!(this.host === h && a === this.hostGeneration && (null == (n = h.getActiveRunSnapshot()) ? void 0 : n.runId) === d.runId)) {
                    _context46.next = 45;
                    break;
                  }
                  if (I.ok) {
                    _context46.next = 32;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "广告已完成，但复活存档保存失败；请稍后重试领取。", void this.changed()));
                case 32:
                  h.onSpillReviveCommitted(f, I.data.revision);
                  _context46.next = 35;
                  return this.repo.readBundle();
                case 35:
                  y = _context46.sent;
                  if (!(this.host === h && a === this.hostGeneration)) {
                    _context46.next = 45;
                    break;
                  }
                  if (!(!y.ok || !y.data.envelope)) {
                    _context46.next = 39;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "复活存档回读失败，可重试领取。", void this.changed()));
                case 39:
                  E = y.data.envelope.payload;
                  if (!(!r.hasReceipt(E.profile.rewardedRevive, e) || (null == (s = E.run) ? void 0 : s.runId) !== d.runId || 1 !== E.run.revive.used || E.run.revive.committedReceiptId !== e)) {
                    _context46.next = 42;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "复活账本与本局状态未能一致回读，可重试领取。", void this.changed()));
                case 42:
                  if (!(h.onSpillReviveCommitted(E, y.data.envelope.revision), !h.applyCommittedRevive(e))) {
                    _context46.next = 44;
                    break;
                  }
                  return _context46.abrupt("return", (this.phase = "ERROR", this.retrySettle = !0, this.message = "复活已保存，但应用失败，可重试领取。", void this.changed()));
                case 44:
                  this.pendingAttempt = null, this.stalePending = !1, this.attemptIdentity = null, this.phase = "GRANTED", this.message = null, this.retrySettle = !1, this.changed();
                case 45:
                case "end":
                  return _context46.stop();
              }
            }, _callee45, this);
          }));
          return function (t) {
            return e.apply(this, arguments);
          };
        }(), s.changed = function () {
          var e;
          null == (e = this.host) || e.onSpillReviveChanged();
        }, s.blockMessage = function (e) {
          switch (e) {
            case "POLICY_DISABLED":
              return "洒出复活广告尚未开启";
            case "AD_UNCONFIGURED":
              return "未配置真实复活广告位";
            case "AD_UNSUPPORTED":
              return "当前环境不支持激励广告";
            case "NO_ACTIVE_RUN":
            case "NOT_SPILL_PENDING":
              return "当前没有可复活的洒出局";
            case "RUN_LIMIT":
              return "本局已使用过复活";
            case "TUTORIAL_REQUIRED":
              return "完成教程后可观看复活广告";
            case "FIRST_RUN_REQUIRED":
              return "完成一局真实游戏后可观看复活广告";
            case "FOREGROUND_REQUIRED":
              return "游戏时间稍短，暂不可观看复活广告";
            case "PENDING_ATTEMPT":
              return "有未确认的复活奖励";
            default:
              return "暂不可复活";
          }
        }, t(e, [{
          key: "policy",
          get: function get() {
            return this.env.policy;
          }
        }]), e;
      }());
      s._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/StartupTrace.ts", ["./rollupPluginModLoBabelHelpers.js", "cc", "./DiagnosticRing.ts"], function (t) {
  var e, r, n;
  return {
    setters: [function (t) {
      e = t.createClass;
    }, function (t) {
      r = t.cclegacy;
    }, function (t) {
      n = t.DiagnosticRing;
    }],
    execute: function execute() {
      function i() {
        try {
          return "undefined" != typeof performance && "function" == typeof performance.now ? performance.now() : Date.now();
        } catch (t) {
          return 0;
        }
      }
      r._RF.push({}, "e8167XdXdJCdJzIBgd+RULH", "StartupTrace", void 0);
      t("StartupTrace", function () {
        function t(t) {
          this.ring = new n(32), this.traceId = 0, this.ownerEpoch = 0, this.bootAtMs = i(), this.foregroundMs = 0, this.readBuildId = t;
        }
        var r = t.prototype;
        return r.beginTrace = function (t) {
          return this.ownerEpoch = Number.isSafeInteger(t) ? t : 0, this.traceId += 1, this.traceId;
        }, r.tickForeground = function (t) {
          !Number.isFinite(t) || t <= 0 || (this.foregroundMs += t);
        }, r.stage = function (t, e, r, n, i) {
          void 0 === n && (n = this.ownerEpoch), void 0 === i && (i = this.traceId);
          try {
            var o,
              s = {
                buildId: this.safeBuildId(),
                traceId: i,
                ownerEpoch: Number.isSafeInteger(n) ? n : 0,
                phase: String(t).slice(0, 48),
                result: e,
                elapsedMs: this.elapsed(),
                foregroundElapsedMs: Math.round(this.foregroundMs)
              };
            null != r && r.code && (s.code = this.summary(r.code)), null != r && r.assetId && (s.assetId = this.summary(r.assetId)), null != r && r.bundleName && (s.bundleName = this.summary(r.bundleName)), null != r && r.stack && (s.stack = this.summary(r.stack)), void 0 !== (null == r ? void 0 : r.error) && (s.code = null != (o = s.code) ? o : this.summary(r.error)), this.ring.append(s);
          } catch (t) {}
        }, r.latest = function (t) {
          void 0 === t && (t = 32);
          try {
            var e = Number.isSafeInteger(t) ? Math.max(1, Math.min(32, t)) : 32;
            return this.ring.page(Math.max(0, this.ring.latestSeq - e), e).records;
          } catch (t) {
            return [];
          }
        }, r.exportJson = function () {
          try {
            return JSON.stringify(this.latest(32).map(function (t) {
              return t.value;
            }));
          } catch (t) {
            return "[]";
          }
        }, r.elapsed = function () {
          try {
            return Math.max(0, Math.round(i() - this.bootAtMs));
          } catch (t) {
            return 0;
          }
        }, r.safeBuildId = function () {
          try {
            return this.readBuildId();
          } catch (t) {
            return "unknown";
          }
        }, r.summary = function (t) {
          var e = t instanceof Error ? t.name + ": " + t.message : String(t);
          return e.length <= 512 ? e : e.slice(0, 509) + "...";
        }, e(t, [{
          key: "currentTraceId",
          get: function get() {
            return this.traceId;
          }
        }, {
          key: "currentOwnerEpoch",
          get: function get() {
            return this.ownerEpoch;
          }
        }, {
          key: "foregroundElapsedMs",
          get: function get() {
            return this.foregroundMs;
          }
        }, {
          key: "overflowCount",
          get: function get() {
            try {
              return this.ring.overflowCount;
            } catch (t) {
              return 0;
            }
          }
        }]), t;
      }());
      r._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/TapRewardedAdProvider.ts", ["./rollupPluginModLoBabelHelpers.js", "cc"], function (e) {
  var n, t, i;
  return {
    setters: [function (e) {
      n = e.createForOfIteratorHelperLoose, t = e.asyncToGenerator;
    }, function (e) {
      i = e.cclegacy;
    }],
    execute: function execute() {
      i._RF.push({}, "16135y3iulEAaKxVZxYy2Hf", "TapRewardedAdProvider", void 0);
      var r = function r() {
        return globalThis.tap;
      };
      e("TapRewardedAdProvider", function () {
        function e(e) {
          this.providerName = "tap", this.active = null, this.generation = 0, this.disposed = !1, this.policy = e;
        }
        var i = e.prototype;
        return i.capability = function () {
          var e;
          return this.policy.enabled ? this.policy.adUnitId ? "function" == typeof (null == (e = r()) ? void 0 : e.createRewardedVideoAd) ? "SUPPORTED" : "UNSUPPORTED" : "UNCONFIGURED" : "DISABLED";
        }, i.prepare = function () {
          var e = t( /*#__PURE__*/_regeneratorRuntime().mark(function _callee46() {
            var e, n;
            return _regeneratorRuntime().wrap(function _callee46$(_context47) {
              while (1) switch (_context47.prev = _context47.next) {
                case 0:
                  e = this;
                  if (!this.disposed) {
                    _context47.next = 3;
                    break;
                  }
                  return _context47.abrupt("return", this.fail("REWARD_AD_DISPOSED"));
                case 3:
                  n = this.getInstance();
                  return _context47.abrupt("return", n ? n.loaded ? {
                    ok: !0,
                    data: void 0
                  } : n.preparing ? n.preparing : "function" != typeof n.instance.load ? (this.release(n), this.fail("REWARD_AD_LOAD_UNSUPPORTED")) : (n.preparing = new Promise(function (t) {
                    var i = !1,
                      r = function (_r) {
                        function r(_x, _x2) {
                          return _r.apply(this, arguments);
                        }
                        r.toString = function () {
                          return _r.toString();
                        };
                        return r;
                      }(function (r, o) {
                        void 0 === o && (o = "REWARD_AD_LOAD_FAILED"), i || n.closed || (i = !0, e.clearLoadTimer(n), n.preparing = null, n.loaded = r, n.loadFinish = null, t(r ? {
                          ok: !0,
                          data: void 0
                        } : e.fail(o)), r || (e.release(n), e.active === n && (e.active = null)));
                      });
                    n.loadFinish = function (e, n) {
                      return r(e, n);
                    }, n.loadTimer = setTimeout(function () {
                      return r(!1, "REWARD_AD_LOAD_TIMEOUT");
                    }, 1e4);
                    try {
                      var o = n.instance.load();
                      if (!o || "function" != typeof o.then) return void r(!1, "REWARD_AD_LOAD_CONTRACT");
                      o.then(function () {
                        return r(!0);
                      }, function () {
                        return r(!1, "REWARD_AD_LOAD_REJECTED");
                      });
                    } catch (e) {
                      r(!1, "REWARD_AD_LOAD_THROW");
                    }
                  }), n.preparing) : this.fail("REWARD_AD_UNSUPPORTED"));
                case 5:
                case "end":
                  return _context47.stop();
              }
            }, _callee46, this);
          }));
          return function () {
            return e.apply(this, arguments);
          };
        }(), i.show = function (e) {
          var n = this;
          if (this.disposed) return Promise.resolve({
            kind: "FAILED",
            attemptId: e,
            errorCode: "REWARD_AD_DISPOSED"
          });
          var t = this.active;
          return t && !t.closed && t.loaded && "function" == typeof t.instance.show ? t.pending ? Promise.resolve({
            kind: "UNAVAILABLE",
            attemptId: e,
            errorCode: "REWARD_AD_BUSY"
          }) : new Promise(function (i) {
            t.pending = {
              attemptId: e,
              resolve: i
            };
            try {
              var r = t.instance.show();
              r && "function" == typeof r.then ? r["catch"](function () {
                return n.finish(t, {
                  kind: "FAILED",
                  attemptId: e,
                  errorCode: "REWARD_AD_SHOW_REJECTED"
                });
              }) : n.finish(t, {
                kind: "FAILED",
                attemptId: e,
                errorCode: "REWARD_AD_SHOW_CONTRACT"
              });
            } catch (i) {
              n.finish(t, {
                kind: "FAILED",
                attemptId: e,
                errorCode: "REWARD_AD_SHOW_THROW"
              });
            }
          }) : Promise.resolve({
            kind: "UNAVAILABLE",
            attemptId: e,
            errorCode: "REWARD_AD_NOT_PREPARED"
          });
        }, i.getInstance = function () {
          var e = this;
          if (this.active && !this.active.closed) return this.active;
          var n,
            t = r();
          if (null == t || !t.createRewardedVideoAd || !this.policy.adUnitId) return null;
          try {
            n = t.createRewardedVideoAd({
              adUnitId: this.policy.adUnitId,
              multiton: !0
            });
          } catch (e) {
            return null;
          }
          var i = {
            generation: ++this.generation,
            instance: n,
            loaded: !1,
            preparing: null,
            pending: null,
            loadFinish: null,
            loadTimer: null,
            closed: !1,
            released: !1,
            destroyed: !1,
            registered: [],
            onLoad: function onLoad() {},
            onError: function onError() {},
            onClose: function onClose() {}
          };
          if (!(n.onLoad && n.offLoad && n.onError && n.offError && n.onClose && n.offClose && n.load && n.show)) return this.release(i), null;
          i.onLoad = function () {
            i.closed || (i.loaded = !0, null == i.loadFinish || i.loadFinish(!0));
          }, i.onError = function () {
            i.closed || (i.loaded = !1, i.pending ? e.finish(i, {
              kind: "FAILED",
              attemptId: i.pending.attemptId,
              errorCode: "REWARD_AD_NATIVE_ERROR"
            }) : null == i.loadFinish || i.loadFinish(!1, "REWARD_AD_LOAD_ERROR"));
          }, i.onClose = function (n) {
            if (!i.closed) {
              var t = i.pending;
              t && e.finish(i, !0 === (null == n ? void 0 : n.isEnded) ? {
                kind: "COMPLETED",
                attemptId: t.attemptId
              } : {
                kind: "CANCELLED",
                attemptId: t.attemptId,
                errorCode: "REWARD_AD_CLOSED_EARLY"
              });
            }
          };
          var o = function o(e, n) {
            try {
              return n(), i.registered.push(e), !0;
            } catch (e) {
              return !1;
            }
          };
          return o("load", function () {
            return n.onLoad(i.onLoad);
          }) && o("error", function () {
            return n.onError(i.onError);
          }) && o("close", function () {
            return n.onClose(i.onClose);
          }) ? (this.active = i, i) : (this.release(i), null);
        }, i.finish = function (e, n) {
          var t = e.pending;
          !e.closed && t && t.attemptId === n.attemptId && (e.closed = !0, e.pending = null, e.loaded = !1, e.loadFinish = null, t.resolve(n), this.release(e));
        }, i.release = function (e) {
          if (!e.released) {
            e.released = !0, e.closed = !0, this.clearLoadTimer(e), e.loadFinish = null, e.preparing = null;
            for (var t, i = n(e.registered); !(t = i()).done;) {
              var r = t.value;
              try {
                "load" === r ? null == e.instance.offLoad || e.instance.offLoad(e.onLoad) : "error" === r ? null == e.instance.offError || e.instance.offError(e.onError) : null == e.instance.offClose || e.instance.offClose(e.onClose);
              } catch (e) {}
            }
            if (e.registered = [], !e.destroyed) {
              e.destroyed = !0;
              try {
                null == e.instance.destroy || e.instance.destroy();
              } catch (e) {}
            }
            this.active === e && (this.active = null);
          }
        }, i.clearLoadTimer = function (e) {
          null !== e.loadTimer && (clearTimeout(e.loadTimer), e.loadTimer = null);
        }, i.fail = function (e) {
          return {
            ok: !1,
            error: {
              code: e,
              message: e,
              retryable: !0
            }
          };
        }, i.dispose = function () {
          if (!this.disposed) {
            this.disposed = !0;
            var e = this.active;
            this.active = null, e && (e.pending ? this.finish(e, {
              kind: "FAILED",
              attemptId: e.pending.attemptId,
              errorCode: "REWARD_AD_DISPOSED"
            }) : null == e.loadFinish || e.loadFinish(!1, "REWARD_AD_DISPOSED"), this.release(e));
          }
        }, e;
      }());
      i._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/types.ts", ["cc"], function () {
  var t;
  return {
    setters: [function (c) {
      t = c.cclegacy;
    }],
    execute: function execute() {
      t._RF.push({}, "1ccf1JIhlBUXoLO5H6/hEvH", "types", void 0), t._RF.pop();
    }
  };
});
System.register("chunks:///_virtual/Viewport.ts", ["cc"], function (e) {
  var t, n, i, o, a, r, h;
  return {
    setters: [function (e) {
      t = e.cclegacy, n = e.view, i = e.Node, o = e.UITransform, a = e.Canvas, r = e.Camera, h = e.ResolutionPolicy;
    }],
    execute: function execute() {
      e({
        configureViewport: function configureViewport(e, t) {
          var c, d, s;
          n.enableRetina(!1);
          var g = function g() {
              var e = n.getFrameSize(),
                i = e.height / e.width >= t.height_du / t.width_du ? h.FIXED_WIDTH : h.SHOW_ALL;
              n.setDesignResolutionSize(t.width_du, t.height_du, i);
            },
            v = u.get(e);
          v && n.off("canvas-resize", v);
          g(), n.on("canvas-resize", g), u.set(e, g), v || e.once(i.EventType.NODE_DESTROYED, function () {
            var t = u.get(e);
            t && n.off("canvas-resize", t), u["delete"](e);
          });
          (null != (c = e.getComponent(o)) ? c : e.addComponent(o)).setContentSize(t.width_du, t.height_du);
          var l = null != (d = e.getComponent(a)) ? d : e.addComponent(a),
            p = null == (s = e.scene.getChildByName("Main Camera")) ? void 0 : s.getComponent(r);
          if (!p) throw new Error("场景缺少Main Camera");
          p.projection = r.ProjectionType.ORTHO, l.cameraComponent = p, l.alignCanvasWithScreen = !0;
        },
        gameUiPoint: function gameUiPoint(e, t) {
          var i = n.getVisibleSize();
          return {
            x: e.x - (i.width - t.width_du) / 2,
            y: e.y - (i.height - t.height_du) / 2
          };
        },
        presentationSize: function presentationSize() {
          var e = n.getVisibleSize();
          return {
            width: e.width,
            height: e.height
          };
        }
      }), t._RF.push({}, "1a01eI0KgdN4730AvoCX3Pv", "Viewport", void 0);
      var u = new WeakMap();
      t._RF.pop();
    }
  };
});
(function (r) {
  r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main');
})(function (mid, cid) {
  System.register(mid, [cid], function (_export, _context) {
    return {
      setters: [function (_m) {
        var _exportObj = {};
        for (var _key in _m) {
          if (_key !== "default" && _key !== "__esModule") _exportObj[_key] = _m[_key];
        }
        _export(_exportObj);
      }],
      execute: function execute() {}
    };
  });
});