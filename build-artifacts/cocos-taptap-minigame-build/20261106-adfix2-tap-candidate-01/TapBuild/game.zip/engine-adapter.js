function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
!function i(b, d, f) {
  function g(k, l) {
    if (!d[k]) {
      if (!b[k]) {
        var m = 'function' == typeof require && require;
        if (!l && m) return m(k, !0x0);
        if (h) return h(k, !0x0);
        throw (l = new Error('Cannot\x20find\x20module\x20\x27' + k + '\x27'))['code'] = 'MODULE_NOT_FOUND', l;
      }
      m = d[k] = {
        'exports': {}
      }, b[k][0x0]['call'](m['exports'], function (p) {
        return g(b[k][0x1][p] || p);
      }, m, m['exports'], i, b, d, f);
    }
    return d[k]['exports'];
  }
  for (var h = 'function' == typeof require && require, j = 0x0; j < f['length']; j++) g(f[j]);
  return g;
}({
  0x1: [function (j, q, z) {
    var G = j('./cache-manager'),
      H = window['fsUtils'],
      J = H['fs'],
      L = H['downloadFile'],
      N = H['readText'],
      Q = H['readArrayBuffer'],
      R = H['readJson'],
      U = H['loadSubpackage'],
      V = H['getUserDataPath'],
      W = H['exists'],
      X = /^https?:\/\/.*/,
      Y = cc['assetManager']['downloader'],
      H = cc['assetManager']['parser'],
      Z = cc['assetManager']['presets'],
      a0 = (Y['maxConcurrency'] = 0xc, Y['maxRequestsPerFrame'] = 0x40, Z['scene']['maxConcurrency'] = 0xc, Z['scene']['maxRequestsPerFrame'] = 0x40, {}),
      a1 = cc['sys'];
    function a2(al, am, an) {
      X['test'](al) ? an && an(new Error('Can\x20not\x20load\x20remote\x20scripts')) : (a1['platform'] !== a1['Platform']['TAOBAO_CREATIVE_APP'] && j('../../../'['concat'](al)), an && an(null));
    }
    function a3(al, am, an) {
      cc['AudioPlayer']['load'](al)['then'](function (ao) {
        ao = {
          'player': ao,
          'url': al,
          'duration': ao['duration'],
          'type': ao['type']
        }, an(null, ao);
      })['catch'](function (ao) {
        an(ao);
      });
    }
    function a4(al, am, an, ao, ap) {
      var aq = function (ar, as) {
        var at = !0x1,
          au = !0x1;
        return !ar['startsWith'](V()) && X['test'](ar) ? as['reload'] || ((as = G['cachedFiles']['get'](ar)) ? (au = !0x0, ar = as['url']) : (as = G['tempFiles']['get'](ar)) && (at = !0x0, ar = as)) : at = !0x0, {
          'url': ar,
          'inLocal': at,
          'inCache': au
        };
      }(al, an);
      aq['inLocal'] ? am(aq['url'], an, ap) : aq['inCache'] ? (G['updateLastTime'](al), am(aq['url'], an, function (ar, as) {
        ar && G['removeCache'](al), ap(ar, as);
      })) : L(al, null, an['header'], ao, function (ar, as) {
        ar ? ap(ar, null) : am(as, an, function (at, au) {
          at || (G['tempFiles']['add'](al, as), G['cacheFile'](al, as, an['cacheEnabled'], an['__cacheBundleRoot__'], !0x0)), ap(at, au);
        });
      });
    }
    function a5(al, am, an) {
      Q(al, an);
    }
    function a6(al, am, an) {
      N(al, an);
    }
    function a7(al, am, an) {
      R(al, an);
    }
    function a8(al, am, an) {
      a4(al, a7, am, am['onFileProgress'], an);
    }
    function a9(al, am, an) {
      an(null, __globalAdapter['loadFont'](al) || 'Arial');
    }
    function aa(al, am, an) {
      W(al, function (ao) {
        ao ? an(null, al) : an(new Error('file\x20'['concat'](al, '\x20does\x20not\x20exist!')));
      });
    }
    function ab(al, am, an) {
      a4(al, aa, am, am['onFileProgress'], an);
    }
    a1['platform'] === a1['Platform']['TAOBAO_MINI_GAME'] && (j = globalThis['__taobaoRequire']);
    function ac(al, am, an) {
      Q(al, function (ao, ap) {
        ao ? an(ao) : ag(ap, am, an);
      });
    }
    function ad(al, am, an) {
      Q(al, function (ao, ap) {
        ao ? an(ao) : ah(ap, am, an);
      });
    }
    function ae(al, am, an) {
      Q(al, function (ao, ap) {
        ao ? an(ao) : ai(ap, am, an);
      });
    }
    function af(al, am, an) {
      N(al, function (ao, ap) {
        ao ? an(ao) : aj(ap, am, an);
      });
    }
    var ag = H['parsePVRTex'],
      ah = H['parsePKMTex'],
      ai = H['parseASTCTex'],
      aj = H['parsePlist'];
    Y['downloadScript'] = a2, Y['_downloadArrayBuffer'] = function (al, am, an) {
      a4(al, a5, am, am['onFileProgress'], an);
    }, Y['_downloadJson'] = a8, H['parsePVRTex'] = ac, H['parsePKMTex'] = ad, H['parseASTCTex'] = ae, H['parsePlist'] = af, Y['register']({
      '.js': a2,
      '.mp3': ab,
      '.ogg': ab,
      '.wav': ab,
      '.m4a': ab,
      '.png': ab,
      '.jpg': ab,
      '.bmp': ab,
      '.jpeg': ab,
      '.gif': ab,
      '.ico': ab,
      '.tiff': ab,
      '.image': ab,
      '.webp': ab,
      '.pvr': ab,
      '.pkm': ab,
      '.astc': ab,
      '.font': ab,
      '.eot': ab,
      '.ttf': ab,
      '.woff': ab,
      '.svg': ab,
      '.ttc': ab,
      '.txt': ab,
      '.xml': ab,
      '.vsh': ab,
      '.fsh': ab,
      '.atlas': ab,
      '.tmx': ab,
      '.tsx': ab,
      '.plist': ab,
      '.fnt': ab,
      '.json': a8,
      '.ExportJson': ab,
      '.binary': ab,
      '.bin': ab,
      '.dbbin': ab,
      '.skel': ab,
      '.mp4': ab,
      '.avi': ab,
      '.mov': ab,
      '.mpg': ab,
      '.mpeg': ab,
      '.rm': ab,
      '.rmvb': ab,
      'bundle': function bundle(al, am, an) {
        var ao,
          ap,
          aq,
          ar = cc['path']['basename'](al),
          as = (as = am['version'] || cc['assetManager']['downloader']['bundleVers'][ar]) ? ''['concat'](as, '.') : '';
        a0[ar] ? (ao = (a1['platform'] === a1['Platform']['TAOBAO_MINI_GAME'] ? '' : 'subpackages/')['concat'](ar, '/config.')['concat'](as, 'json'), U(ar, am['onFileProgress'], function (at) {
          at ? an(at, null) : a8(ao, am, function (au, av) {
            var aw;
            (aw = av) && (a1['platform'] === a1['Platform']['TAOBAO_MINI_GAME'] ? aw['base'] = ''['concat'](ar, '/') : aw['base'] = 'subpackages/'['concat'](ar, '/')), an(au, av);
          });
        })) : (X['test'](al) || al['startsWith'](V()) ? (aq = al, ap = 'src/bundle-scripts/'['concat'](ar, '/index.')['concat'](as, 'js'), G['makeBundleFolder'](ar)) : -0x1 !== Y['remoteBundles']['indexOf'](ar) ? (aq = ''['concat'](Y['remoteServerAddress'], 'remote/')['concat'](ar), ap = 'src/bundle-scripts/'['concat'](ar, '/index.')['concat'](as, 'js'), G['makeBundleFolder'](ar)) : (aq = 'assets/'['concat'](ar), ap = 'assets/'['concat'](ar, '/index.')['concat'](as, 'js')), a1['platform'] === a1['Platform']['TAOBAO_MINI_GAME'] ? j(ap) : a1['platform'] !== a1['Platform']['TAOBAO_CREATIVE_APP'] && j('./'['concat'](ap)), am['__cacheBundleRoot__'] = ar, a8(''['concat'](aq, '/config.')['concat'](as, 'json'), am, function (at, au) {
          var av, aw, ax;
          at ? an && an(at) : au['isZip'] ? (at = au['zipVersion'], at = ''['concat'](aq, '/res.')['concat'](at ? ''['concat'](at, '.') : '', 'zip'), av = at, aw = am, ax = function ax(ay, az) {
            ay ? an && an(ay) : (au['base'] = ''['concat'](az, '/res/'), a1['platform'] === a1['Platform']['ALIPAY_MINI_GAME'] && a1['os'] === a1['OS']['ANDROID'] && (ay = ''['concat'](az, 'res/'), J['accessSync']({
              'path': ay
            })['success']) && (au['base'] = ay), an && an(null, au));
          }, (at = G['cachedFiles']['get'](av)) ? (G['updateLastTime'](av), ax && ax(null, at['url'])) : X['test'](av) ? L(av, null, aw['header'], aw['onFileProgress'], function (ay, az) {
            ay ? ax && ax(ay) : G['unzipAndCacheBundle'](av, az, aw['__cacheBundleRoot__'], ax);
          }) : G['unzipAndCacheBundle'](av, av, aw['__cacheBundleRoot__'], ax)) : (au['base'] = ''['concat'](aq, '/'), an && an(null, au));
        }));
      },
      'default': function _default(al, am, an) {
        a4(al, a6, am, am['onFileProgress'], an);
      }
    }), H['register']({
      '.png': Y['downloadDomImage'],
      '.jpg': Y['downloadDomImage'],
      '.bmp': Y['downloadDomImage'],
      '.jpeg': Y['downloadDomImage'],
      '.gif': Y['downloadDomImage'],
      '.ico': Y['downloadDomImage'],
      '.tiff': Y['downloadDomImage'],
      '.image': Y['downloadDomImage'],
      '.webp': Y['downloadDomImage'],
      '.pvr': ac,
      '.pkm': ad,
      '.astc': ae,
      '.font': a9,
      '.eot': a9,
      '.ttf': a9,
      '.woff': a9,
      '.svg': a9,
      '.ttc': a9,
      '.mp3': a3,
      '.ogg': a3,
      '.wav': a3,
      '.m4a': a3,
      '.txt': a6,
      '.xml': a6,
      '.vsh': a6,
      '.fsh': a6,
      '.atlas': a6,
      '.tmx': a6,
      '.tsx': a6,
      '.fnt': a6,
      '.plist': af,
      '.binary': a5,
      '.bin': a5,
      '.dbbin': a5,
      '.skel': a5,
      '.ExportJson': a7
    }), cc['assetManager']['transformPipeline']['append'](function (al) {
      for (var am = al['output'] = al['input'], an = 0x0, ao = am['length']; an < ao; an++) {
        var ap = am[an],
          aq = ap['options'];
        if (ap['config']) aq['__cacheBundleRoot__'] = ap['config']['name'];else {
          if ('bundle' === ap['ext']) continue;
          aq['cacheEnabled'] = void 0x0 !== aq['cacheEnabled'] && aq['cacheEnabled'];
        }
        '.cconb' === ap['ext'] ? ap['url'] = ap['url']['replace'](ap['ext'], '.bin') : '.ccon' === ap['ext'] && (ap['url'] = ap['url']['replace'](ap['ext'], '.json'));
      }
    });
    var ak = cc['assetManager']['init'];
    cc['assetManager']['init'] = function (al) {
      ak['call'](cc['assetManager'], al), al = cc['settings']['querySettings']('assets', 'subpackages'), (al && al['forEach'](function (am) {
        return a0[am] = 'subpackages/'['concat'](am);
      }), G['init']());
    };
  }, {
    './cache-manager': 0x3
  }],
  0x2: [function (b, d, f) {
    function g() {
      this['_delegate'] = null, this['_editing'] = !0x1, this['_eventListeners'] = {
        'onKeyboardInput': null,
        'onKeyboardConfirm': null,
        'onKeyboardComplete': null
      };
    }
    var h, j, k, l;
    cc && cc['internal'] && cc['internal']['EditBox'] && (h = cc['internal']['EditBox'], j = h['KeyboardReturnType'], l = k = null, cc['js']['extend'](g, h['_EditBoxImpl']), h['_EditBoxImpl'] = g, Object['assign'](g['prototype'], {
      'init': function init(m) {
        m ? this['_delegate'] = m : cc['error']('EditBox\x20init\x20failed');
      },
      'beginEditing': function beginEditing() {
        var m = this;
        this['_editing'] || this['_ensureKeyboardHide'](function () {
          var p = m['_delegate'];
          m['_showKeyboard'](), m['_registerKeyboardEvent'](), m['_editing'] = !0x0, l = m, p['_editBoxEditingDidBegan']();
        });
      },
      'endEditing': function endEditing() {
        this['_hideKeyboard']();
        var m = this['_eventListeners'];
        m['onKeyboardComplete'] && m['onKeyboardComplete']();
      },
      '_registerKeyboardEvent': function _registerKeyboardEvent() {
        var m = this,
          p = this['_delegate'],
          q = this['_eventListeners'];
        q['onKeyboardInput'] = function (s) {
          p['_string'] !== s['value'] && p['_editBoxTextChanged'](s['value']);
        }, q['onKeyboardConfirm'] = function (s) {
          s && s['value'] ? p['_editBoxEditingReturn'](s['value']) : p['_editBoxEditingReturn']();
          var u = m['_eventListeners'];
          u['onKeyboardComplete'] && u['onKeyboardComplete'](s);
        }, q['onKeyboardComplete'] = function (s) {
          m['_editing'] = !0x1, l = null, cc['sys']['platform'] !== cc['sys']['Platform']['WECHAT_MINI_PROGRAM'] && m['_unregisterKeyboardEvent'](), s && s['value'] && s['value'] !== p['string'] && p['_editBoxTextChanged'](s['value']), s && s['value'] ? p['_editBoxEditingDidEnded'](s['value']) : p['_editBoxEditingDidEnded']();
        }, __globalAdapter['onKeyboardInput'](q['onKeyboardInput']), __globalAdapter['onKeyboardConfirm'](q['onKeyboardConfirm']), __globalAdapter['onKeyboardComplete'](q['onKeyboardComplete']);
      },
      '_unregisterKeyboardEvent': function _unregisterKeyboardEvent() {
        var m = this['_eventListeners'];
        m['onKeyboardInput'] && (__globalAdapter['offKeyboardInput'](m['onKeyboardInput']), m['onKeyboardInput'] = null), m['onKeyboardConfirm'] && (__globalAdapter['offKeyboardConfirm'](m['onKeyboardConfirm']), m['onKeyboardConfirm'] = null), m['onKeyboardComplete'] && (__globalAdapter['offKeyboardComplete'](m['onKeyboardComplete']), m['onKeyboardComplete'] = null);
      },
      '_otherEditing': function _otherEditing() {
        return !!l && l !== this && l['_editing'];
      },
      '_ensureKeyboardHide': function _ensureKeyboardHide(m) {
        var p = this['_otherEditing']();
        if (!p && !k) return m();
        k && clearTimeout(k), p && l['endEditing'](), k = setTimeout(function () {
          k = null, m();
        }, 0x258);
      },
      '_showKeyboard': function _showKeyboard() {
        var m = this['_delegate'],
          p = m['inputMode'] === h['InputMode']['ANY'];
        __globalAdapter['showKeyboard']({
          'defaultValue': m['string'],
          'maxLength': m['maxLength'] < 0x0 ? 0xffff : m['maxLength'],
          'multiple': p,
          'confirmHold': !0x1,
          'confirmType': function (q) {
            switch (q) {
              case j['DEFAULT']:
              case j['DONE']:
                return 'done';
              case j['SEND']:
                return 'send';
              case j['SEARCH']:
                return 'search';
              case j['GO']:
                return 'go';
              case j['NEXT']:
                return 'next';
              default:
                return 'done';
            }
          }(m['returnType']),
          'success': function success(q) {},
          'fail': function fail(q) {
            cc['warn'](q['errMsg']);
          }
        });
      },
      '_hideKeyboard': function _hideKeyboard() {
        __globalAdapter['hideKeyboard']({
          'success': function success(m) {},
          'fail': function fail(m) {
            cc['warn'](m['errMsg']);
          }
        });
      }
    }));
  }, {}],
  0x3: [function (b, g, j) {
    var k = window['fsUtils'],
      q = k['getUserDataPath'],
      w = k['readJsonSync'],
      x = k['makeDirSync'],
      z = k['writeFileSync'],
      A = k['copyFile'],
      B = k['downloadFile'],
      C = k['deleteFile'],
      D = k['rmdirSync'],
      E = k['unzip'],
      F = k['isOutOfStorage'],
      G = !0x1,
      H = null,
      I = !0x1,
      J = 0x0,
      K = /^https?:\/\/.*/;
    cc['assetManager']['cacheManager'] = g['exports'] = {
      'cacheDir': 'gamecaches',
      'cachedFileName': 'cacheList.json',
      'cacheEnabled': !0x0,
      'autoClear': !0x0,
      'cacheInterval': 0x1f4,
      'deleteInterval': 0x1f4,
      'writeFileInterval': 0x7d0,
      'outOfStorage': !0x1,
      'tempFiles': null,
      'cachedFiles': null,
      'cacheQueue': {},
      'version': '1.0',
      'getCache': function getCache(L) {
        return this['cachedFiles']['has'](L) ? this['cachedFiles']['get'](L)['url'] : '';
      },
      'getTemp': function getTemp(L) {
        return this['tempFiles']['has'](L) ? this['tempFiles']['get'](L) : '';
      },
      'init': function init() {
        this['cacheDir'] = ''['concat'](q(), '/')['concat'](this['cacheDir']);
        var L = ''['concat'](this['cacheDir'], '/')['concat'](this['cachedFileName']),
          M = w(L);
        M instanceof Error || !M['version'] ? (M instanceof Error || D(this['cacheDir'], !0x0), this['cachedFiles'] = new cc['AssetManager']['Cache'](), x(this['cacheDir'], !0x0), z(L, JSON['stringify']({
          'files': this['cachedFiles']['_map'],
          'version': this['version']
        }), 'utf8')) : this['cachedFiles'] = new cc['AssetManager']['Cache'](M['files']), this['tempFiles'] = new cc['AssetManager']['Cache']();
      },
      'updateLastTime': function updateLastTime(L) {
        this['cachedFiles']['has'](L) && (this['cachedFiles']['get'](L)['lastTime'] = Date['now']());
      },
      '_write': function _write() {
        H = null, z(''['concat'](this['cacheDir'], '/')['concat'](this['cachedFileName']), JSON['stringify']({
          'files': this['cachedFiles']['_map'],
          'version': this['version']
        }), 'utf8');
      },
      'writeCacheFile': function writeCacheFile() {
        H = H || setTimeout(this['_write']['bind'](this), this['writeFileInterval']);
      },
      '_cache': function _cache() {
        G = !0x1;
        var L,
          M,
          N,
          O,
          P,
          Q,
          R,
          S = this,
          T = '';
        for (L in this['cacheQueue']) {
          T = L;
          break;
        }
        function U(V) {
          if (V) {
            if (F(V['message'])) return S['outOfStorage'] = !0x0, void (S['autoClear'] && S['clearLRU']());
          } else S['cachedFiles']['add'](T, {
            'bundle': P,
            'url': R,
            'lastTime': Q
          }), S['writeCacheFile']();
          delete S['cacheQueue'][T], cc['js']['isEmptyObject'](S['cacheQueue']) || G || (G = !0x0, setTimeout(S['_cache']['bind'](S), S['cacheInterval']));
        }
        T && (N = (M = this['cacheQueue'][T])['srcUrl'], O = M['isCopy'], P = M['cacheBundleRoot'], Q = Date['now']()['toString'](), R = '', R = (P ? ''['concat'](this['cacheDir'], '/')['concat'](P, '/') : ''['concat'](this['cacheDir'], '/'))['concat'](Q)['concat'](J++)['concat'](cc['path']['extname'](T)), O ? A(N, R, U) : B(N, R, null, U));
      },
      'cacheFile': function cacheFile(L, M, N, O, P) {
        !(N = void 0x0 !== N ? N : this['cacheEnabled']) || this['cacheQueue'][L] || this['cachedFiles']['has'](L) || (this['cacheQueue'][L] = {
          'srcUrl': M,
          'cacheBundleRoot': O,
          'isCopy': P
        }, G) || this['outOfStorage'] || (G = !0x0, setTimeout(this['_cache']['bind'](this), this['cacheInterval']));
      },
      'clearCache': function clearCache() {
        var L = this;
        D(this['cacheDir'], !0x0), this['cachedFiles'] = new cc['AssetManager']['Cache'](), x(this['cacheDir'], !0x0), this['outOfStorage'] = !0x1, clearTimeout(H), this['_write'](), cc['assetManager']['bundles']['forEach'](function (M) {
          K['test'](M['base']) && L['makeBundleFolder'](M['name']);
        });
      },
      'clearLRU': function clearLRU() {
        if (!I) {
          I = !0x0;
          var L = [],
            M = this;
          this['cachedFiles']['forEach'](function (Q, R) {
            M['_isZipFile'](R) && cc['assetManager']['bundles']['find'](function (S) {
              return -0x1 !== S['base']['indexOf'](Q['url']);
            }) || L['push']({
              'originUrl': R,
              'url': Q['url'],
              'lastTime': Q['lastTime']
            });
          }), L['sort'](function (Q, R) {
            return Q['lastTime'] - R['lastTime'];
          }), L['length'] < 0x3 ? console['warn']('Insufficient\x20storage,\x20cleaning\x20now') : L['length'] = Math['floor'](L['length'] / 0x3);
          for (var N = 0x0, O = L['length']; N < O; N++) {
            var P = ''['concat'](cc['assetManager']['utils']['getUuidFromURL'](L[N]['originUrl']), '@native');
            cc['assetManager']['files']['remove'](P), this['cachedFiles']['remove'](L[N]['originUrl']);
          }
          clearTimeout(H), this['_write'](), setTimeout(function Q() {
            var R = L['pop']();
            M['_removePathOrFile'](R['originUrl'], R['url']), 0x0 < L['length'] ? setTimeout(Q, M['deleteInterval']) : I = !0x1;
          }, M['deleteInterval']);
        }
      },
      'removeCache': function removeCache(L) {
        var M;
        this['cachedFiles']['has'](L) && (M = this['cachedFiles']['remove'](L)['url'], clearTimeout(H), this['_write'](), this['_removePathOrFile'](L, M));
      },
      '_removePathOrFile': function _removePathOrFile(L, M) {
        !this['_isZipFile'](L) || this['_isZipFile'](M) ? C(M, this['_deleteFileCB']['bind'](this)) : (D(M, !0x0), this['_deleteFileCB']());
      },
      '_deleteFileCB': function _deleteFileCB(L) {
        L || (this['outOfStorage'] = !0x1);
      },
      'makeBundleFolder': function makeBundleFolder(L) {
        x(''['concat'](this['cacheDir'], '/')['concat'](L), !0x0);
      },
      'unzipAndCacheBundle': function unzipAndCacheBundle(L, M, N, O) {
        var P = Date['now']()['toString'](),
          Q = ''['concat'](this['cacheDir'], '/')['concat'](N, '/')['concat'](P)['concat'](J++),
          R = this;
        x(Q, !0x0), E(M, Q, function (S) {
          S ? (D(Q, !0x0), F(S['message']) && (R['outOfStorage'] = !0x0, R['autoClear']) && R['clearLRU'](), O && O(S)) : (R['cachedFiles']['add'](L, {
            'bundle': N,
            'url': Q,
            'lastTime': P
          }), R['writeCacheFile'](), O && O(null, Q));
        });
      },
      '_isZipFile': function _isZipFile(L) {
        return '.zip' === L['slice'](-0x4);
      }
    };
  }, {}],
  0x4: [function (a, b, c) {
    a('./Editbox'), a('./AssetManager');
  }, {
    './AssetManager': 0x1,
    './Editbox': 0x2
  }],
  0x5: [function (b, g, j) {
    function k(E) {
      return (k = 'function' == typeof Symbol && 'symbol' == _typeof(Symbol['iterator']) ? function (F) {
        return _typeof(F);
      } : function (F) {
        return F && 'function' == typeof Symbol && F['constructor'] === Symbol && F !== Symbol['prototype'] ? 'symbol' : _typeof(F);
      })(E);
    }
    function m(E, F) {
      for (var G = 0x0; G < F['length']; G++) {
        var H = F[G];
        H['enumerable'] = H['enumerable'] || !0x1, H['configurable'] = !0x0, 'value' in H && (H['writable'] = !0x0), Object['defineProperty'](E, function (I) {
          return I = function (J, K) {
            if ('object' != k(J) || !J) return J;
            var L = J[Symbol['toPrimitive']];
            if (void 0x0 === L) return ('string' === K ? String : Number)(J);
            if ('object' != k(L = L['call'](J, K || 'default'))) return L;
            throw new TypeError('@@toPrimitive\x20must\x20return\x20a\x20primitive\x20value.');
          }(I, 'string'), 'symbol' == k(I) ? I : I + '';
        }(H['key']), H);
      }
    }
    function q(E, F, G) {
      F = w(F);
      var H = E,
        F = v() ? Reflect['construct'](F, G || [], w(E)['constructor']) : F['apply'](E, G);
      if (!F || 'object' != k(F) && 'function' != typeof F) {
        if (void 0x0 !== F) throw new TypeError('Derived\x20constructors\x20may\x20only\x20return\x20object\x20or\x20undefined');
        if (void 0x0 === (F = H)) throw new ReferenceError('this\x20hasn\x27t\x20been\x20initialised\x20-\x20super()\x20hasn\x27t\x20been\x20called');
      }
      return F;
    }
    function v() {
      try {
        var E = !Boolean['prototype']['valueOf']['call'](Reflect['construct'](Boolean, [], function () {}));
      } catch (F) {}
      return (v = function v() {
        return !!E;
      })();
    }
    function w(E) {
      return (w = Object['setPrototypeOf'] ? Object['getPrototypeOf']['bind']() : function (F) {
        return F['__proto__'] || Object['getPrototypeOf'](F);
      })(E);
    }
    function x(E, F) {
      return (x = Object['setPrototypeOf'] ? Object['setPrototypeOf']['bind']() : function (G, H) {
        return G['__proto__'] = H, G;
      })(E, F);
    }
    var y, z, A, B, C, D;
    cc['internal']['VideoPlayer'] && (y = cc['internal']['VideoPlayer']['EventType'], z = cc['mat4'](), A = new cc['Vec3'](), B = new cc['Vec3'](), C = wx['getSystemInfoSync']()['pixelRatio'], cc['internal']['VideoPlayerImplManager']['getImpl'] = function (E) {
      return new D(E);
    }, D = function (E) {
      function F(I) {
        if (this instanceof F) return q(this, F, [I]);
        throw new TypeError('Cannot\x20call\x20a\x20class\x20as\x20a\x20function');
      }
      var G,
        H = F;
      if ('function' != typeof E && null !== E) throw new TypeError('Super\x20expression\x20must\x20either\x20be\x20null\x20or\x20a\x20function');
      return H['prototype'] = Object['create'](E && E['prototype'], {
        'constructor': {
          'value': H,
          'writable': !0x0,
          'configurable': !0x0
        }
      }), Object['defineProperty'](H, 'prototype', {
        'writable': !0x1
      }), E && x(H, E), H = F, (E = [{
        'key': 'syncClip',
        'value': function value(I) {
          this['removeVideoPlayer'](), I && this['createVideoPlayer'](I['_nativeAsset']);
        }
      }, {
        'key': 'syncURL',
        'value': function value(I) {
          this['removeVideoPlayer'](), I && this['createVideoPlayer'](I);
        }
      }, {
        'key': 'onCanplay',
        'value': function value() {
          this['_loaded'] || (this['_loaded'] = !0x0, this['setVisible'](this['_visible']), this['dispatchEvent'](y['READY_TO_PLAY']), this['delayedPlay']());
        }
      }, {
        'key': '_bindEvent',
        'value': function value() {
          var I = this['_video'],
            J = this;
          I && (I['onPlay'](function () {
            J['_video'] === I && (J['_playing'] = !0x0, J['dispatchEvent'](y['PLAYING']));
          }), I['onEnded'](function () {
            J['_video'] === I && (J['_playing'] = !0x1, J['_currentTime'] = J['_duration'], J['dispatchEvent'](y['COMPLETED']));
          }), I['onPause'](function () {
            J['_video'] === I && (J['_playing'] = !0x1, J['dispatchEvent'](y['PAUSED']));
          }), I['onTimeUpdate'](function (K) {
            J['_duration'] = K['duration'], J['_currentTime'] = K['position'];
          }));
        }
      }, {
        'key': '_unbindEvent',
        'value': function value() {
          var I = this['_video'];
          I && (I['offPlay'](), I['offEnded'](), I['offPause'](), I['offTimeUpdate']());
        }
      }, {
        'key': 'createVideoPlayer',
        'value': function value(I) {
          __globalAdapter['createVideo'] ? (this['_video'] || (this['_video'] = __globalAdapter['createVideo'](), this['_video']['showCenterPlayBtn'] = !0x1, this['_video']['controls'] = !0x1, this['_duration'] = 0x0, this['_currentTime'] = 0x0, this['_loaded'] = !0x1, this['setVisible'](this['_visible']), this['_bindEvent'](), this['_forceUpdate'] = !0x0), this['setURL'](I), this['_forceUpdate'] = !0x0) : console['warn']('VideoPlayer\x20not\x20supported');
        }
      }, {
        'key': 'setURL',
        'value': function value(I) {
          var J,
            K = this['_video'];
          K && K['src'] !== I && (K['stop'](), this['_unbindEvent'](), K['autoplay'] = !0x0, K['src'] = I, K['muted'] = !0x0, (J = this)['_loaded'] = !0x1, K['onPlay'](function () {
            K['offPlay'](), J['_bindEvent'](), K['stop'](), K['muted'] = !0x1, J['_loaded'] = !0x0, J['_playing'] = !0x1, J['_currentTime'] = 0x0, J['dispatchEvent'](y['READY_TO_PLAY']), K['autoplay'] = !0x1;
          }));
        }
      }, {
        'key': 'removeVideoPlayer',
        'value': function value() {
          var I = this['video'];
          I && (I['stop'](), I['destroy'](), this['_playing'] = !0x1, this['_loaded'] = !0x1, this['_loadedMeta'] = !0x1, this['_ignorePause'] = !0x1, this['_cachedCurrentTime'] = 0x0, this['_video'] = null);
        }
      }, {
        'key': 'setVisible',
        'value': function value(I) {
          var J = this['_video'];
          J && this['_visible'] !== I && (J['width'] = I && this['_actualWidth'] || 0x0, this['_visible'] = I);
        }
      }, {
        'key': 'getDuration',
        'value': function value() {
          return this['duration']();
        }
      }, {
        'key': 'duration',
        'value': function value() {
          return this['_duration'];
        }
      }, {
        'key': 'syncPlaybackRate',
        'value': function value(I) {
          var J = this['_video'];
          J && I !== J['playbackRate'] && (0.5 === I | 0.8 === I | 0x1 === I | 1.25 === I | 1.5 === I ? J['playbackRate'] = I : console['warn']('The\x20platform\x20does\x20not\x20support\x20this\x20PlaybackRate!'));
        }
      }, {
        'key': 'syncVolume',
        'value': function value() {
          console['warn']('The\x20platform\x20does\x20not\x20support');
        }
      }, {
        'key': 'syncMute',
        'value': function value(I) {
          var J = this['_video'];
          J && J['muted'] !== I && (J['muted'] = I);
        }
      }, {
        'key': 'syncLoop',
        'value': function value(I) {
          var J = this['_video'];
          J && J['loop'] !== I && (J['loop'] = I);
        }
      }, {
        'key': 'syncStayOnBottom',
        'value': function value() {
          console['warn']('The\x20platform\x20does\x20not\x20support');
        }
      }, {
        'key': 'getCurrentTime',
        'value': function value() {
          return this['video'] ? this['currentTime']() : -0x1;
        }
      }, {
        'key': 'currentTime',
        'value': function value() {
          return this['_currentTime'];
        }
      }, {
        'key': 'seekTo',
        'value': function value(I) {
          var J = this['_video'];
          J && this['_loaded'] && J['seek'](I);
        }
      }, {
        'key': 'disable',
        'value': function value(I) {
          this['_video'] && (I || this['_video']['pause'](), this['setVisible'](!0x1), this['_visible'] = !0x1);
        }
      }, {
        'key': 'enable',
        'value': function value() {
          this['_video'] && (this['setVisible'](!0x0), this['_visible'] = !0x0);
        }
      }, {
        'key': 'canPlay',
        'value': function value() {
          this['_video']['play'](), this['syncCurrentTime']();
        }
      }, {
        'key': 'resume',
        'value': function value() {
          var I = this['_video'];
          !this['_playing'] && I && I['play']();
        }
      }, {
        'key': 'pause',
        'value': function value() {
          var I = this['_video'];
          this['_playing'] && I && I['pause']();
        }
      }, {
        'key': 'stop',
        'value': function value() {
          var I = this,
            J = this['_video'];
          J && this['_visible'] && (this['_playing'] || J['play'](), J['stop']()['then'](function (K) {
            K['errMsg'] && !K['errMsg']['includes']('ok') ? console['error']('failed\x20to\x20stop\x20video\x20player') : (I['_currentTime'] = 0x0, I['_playing'] = !0x1, I['dispatchEvent'](y['STOPPED']));
          }));
        }
      }, {
        'key': 'canFullScreen',
        'value': function value(I) {
          this['_video'] && this['setFullScreenEnabled'](I);
        }
      }, {
        'key': 'setFullScreenEnabled',
        'value': function value(I) {
          var J = this['_video'];
          J && this['_fullScreenEnabled'] !== I && (I ? J['requestFullScreen']() : J['exitFullScreen'](), this['_fullScreenEnabled'] = I);
        }
      }, {
        'key': 'syncKeepAspectRatio',
        'value': function value(I) {
          console['warn']('On\x20wechat\x20game\x20videoPlayer\x20is\x20always\x20keep\x20the\x20aspect\x20ratio');
        }
      }, {
        'key': 'syncMatrix',
        'value': function value() {
          var I, J, K;
          this['_video'] && this['_component'] && this['_uiTrans'] && (K = this['UICamera']) && (this['_component']['node']['getWorldMatrix'](z), I = (J = this['_uiTrans']['contentSize'])['width'], J = J['height'], !this['_forceUpdate'] && this['_m00'] === z['m00'] && this['_m01'] === z['m01'] && this['_m04'] === z['m04'] && this['_m05'] === z['m05'] && this['_m12'] === z['m12'] && this['_m13'] === z['m13'] && this['_w'] === I && this['_h'] === J || (this['_m00'] = z['m00'], this['_m01'] = z['m01'], this['_m04'] = z['m04'], this['_m05'] = z['m05'], this['_m12'] = z['m12'], this['_m13'] = z['m13'], this['_w'] = I, this['_h'] = J, I = cc['game']['canvas']['height'], J = this['_uiTrans']['anchorPoint'], cc['Vec3']['set'](A, -J['x'] * this['_w'], (0x1 - J['y']) * this['_h'], 0x0), cc['Vec3']['set'](B, (0x1 - J['x']) * this['_w'], -J['y'] * this['_h'], 0x0), cc['Vec3']['transformMat4'](A, A, z), cc['Vec3']['transformMat4'](B, B, z), K['worldToScreen'](A, A), K['worldToScreen'](B, B), J = B['x'] - A['x'], K = A['y'] - B['y'], this['_video']['x'] = A['x'] / C, this['_video']['y'] = (I - A['y']) / C, this['_actualWidth'] = this['_video']['width'] = J / C, this['_video']['height'] = K / C, this['_forceUpdate'] = !0x1));
        }
      }]) && m(H['prototype'], E), G && m(H, G), Object['defineProperty'](H, 'prototype', {
        'writable': !0x1
      }), H;
    }(cc['internal']['VideoPlayerImpl']));
  }, {}],
  0x6: [function (a, b, c) {
    a('../../../../common/engine/index'), a('./VideoPlayer'), a('./sprite-frame');
  }, {
    '../../../../common/engine/index': 0x4,
    './VideoPlayer': 0x5,
    './sprite-frame': 0x7
  }],
  0x7: [function (a, b, c) {
    cc['SpriteFrame'] && (cc['SpriteFrame']['prototype']['_checkPackable'] = function () {
      var d,
        f,
        g,
        h = cc['internal']['dynamicAtlasManager'];
      h && (!((d = this['_texture']) instanceof cc['Texture2D']) || d['isCompressed'] || (f = this['width'], g = this['height'], !d['image']) || f > h['maxFrameSize'] || g > h['maxFrameSize'] ? this['_packable'] = !0x1 : d['image'] && d['image']['getContext'] && (this['_packable'] = !0x0));
    });
  }, {}]
}, {}, [0x6]);